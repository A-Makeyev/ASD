log.info(`0. מחיקת לידים ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url, 300)

const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360

web.transaction('04. Open Settings')
if (web.isVisible('//div[@id="wrapper-body"]//h2[contains(text(), "עדכון פרטים אישיים")]', po.longWait)) {
    po.click('//div[@id="wrapper-body"]//h2[contains(text(), "עדכון פרטים אישיים")]//..//..//..//..//..//button[contains(@title, "סגור")]')
}

po.click(main.settingsButton)
po.click(main.settingsMenu.currentApp)
po.selectWindow('new')

function searchRep() {
    po.type(settings.mainSearchInput, env.repName)
    func.pressENTER()
    if (web.isVisible(`(//a[contains(@class, "setupLink") and text()="${env.repName}"])[1]`, po.longWait)) {
        po.click(`(//a[contains(@class, "setupLink") and text()="${env.repName}"])[1]`)
    } else if (web.isVisible(`//span[@title="${env.repName}" and contains(@class, "mruName")]`, po.shortWait)) {
        po.click(`//span[@title="${env.repName}" and contains(@class, "mruName")]`)
    }
}
searchRep()

let tries = 15
while (!web.isVisible(`//iframe[contains(@title, "User: ${env.repName}")]`, po.longWait)) {
    searchRep()
    if (tries == 0) break
    else tries--
}

web.transaction(`05. Login With Rep ${env.repName}`)
main.assertApplicationError()
web.selectFrame(`//iframe[contains(@title, "User: ${env.repName}")]`)
if (web.isVisible('//td[@id="topButtonRow"]//input[@name="login"]', po.shortWait)) {
    po.click('//td[@id="topButtonRow"]//input[@name="login"]')
} else {
    assert.fail(`לא מופיע כפתור כניסה לנציג\ה ${env.repName}`)
}

po.selectWindow('new')
main.assertApplicationError()

if (web.isVisible(`//header[@id="oneHeader"]//span[contains(text(), "כניסה בוצעה בתור ${env.repName}")]`, po.longWait)) {
    po.log('success', `Logged in with rep -> ${env.repName}`)
} else {
    po.log('warning', `Rep ${env.repName} is not visible`)
}

if (web.isVisible('//lightning-formatted-text[contains(text(), "ההפעלה שלך הסתיימה")]', po.longWait)) {
    po.log('warning', web.getText('//lightning-formatted-text[contains(text(), "ההפעלה שלך הסתיימה")]//..//lightning-formatted-text'))
    po.click('//button[contains(text(), "כניסה")]')
}

web.transaction('06. Close All Active Tabs')
main.closeAllTabs()

web.transaction('7. Open Leads')
po.click(main.navigationBtn)
po.click(main.navigationOptions.leads)

web.transaction('8. Delete Leads')
var deletedLeads = []
var testLeads = '//a[@data-refid="recordId" and contains(@title, "Automation")]'
var currentLeadButton = `(${testLeads}//..//..//..//a[contains(@class, "rowActionsPlaceHolder")])[1]`

if (web.isVisible(testLeads)) {
    var testLeadCount = web.getElementCount(testLeads)

    while (web.isVisible(currentLeadButton)) {
        po.click(currentLeadButton)
        web.pause(po.shortWait / 2)
        po.click('//a[@role="menuitem" and @title="מחיקה"]')
        po.click('//h2[contains(text(), "מחק ליד")]//..//..//button[@title="מחיקה"]')
        
        if (web.isVisible('//span[@data-aura-class="forceActionsText"]', po.longWait)) {
            let deletedLead = web.getText('//span[@ data-aura-class="forceActionsText"]')
            po.log('success', deletedLead)
            deletedLeads.push(deletedLead)
        } else if (web.isVisible('//div[contains(text(), "אין לך הרשאה למחוק")]', po.longWait)) {
            let undeletedLead = web.getText('//div[contains(text(), "אין לך הרשאה למחוק")]')
            let leadName = web.getText(`(${testLeads})[1]`)
            po.log('warning', `${undeletedLead}: ${leadName}`)
            break
        }

        if (testLeadCount == 0) {
            po.log('info', `Deleted ${deletedLeads.length} leads`)
            break
        } else {
            testLeadCount--
        }
    }
} else {
    po.log('info', 'No test leads available')
    assert.pass()
}
