log.info(`2. תהליך מכר עם הצעת סטינג ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url, 300)

const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360

var id = func.createTzNumber()
var phone = func.generatePhone()
var email = func.generateEmail()
var firstName = func.generateName()
var lastName = `Automation - ${Math.random().toString().slice(2, 8)}`
var houseNumber = func.generateNumber(1, 9999)
var apartmentNumber = Math.trunc(houseNumber / 2)
var productNumber = '200701'

po.log('info', `ID: ${id}`)
po.log('info', `Phone: ${phone}`)
po.log('info', `Email: ${email}`)
po.log('info', `First Name: ${firstName}`)
po.log('info', `Last Name: ${lastName}`)
po.log('info', `House Number: ${houseNumber}`)
po.log('info', `Apartment Number: ${apartmentNumber}`)
po.log('info', `Product Number: ${productNumber}`)

web.transaction('04. Open Settings')
if (web.isVisible('//div[@id="wrapper-body"]//h2[contains(text(), "עדכון פרטים אישיים")]', po.longWait)) {
    po.click('//div[@id="wrapper-body"]//h2[contains(text(), "עדכון פרטים אישיים")]//..//..//..//..//..//button[contains(@title, "סגור")]')
}

if (web.isVisible('//div[contains(@class, "modal-header")]//*[contains(text(), "משהו השתבש")]', po.shortWait)) {
    po.log('warning', web.getText('(//div[contains(@class, "modal-container")]//div[contains(@class, "modal-body")])[2]'))
    po.click('//div[contains(@class, "modal-container")]//button[contains(text(), "אישור")]')
    func.refresh()
}

po.click(main.settingsButton)
po.click(main.settingsMenu.currentApp)
po.selectWindow('new')

function searchRep() {
    po.type(settings.mainSearchInput, env.repName)
    func.pressENTER()
    if (web.isVisible(`(//a[contains(@class, "setupLink") and text()="${env.repName}"])[1]`, po.shortWait)) {
        po.click(`(//a[contains(@class, "setupLink") and text()="${env.repName}"])[1]`)
    } else if (web.isVisible(`//span[@title="${env.repName}" and contains(@class, "mruName")]`, po.shortWait)) {
        po.click(`//span[@title="${env.repName}" and contains(@class, "mruName")]`)
    }
}
searchRep()

let tries = 15
while (!web.isVisible(`//iframe[contains(@title, "User: ${env.repName}")]`, po.longWait)) {
    searchRep()
    if (tries == 0) break
    else tries--
}

web.transaction(`05. Login With Rep ${env.repName}`)
main.assertApplicationError()
web.selectFrame(`//iframe[contains(@title, "User: ${env.repName}")]`)
if (web.isVisible('//td[@id="topButtonRow"]//input[@name="login"]', po.shortWait)) {
    po.click('//td[@id="topButtonRow"]//input[@name="login"]')
} else {
    assert.fail(`לא מופיע כפתור כניסה לנציג\ה ${env.repName}`)
}

po.selectWindow('new')
main.assertApplicationError()

if (web.isVisible(`//header[@id="oneHeader"]//span[contains(text(), "כניסה בוצעה בתור ${env.repName}")]`, po.longWait)) {
    po.log('success', `Logged in with rep -> ${env.repName}`)
} else {
    po.log('warning', `Rep ${env.repName} is not visible`)
}

if (web.isVisible('//lightning-formatted-text[contains(text(), "ההפעלה שלך הסתיימה")]', po.longWait)) {
    po.log('warning', web.getText('//lightning-formatted-text[contains(text(), "ההפעלה שלך הסתיימה")]//..//lightning-formatted-text'))
    po.click('//button[contains(text(), "כניסה")]')
}

if (web.isVisible('id=ErrorLoadingGantt', po.longWait)) {
    po.log('error', web.getText('id=ErrorLoadingGantt'))
    func.refresh()
}

web.transaction('06. Close All Active Tabs')
main.closeAllTabs()

web.transaction('07. Open New Lead Form')
if (!web.isVisible(main.globalActionsButton)) func.refresh()
po.click(main.globalActionsButton)
po.click(main.globalActionsMenu.createLead)

web.transaction('08. Type Lead Details')
if (!web.isVisible(leads.createLeadFormHeader, po.longWait)) {
    main.closeAllTabs()
    po.click(main.globalActionsButton)
    po.click(main.globalActionsMenu.createLead)
}

po.type(leads.firstName, firstName)
po.type(leads.lastName, lastName)
po.type(leads.phone, phone) 
func.pressTAB()

leads.handlePhoneError()

if (!web.getValue(leads.phone).includes(phone)) {
    phone = web.getValue(leads.phone)
    po.log('info', `Updated phone to: ${phone}`)
}

po.type(leads.id, id) 
func.pressTAB()

if (!web.isVisible('//input[@data-value="YES"]', po.shortWait)) {
    po.click(leads.handlingCompanyBtn)
    if (web.isVisible(leads.handlingCompany.yes)) {
        po.click(leads.handlingCompany.yes)
    }   
}

po.click(leads.interestedInBtn)
po.click(leads.interestedIn.yes)

if (web.isVisible(leads.customerConfirm, po.shortWait)) {
    po.click(leads.customerConfirm)
}

web.transaction('09. Create Lead') 
po.click('(//div[contains(@class, "omniscript-body")]//button[@aria-label="סיום"])[1]')

if (!web.isVisible(`(//lightning-formatted-name[contains(text(), "${firstName} ${lastName}")])[1]`)) {
    po.log('warning', `New lead did not include the right name (${firstName} ${lastName})`)
}

if (!web.isVisible(`(//*[@title="טלפון"]//..//lightning-formatted-text[contains(text(), "${phone}")])[1]`)) {
    po.log('warning', `New lead did not include the right phone number (${phone})`)
}

web.transaction('10. Update Lead')
po.type(leads.offerGivenInput, 'טריפל yes')
po.type(leads.offerTextarea, 'פירוט הצעה שניתנה')
po.click(leads.status.interested)
po.click(leads.rivalCompanies.triple_C)

let displayedId = web.getValue(leads.idInput)
if (displayedId != id) {
    assert.fail(`Update lead window displayed the wrong id. Expected id: ${id} instead got: ${displayedId}`)
} else if (displayedId == '') {
    po.log('error', `Update lead window doesn't include newly created id (${id})`)
    po.type(leads.idInput, id)
} 

web.transaction('11. Find Customer')
po.click(leads.findCustomersBtn)

if (!web.isVisible('//button[text()="' + main.customerName + '"]', po.shortWait * 2)) {
    if (web.isVisible('//*[contains(text(), "קיימת הזמנה פתוחה למספר זיהוי")]', po.shortWait)) {
        po.click('//*[contains(text(), "סגירת ליד")]//..//*[@class="slds-radio_faux"]')
        po.click(leads.finishUpdateLead)
        assert.equal(
            web.isVisible('//*[@data-refid="tab-name" and @title="הסתיים"]'), true,
            'ליד עם תז ' + id + ' לא הסתיים בהצלחה'
        )
    }
    po.log('info', 'לא נמצאו תוצאות ללקוח עם תז: ' + id)
} else {
    po.click(`//button[text()="${main.customerName}"]//..//..//..//span[@class="slds-radio_faux"]`)
}

web.transaction('12. Finish Update Lead')
po.click('//*[contains(text(), "יצירת חשבון חיוב חדש")]//..//..//..//*[@class="slds-radio_faux"]')
po.click(leads.finishUpdateLead)

assert.equal(
    web.isVisible('//lightning-layout-item[@title="תהליך מכר"]'), true,
    'מסך תהליך מכר לא הופיע לאחר לחיצה על עדכון ליד'
)

web.transaction('13. Add Address')
var city = 'כפר סבא'
var street = 'היוזמה'
var randomHomeNumber = func.generateNumber(1, 9999)

po.specialType('//label[contains(text(), "עיר")]//..//input', city)
po.specialClick(`//span[@role="option"]//span[contains(text(), "${city}")]`)
po.specialType('//label[contains(text(), "רחוב")]//..//input', street)
po.specialClick(`//span[@role="option"]//span[contains(text(), "${street}")]`)

po.specialType('//label[contains(text(), "Email")]//..//input', email)
po.specialType('//label[contains(text(), "מספר בית")]//..//input', randomHomeNumber)
po.specialClick('//span[contains(text(), "פרטי כתובות לקוח")]//..//..//..//..//..//span[@class="slds-radio_faux"]//..//span[contains(text(), "בניין")]')
po.specialType('//label[contains(text(), "מספר דירה")]//..//input', '1') 
po.specialType('//label[contains(text(), "כניסה")]//..//input', 'ללא כניסה')

po.click('//*[@aria-disabled="false" and (text()="הבא")]')
main.assertErrorDialog()

let changeHomeNumber = (tries) => {
    if (tries == 0) return
    if (!web.isVisible('//*[contains(text(), "קיים לקוח AC  בכתובת")]', po.longWait)) {
        return
    } else {
        randomHomeNumber = func.generateNumber(1, 9999)
        po.log('warning', web.getText('//*[contains(text(), "קיים לקוח AC  בכתובת")]'))
        po.type('//label[contains(text(), "מספר בית")]//..//input', randomHomeNumber)
        po.click('//*[@aria-disabled="false" and (text()="הבא")]')
        main.assertErrorDialog()
    }
    changeHomeNumber(tries--)
}
changeHomeNumber(10)

web.transaction('14. Feasibility Test')
assert.equal(
    web.isVisible(`//*[contains(text(), "היוזמה") and contains(text(), "כפר סבא") and contains(text(), "${randomHomeNumber}")]`), true,
    `הכתובת שמוצגת בבדיקת היתכנות לא תואמת לכתובת שהוזנה (${city + ' ' + street + ' ' + randomHomeNumber})`
)

po.click('//*[@aria-disabled="false" and (text()="הבא")]')
main.assertErrorDialog()

web.transaction('15. Choose STINGTV Product')
po.click('//label[contains(text(), "הצעות טלויזיה")]//..//button')
po.click('//lightning-base-combobox-item[@data-value="STINGTV"]')

if (web.isVisible('//c-cart-search-result-item')) {
    var offers = web.getElementCount('//c-cart-search-result-item')
    for (let x = 1; x <= offers; x++) {
        var offerNumber = web.getText(`(//c-cart-search-result-item//*[contains(@class, "slds-card__header-title")]//span)[${x}]`)
        var offerDesc = web.getText(`(//c-cart-search-result-item//div[contains(@class, "slds-card__body")])[${x}]`)

        po.specialClick(`(//c-cart-search-result-item//button[@title="joinNow"])[${x}]`)
        if (!web.isVisible('//lightning-badge[contains(text(), "ממירים בשכירות")]', po.shortWait)) {
            po.log('warning', `Can't open offer number: ${offerNumber}`)
            continue
        }

        po.specialClick('//lightning-badge[contains(text(), "ממירים בשכירות")]')
        po.specialClick('//c-cart-expand-icon//..//span[contains(text(), "AppleTV")]')
        po.specialClick('(//c-cart-expand-icon//..//span[contains(text(), "AppleTV")]//..//..//..//..//..//..//span[@class="slds-checkbox_faux"])[1]')
        po.specialClick('//button[contains(text(), "הגדרת מוצר")]')

        if (web.isVisible('//*[contains(text(), "לא נמצאו מוצרים המתאימים")]', po.shortWait)) {
            po.click('//button[contains(text(), "ביטול")]')
            po.click('//button[contains(text(), "הקודם")]')
            if (web.isVisible('//h1[contains(text(), "תהליך מכר")]', po.longWait)) {
                po.click('//*[@aria-disabled="false" and (text()="הבא")]')
                main.assertErrorDialog()
                continue
            }
        }

        if (web.isExist('//slot[contains(text(), "AppleTV")]', po.shortWait)) {
            productNumber = offerNumber
            po.log('info', 'Updated Product Number: ' + productNumber)
            break
        } else if (web.isVisible('//div[@data-key="error"]', po.shortWait)) {
            po.log('error', web.getText('//div[@data-key="error"]'))
            continue
        }
    }
}

po.click('//*[@aria-disabled="false" and (text()="הבא")]')
main.assertErrorDialog()

web.transaction('16. Accept Conditions')
if (web.isVisible('//*[@class="slds-card__header-title"]//span[contains(text(), "שאלות להקמת לקוח")]')) {
    po.specialClick('//label[contains(text(), "האם הצעת ללקוח אינטרנט?")]//..//button[contains(@class, "slds-combobox__input")]')
    po.specialClick('//span[@title="לקוח לא מעוניין"]')

    po.specialClick('//label[contains(text(), "האם הלקוח ממתין להתקנת תשתית?")]//..//button[contains(@class, "slds-combobox__input")]')
    po.specialClick('//span[@title="לא ממתין להתקנת תשתית - קיימת תשתית אינטרנט"]')

    po.specialClick('//label[contains(text(), "אישור מידע שיווקי למייל ול-SMS")]//..//button[contains(@class, "slds-combobox__input")]')
    func.pressARROW_DOWN()
    func.pressARROW_DOWN()
    func.pressENTER()
    func.pressTAB()

    po.specialClick('//label[contains(text(), "האם הלקוח אישר פרסום דיגיטלי פרסונלי?")]//..//button[contains(@class, "slds-combobox__input")]')
    func.pressARROW_DOWN()
    func.pressENTER()
    func.pressTAB()

    if (web.isVisible('//label[contains(text(), "האם הלקוח אישר פרסום דיגיטלי פרסונלי?")]//..//div[contains(text(), "מלא שדה זה")]', po.longWait)) {
        po.specialClick('//label[contains(text(), "אישור מידע שיווקי למייל ול-SMS")]//..//button[contains(@class, "slds-combobox__input")]')
        func.pressTAB()
        func.pressTAB()
        func.pressENTER()
        func.pressARROW_DOWN()
        func.pressARROW_DOWN()
        func.pressENTER()
        func.pressTAB()
    }

    po.specialClick('//label[contains(text(), "אישור מכירה באמצעות")]//..//button[contains(@class, "slds-combobox__input")]')
    po.specialClick('//span[@title="מכירה מוקלטת"]')

    po.specialClick('//label[contains(text(), "אופן שליחה")]//..//button[contains(@class, "slds-combobox__input")]')
    po.specialClick('//span[@title="Mail"]')

    po.specialClick('//label[contains(text(), "אופן שליחה")]//..//button[contains(@class, "slds-combobox__input")]')
    po.specialClick('//span[@title="Mail"]')
}

po.click('//*[@aria-disabled="false" and (text()="הבא")]')
main.assertErrorDialog()

web.transaction('17. Choose Delivery by Technician')
if (web.isVisible('//span[contains(text(), "בחר אופן אספקה")]')) {
    po.specialClick('//th[@data-label="שיטת אספקה"]//lightning-base-formatted-text[contains(text(), "טכנאי")]//..//..//..//..//..//span[@class="slds-radio_faux"]')
    po.specialClick('//button[contains(text(), "מצא חלון זמן")]')
    if (!web.isVisible('(//div[contains(@class, "singleDay")])[1]', po.longWait)) {
        main.assertErrorDialog()
        po.clickUntilElementIsVisible('(//div[contains(@class, "singleDay")])[1]', '//button[contains(text(), "מצא חלון זמן")]')
    }

    web.pause(po.shortWait)
    po.specialClick('(//div[contains(@class, "singleDay")])[1]')
    po.specialClick('//span[contains(text(), "המצאות בגיר בבית")]//..//span[@class="slds-checkbox_faux"]')
}

po.click('//*[@aria-disabled="false" and (text()="הבא")]')
main.assertErrorDialog()

web.transaction('18. Order Summary')
if (web.isVisible('//div[@class="order-summary"]')) {
    po.log('info', web.getText('//div[@class="order-summary"]'))
    po.click('//*[@aria-disabled="false" and (text()="הבא")]')
    main.assertErrorDialog()
}

web.transaction('19. Payment Info')
po.click('//span[text()="הוראת קבע"]')

po.specialClick('//label[contains(text(), "בנק")]//..//button')
po.specialClick('//span[contains(text(), "ONE ZERO") or contains(@title, "ONE ZERO")]')

po.type('//label[contains(text(), "סניף בנק")]//..//input', '001')
po.specialClick('//*[contains(text(), "לקוחות - 001")]')

po.type('//label[contains(text(), "מספר חשבון בנק")]//..//input', '123456')
po.specialClick('//label[contains(text(), "אופן שליחה")]//..//button')
func.pressENTER()

web.clear('//label[contains(text(), "שלח אל")]//..//input')
po.type('//label[contains(text(), "שלח אל")]//..//input', email)

po.specialClick('//label[contains(text(), "מחזור חיוב")]//..//button')
func.pressENTER()

po.click('//button[@title="המשך"]')
main.assertErrorDialog()

web.transaction('20. Assert Order')
if (web.isVisible('//*[text()="ההזמנה נשלחה"]')) {
    po.log('success', web.getText('//div[contains(@class, "flowruntimeBody")]'))
    var newCustomerNumber = web.getText('//div[contains(@class, "flowruntimeBody")]//div[contains(text(), "מספר לקוח")]')
    newCustomerNumber = newCustomerNumber.match(/\d+/g).join('')
    po.log('success', 'New Customer Number: ' + newCustomerNumber)
} else if (web.isVisible('//*[text()=" בממשק הקמת אמצעי תשלום" or contains(text(), "ממשק שליחת טופס הוראת קבע נכשל")]')) {
    po.log('error', web.getText('//flowruntime-base-section'))
}

web.transaction(`21. Search Newly Created Customer ${newCustomerNumber}`)
if (!web.isVisible(searchPage.header, po.shortWait)) {
    po.click(main.navigationBtn)
    po.click(main.navigationOptions.customers)
    assert.equal(web.isVisible(searchPage.header), true)
}

po.click(searchPage.searchParametersBtn)
web.pause(po.shortWait)

if (!web.isVisible(searchPage.parameters.accountNumber, po.shortWait)) {
    po.click(searchPage.searchParametersBtn)
}

po.click(searchPage.parameters.accountNumber)
po.type(searchPage.accountNumberInput, newCustomerNumber)
po.click(searchPage.searchBtn)

web.transaction('22. Assert That Order Was Sent')
var customerNumberHeader = `//c-alp360-billing-info//strong[contains(text(), "מספר לקוח")]//..//..//span[contains(text(), "${newCustomerNumber}")]`

assert.equal(
    web.isExist(customerNumberHeader), true,
    `Account ${newCustomerNumber} has failed to load`
)

po.click('//li[@data-label="הזמנות"]')

if (web.isVisible(`${customerNumberHeader}//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//lightning-base-formatted-text[text()="הזמנה נשלחה"]`)) {
    po.log('success', web.getText(`${customerNumberHeader}//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//tr[@data-row-number="1"]`))
} else {
    po.log('error', `הייתה בעיה עם שליחת ההזמנה ללקוח ${newCustomerNumber}`)
}
