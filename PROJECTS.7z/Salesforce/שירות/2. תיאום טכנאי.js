log.info(`5. תהליך מכר BYOD ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url, 300)

const cases = po.cases
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const customerNumber = '245158' // '1371023' // '179617'
const repName = 'שלמה בונן'

web.transaction('04. Open Settings')
if (web.isVisible('//div[@id="wrapper-body"]//h2[contains(text(), "עדכון פרטים אישיים")]', po.longWait)) {
    po.click('//div[@id="wrapper-body"]//h2[contains(text(), "עדכון פרטים אישיים")]//..//..//..//..//..//button[contains(@title, "סגור")]')
}

if (web.isVisible('//div[contains(@class, "modal-header")]//*[contains(text(), "משהו השתבש")]', po.shortWait)) {
    po.log('warning', web.getText('(//div[contains(@class, "modal-container")]//div[contains(@class, "modal-body")])[2]'))
    po.click('//div[contains(@class, "modal-container")]//button[contains(text(), "אישור")]')
    func.refresh()
}

po.click(main.settingsButton)
po.click(main.settingsMenu.currentApp)
po.selectWindow('new')

function searchRep(name) {
    po.type(settings.mainSearchInput, name)
    func.pressENTER()
    if (web.isVisible(`(//a[contains(@class, "setupLink") and text()="${name}"])[1]`, po.shortWait)) {
        po.click(`(//a[contains(@class, "setupLink") and text()="${name}"])[1]`)
    } else if (web.isVisible(`//span[@title="${name}" and contains(@class, "mruName")]`, po.shortWait)) {
        po.click(`//span[@title="${name}" and contains(@class, "mruName")]`)
    }
}
searchRep(repName)

let tries = 15
while (!web.isVisible(`//iframe[contains(@title, "User: ${repName}")]`, po.longWait)) {
    searchRep(repName)
    if (tries == 0) break
    else tries--
}

web.transaction(`05. Login With Rep ${repName}`)
main.assertApplicationError()
web.selectFrame(`//iframe[contains(@title, "User: ${repName}")]`)
if (web.isVisible('//td[@id="topButtonRow"]//input[@name="login"]', po.shortWait)) {
    po.click('//td[@id="topButtonRow"]//input[@name="login"]')
} else {
    assert.fail(`לא מופיע כפתור כניסה לנציג\ה ${repName}`)
}

po.selectWindow('new')
main.assertApplicationError()

if (web.isVisible(`//header[@id="oneHeader"]//span[contains(text(), "כניסה בוצעה בתור ${repName}")]`, po.longWait)) {
    po.log('success', `Logged in with rep -> ${repName}`)
} else {
    po.log('warning', `Rep ${repName} is not visible`)
}

if (web.isVisible('//lightning-formatted-text[contains(text(), "ההפעלה שלך הסתיימה")]', po.longWait)) {
    po.log('warning', web.getText('//lightning-formatted-text[contains(text(), "ההפעלה שלך הסתיימה")]//..//lightning-formatted-text'))
    po.click('//button[contains(text(), "כניסה")]')
}

if (web.isVisible('id=ErrorLoadingGantt', po.longWait)) {
    po.log('error', web.getText('id=ErrorLoadingGantt'))
    func.refresh()
}

web.transaction('06. Close All Active Tabs')
main.closeAllTabs()

web.transaction(`07. Search Customer ${customerNumber}`)
if (!web.isVisible(searchPage.header, po.shortWait)) {
    po.click(main.navigationBtn)
    po.click(main.navigationOptions.customers)
    assert.equal(web.isVisible(searchPage.header), true)
}

po.click(searchPage.searchParametersBtn)
web.pause(po.shortWait)

if (!web.isVisible(searchPage.parameters.accountNumber, po.shortWait)) {
    po.click(searchPage.searchParametersBtn)
}

po.click(searchPage.parameters.accountNumber)
po.type(searchPage.accountNumberInput, customerNumber)
po.click(searchPage.searchBtn)

web.transaction('08. Create Request')
po.click(cases.createCaseBtn)

if (web.isVisible('//div[@id="wrapper-body"]//h2[contains(text(), "עדכון פרטים אישיים")]', po.longWait)) {
    po.click(cases.nextBtn)
    if (web.isVisible('//img[contains(@src, "Error")]', po.longWait)) {
        po.log('error', web.getText('(//div[@id="wrapper-body"]//flowruntime-list-container)[1]'))
        po.click(cases.finishBtn)
        po.click(cases.createCaseBtn)
    }
} else {
    po.click('(//span[contains(text(), "פניית תפעול ותמיכה")])[1]')
    po.click(cases.nextBtn)
}

if (web.isVisible(cases.finishBtn, po.shortWait)) po.click(cases.finishBtn)
if (web.isVisible(cases.createCaseBtn, po.shortWait)) po.click(cases.createCaseBtn)
if (web.isVisible(cases.nextBtn, po.shortWait)) po.click(cases.nextBtn)

if (web.isVisible('//*[contains(text(), "יש לתעד את התקלה")]', po.longWait)) {
    po.log('warning', web.getText('//*[contains(text(), "יש לתעד את התקלה")]'))
}

if (web.isVisible(`//a[@title="פתוח"]//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//a[@data-label='פק"עות']`, po.longWait)) {
    web.transaction('09. Get Technician')
    po.click(`//a[@title="פתוח"]//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//a[@data-label='פק"עות']`)
    po.click(`(//*[contains(text(), 'פק"עות פתוחות')]//..//..//..//lightning-primitive-cell-actions//button)[2]`)

    if (web.isVisible('//a[@role="menuitem"]//span[contains(text(), "עדכון תיאום")]')) {
        web.clickHidden('//a[@role="menuitem"]//span[contains(text(), "עדכון תיאום")]')
        po.click('//button[contains(text(), "מצא חלון זמן")]')
        if (!web.isVisible('(//div[contains(@class, "singleDay")])[1]', po.longWait)) {
            main.assertErrorDialog()
            po.clickUntilElementIsVisible('(//div[contains(@class, "singleDay")])[1]', '//button[contains(text(), "מצא חלון זמן")]')
        }
        web.pause(po.shortWait)
        po.click('(//div[contains(@class, "singleDay")])[1]')
        if (!web.isVisible('//lightning-spinner', po.longWait)) {
            po.click('//span[contains(text(), "המצאות בגיר בבית")]')
            po.click('//span[contains(text(), "הוסבר חיוג מטלפון")]')
            po.click('//button[@title="תאם" and not(@disabled)]')
        } else {
            po.log('error', 'Window stuck on loading after clicking on a date')

            po.click(`(//*[contains(text(), 'פק"עות  פתוחות')]//..//..//..//lightning-primitive-cell-actions//button)[2]`)
            po.click('//a[@role="menuitem"]//span[contains(text(), "עדכון תיאום")]')
            po.click('//button[contains(text(), "מצא חלון זמן")]')
            if (!web.isVisible('(//div[contains(@class, "singleDay")])[1]', po.longWait)) {
                main.assertErrorDialog()
                po.clickUntilElementIsVisible('(//div[contains(@class, "singleDay")])[1]', '//button[contains(text(), "מצא חלון זמן")]')
            }
            web.pause(po.shortWait)
            po.click('(//div[contains(@class, "singleDay")])[1]')
        }
    } else if (web.isVisible('//a[@role="menuitem"]//span[contains(text(), "תיאום טכנאי")]')) {
        web.clickHidden('//a[@role="menuitem"]//span[contains(text(), "תיאום טכנאי")]')
        po.click('//*[contains(text(), "בחר אופן אספקה")]//..//..//..//..//..//lightning-base-formatted-text[contains(text(), "טכנאי")]//..//..//..//..//..//label[contains(@id, "radio")]')

        if (web.isVisible('//span[contains(text(), "בחר אופן אספקה")]')) {
            po.click('//th[@data-label="שיטת אספקה"]//lightning-base-formatted-text[contains(text(), "טכנאי")]//..//..//..//..//..//span[@class="slds-radio_faux"]')
            po.click('//button[contains(text(), "מצא חלון זמן")]')
            if (!web.isVisible('(//div[contains(@class, "singleDay")])[1]', po.longWait)) {
                main.assertErrorDialog()
                po.clickUntilElementIsVisible('(//div[contains(@class, "singleDay")])[1]', '//button[contains(text(), "מצא חלון זמן")]')
            }
            web.pause(po.shortWait)
            po.click('(//div[contains(@class, "singleDay")])[1]')
            if (!web.isVisible('//lightning-spinner', po.longWait)) {
                po.click('//span[contains(text(), "המצאות בגיר בבית")]')
                po.click('//span[contains(text(), "הוסבר חיוג מטלפון")]')
                po.click('//button[@title="תאם" and not(@disabled)]')
            } else {
                po.log('error', 'Window stuck on loading after clicking on a date')

                po.click('//a[@role="menuitem"]//span[contains(text(), "תיאום טכנאי")]')
                po.click('//*[contains(text(), "בחר אופן אספקה")]//..//..//..//..//..//lightning-base-formatted-text[contains(text(), "טכנאי")]//..//..//..//..//..//label[contains(@id, "radio")]')
                po.click('//th[@data-label="שיטת אספקה"]//lightning-base-formatted-text[contains(text(), "טכנאי")]//..//..//..//..//..//span[@class="slds-radio_faux"]')
                po.click('//button[contains(text(), "מצא חלון זמן")]')
                if (!web.isVisible('(//div[contains(@class, "singleDay")])[1]', po.longWait)) {
                    main.assertErrorDialog()
                    po.clickUntilElementIsVisible('(//div[contains(@class, "singleDay")])[1]', '//button[contains(text(), "מצא חלון זמן")]')
                }
                web.pause(po.shortWait)
                po.click('(//div[contains(@class, "singleDay")])[1]')
                po.click('//span[contains(text(), "המצאות בגיר בבית")]')
                po.click('//span[contains(text(), "הוסבר חיוג מטלפון")]')
                po.click('//button[@title="תאם" and not(@disabled)]')
            }
        }

        po.type('//input[@name="contactName"]', 'שם לתיאום אספקה')
        po.click('//span[contains(text(), "המצאות בגיר בבית")]')
        po.click('//span[contains(text(), "הוסבר חיוג מטלפון")]')
        po.click('//label[contains(text(), "סיבת בחירת החלון")]//..//button')
        po.click('//span[@title="בקשת לקוח"]')
        po.click('//button[@title="תאם" and not(@disabled)]')
    } 
    
    if (web.isVisible('//span[contains(text(), "הושלם בהצלחה")]')) {
        po.log('success', 'תיאום טכנאי הושלם בהצלחה')
        po.click('//button[contains(text(), "סיים")]')
        assert.pass()
    } else {
        assert.fail('הייתה תקלה בתיאום טכנאי')
    }
} else {
    if (web.isVisible('//h2[contains(text(), "קיים תיק פתוח")]', po.longWait)) {
        po.log('warning', web.getText('//h2[contains(text(), "קיים תיק פתוח")]//..//..//..//..//div[@class="modal-content"]'))
    }

    po.click('//label[contains(text(), "סוג תקלה")]//..//input')
    po.click('//label[contains(text(), "סוג תקלה")]//..//li[@class="slds-listbox__item"]//span[contains(text(), "תקלה מלאה")]')

    po.click('//label[contains(text(), "אבחון משני")]//..//input')
    po.click('(//label[contains(text(), "אבחון משני")]//..//li[@class="slds-listbox__item"])[1]')

    po.click('//span[contains(text(), "לא בוצע תפעול")]')

    po.click('//label[contains(text(), "סיבה")]//..//input')
    po.click('//label[contains(text(), "סיבה")]//..//li[@class="slds-listbox__item"]//span[contains(text(), "לקוח מסרב לתפעל")]')

    po.click('//label[contains(text(), "תוצאה")]//..//input')
    po.click('//label[contains(text(), "תוצאה")]//..//li[@class="slds-listbox__item"]//span[contains(text(), "נדרש טיפול טכנאי")]')

    web.pause(po.shortWait)
    po.click('//button[contains(text(), "שמור תקלה")]')
    main.assertErrorDialog()

    if (web.isVisible('//div[@class="slds-modal__container change-alias-modal"]', po.shortWait)) {
        po.click('//div[@class="slds-modal__container change-alias-modal"]//button[@title="Yes"]')
    }

    web.transaction(`09. Search Customer ${customerNumber}`)
    if (!web.isVisible(searchPage.header, po.shortWait)) {
        po.click(main.navigationBtn)
        po.click(main.navigationOptions.customers)
        assert.equal(web.isVisible(searchPage.header), true)
    }

    po.click(searchPage.searchParametersBtn)
    web.pause(po.shortWait)

    if (!web.isVisible(searchPage.parameters.accountNumber, po.shortWait)) {
        po.click(searchPage.searchParametersBtn)
    }

    po.click(searchPage.parameters.accountNumber)
    po.type(searchPage.accountNumberInput, customerNumber)
    po.click(searchPage.searchBtn)

    if (web.isVisible(`//th[@data-label="מספר לקוח משלם"]//a[contains(text(), "${customerNumber}")]`, po.longWait)) po.click(`//th[@data-label="מספר לקוח משלם"]//a[contains(text(), "${customerNumber}")]`)
    if (web.isVisible(`//div[contains(text(), "${customerNumber}")]`, po.longWait)) po.click(`//div[contains(text(), "${customerNumber}")]`)

    web.transaction('10. Assert Created Request')
    po.click(alpha360.pakaList)
    main.assertErrorDialog()

    assert.equal(
        web.isExist('(//lightning-base-formatted-text[contains(text(), "תקלה")])[1]'), true,
        `לא נוצרה תקלה אצל לקוח מספר: ${customerNumber}`
    )
}
