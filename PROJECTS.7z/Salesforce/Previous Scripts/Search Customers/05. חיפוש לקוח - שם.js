log.info(`05. חיפוש לקוח - שם (${env.name != 'default' ? `${env.name} סביבת` : ''})`)
po.init(env.url, 120)

const main = po.alphaMainPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360

web.transaction('04. Close All Active Tabs')
main.closeAllTabs()

web.transaction('05. Navigate To Search Account Page')
if (!web.isVisible(searchPage.header, po.shortWait)) {
    po.click(main.navigationBtn)
    po.click(main.navigationOptions.customers)
    assert.equal(web.isVisible(searchPage.header), true)
}

web.transaction('06. Select Customer By Name')
var name = main.customerName.split(' ')
const firstName = name[0]
const lastName = name[1]

po.click(searchPage.searchParametersBtn)
web.pause(po.shortWait)

if (!web.isVisible(searchPage.parameters.name, po.shortWait)) {
    po.click(searchPage.searchParametersBtn)
}

po.click(searchPage.parameters.name)
po.type(searchPage.firstNameInput, firstName)
po.type(searchPage.lastNameInput, lastName)

web.transaction('07. Search Customer')
po.click(searchPage.searchBtn)

web.transaction('08. Assert Customer Details')
assert.equal(
    web.isExist(`//c-alp360-header-container//strong[text()="${main.customerName}"]`), true,
    `Customer ${main.customerName} has failed to load`
)

assert.equal(
    web.isExist(`//div[text()="${main.accountNumber}"]`), true,
    `Account ${main.accountNumber} has failed to load`
)

alpha360.loadCustomerDetails()