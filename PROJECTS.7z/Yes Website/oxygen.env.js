module.exports = {

    default: {
        name: 'default',
        url: 'https://www.yes.co.il'
    },

    prep: {
        name: 'PREP',
        url: 'https://pre.yes.co.il',
        username: 'Naamahaim901@gmail.com',
        password: 'Aa123456',
    },

    prod: {
        name: 'PROD',
        url: 'https://www.yes.co.il',
        username: 'Lshtern@promotheus.tv', // 'LShtern@Yesdbs.onmicrosoft.com',
        password: 'EliN1234', // 'Autom8ion',
    },

}
