const currentDate = () => {
    let today = new Date()
    let dd = String(today.getDate()).padStart(2, "0")
    let mm = String(today.getMonth() + 1).padStart(2, "0")
    let yyyy = today.getFullYear()
    let min = today.getMinutes()
    let sec = today.getSeconds()
    return `${dd}.${mm}.${yyyy}-${min}m-${sec}s`
}

const os = require('os')
const fs = require('fs')
const fileName = 'hitsByUsersReport.xlsx'
const newFileName = `hitsByUsersReport_${currentDate()}.csv`
const downloadsPath = os.userInfo().homedir + '\\downloads'
const downloadedReportFile = downloadsPath + '\\' + fileName
const destinationFolder = '\\\\filesrv05\\infashared\\kms'
const destinationFile = destinationFolder + '\\' + newFileName
// const newDownloadedReportFile = downloadsPath + '\\' + newFileName

if (fs.existsSync(downloadedReportFile)) fs.unlinkSync(downloadedReportFile)

web.transaction('Open YESCM')
web.init()
web.open('https://yescm.lighthouse-cloud.com/kms/lh/login')

web.transaction('Login')
web.type('id=login-username', 'sgustus')
web.type('id=login-password', '0qNyBS2wHCFZ')
web.click('id=kms-login-button')

web.transaction('Login With Informant')
web.click('id=kms-login-to-layout-button')

web.transaction('Open Reports')
web.point('(//header//span[text()="דוחות"])[1]')
web.clickHidden('(//a[contains(@onclick, "/INTERNAL/REPORTS")])[1]')

web.transaction('Open Reports')
web.selectFrame('id=itemscope')
web.click(`//a[contains(text(), 'דוח צפיות במערכת ע"פ משתמש')]`)

web.transaction('Run Report')
web.click('id=goButton')

web.transaction('Save Report')
web.click('id=save-to-excel-button-image')
web.pause(10 * 1000)

if (!fs.existsSync(downloadedReportFile)) {
    log.info('הקובץ לא ירד בלחיצה הראשונה')
    web.click('id=save-to-excel-button-image')
    web.pause(5000)
}

if (fs.existsSync(downloadedReportFile)) {
    web.transaction(`Convert ${fileName} To CSV`)
    const xlsxData = utils.readXlsx(downloadedReportFile)
    const headers = Object.keys(xlsxData[0])
    const csvRows = []

    csvRows.push(headers.join(','))
    xlsxData.forEach(item => {
    const values = headers.map(header => item[header])
    csvRows.push(values.join(','))
    })

    const csvString = '\uFEFF' + csvRows.join('\n')
    fs.writeFileSync(destinationFile, csvString, { encoding: 'utf8' })

    if (fs.existsSync(destinationFile)) {
        log.info(`קובץ נשמר בהצלחה ${destinationFile}`)
        fs.unlinkSync(downloadedReportFile)
    } else {
        assert.fail(`הקובץ לא הועבר לנתיב ${destinationFolder}`)
    }
} else {
    assert.fail('הקובץ לא נשמר')
}

// if (fs.existsSync(downloadedReportFile)) {
//     fs.renameSync(downloadedReportFile, newDownloadedReportFile)
//     fs.copyFileSync(newDownloadedReportFile, destinationFile)
//     if (fs.existsSync(destinationFile)) {
//         log.info(`קובץ נשמר בהצלחה ${destinationFile}`)
//         fs.unlinkSync(newDownloadedReportFile)
//     } else {
//         assert.fail(`הקובץ לא הועבר לנתיב ${destinationFolder}`)
//     }
// } else {
//     assert.fail('הקובץ לא נשמר')
// }
