module.exports = {

    shortWait: 3000,
    longWait: 15000,
    waitASecond: 1000,
    waitHalfASecond: 500,
    waitHalfAMinute: 30 * 1000,
    waitOneMinute: 60 * 1000,
    waitTwoMinutes: 120 * 1000,
    waitThreeMinutes: 180 * 1000,
    waitSixMinutes: 540 * 1000,

    dataFolder: require('path').join(__dirname, '/Data'),

    init: (url) => {    
        web.transaction('Initialize ChromeDriver')
        web.init({
            browserName: 'chrome',
            'goog:chromeOptions': {
                args: [
                    '--disable-notifications',
                    // '--enable-strict-powerful-feature-restrictions',
                    // '--disable-web-security',
                    // '--user-data-dir flags',
                    // '--incognito',
                ]
            }
        })

        web.transaction('Open Login Page')
        web.open(`https://${env.username}:${env.password}@${url.split('https://')[1]}`)
        web.setTimeout(po.waitTwoMinutes)

        if (web.isVisible('id=main', po.longWait)) {
            web.transaction(`Login To -> ${url}`)    
            web.type('id=username', env.username)
            web.type('id=password', env.password) 
            web.click('id=Login')

            if (web.isVisible('//div[@class="loginError" and contains(text(), "Please check your username and password")]', po.shortWait)) {
                assert.fail(web.getText('//div[@class="loginError" and contains(text(), "Please check your username and password")]'))
            }
        } else {
            log.info(`Skipped login at ${env.name} environment`)
        }
        
        if (web.isVisible('id=error', po.shortWait)) {
            assert.fail(web.getText('id=error'))
        } else if (web.isVisible('//span[text()="תחזוקה מתוכננת"]', po.shortWait)) {
            po.log('warning', web.getText('//div[@id="message"]'))
            web.click('//a[contains(text(), "הבנתי")]')
        } else if (web.isVisible('//a[contains(@href, "AddPhoneNumber")]', po.shortWait)) {
            web.click('//a[contains(@href, "AddPhoneNumber")]')
        } else if (web.isVisible('//header[contains(@class, "slds-theme_error")]', po.shortWait)) { 
            let error = web.getText('//header[contains(@class, "slds-theme_error")]//..//div[contains(@class, "slds-modal__content")]') 
            po.log('error', `${error} in ${env.url}`)
            web.click('//header[contains(@class, "slds-theme_error")]//..//button[text()="Continue"]')
        } else if (web.isVisible('//div[contains(text(), "בדוק את החיבור שלך לאינטרנט")]', po.shortWait)) {
            web.isVisible('//span[contains(text(), "נסה שוב")]', po.shortWait) && web.click('//span[contains(text(), "נסה שוב")]')
            web.refresh()
        } else if (web.isVisible('(//h1[contains(text(), "מצטערים להפריע")])[1]', po.shortWait)) {
            web.click('(//h1[contains(text(), "מצטערים להפריע")]//..//..//button[@title="אישור"])[1]')
        } else if (web.isVisible('//div[contains(@class, "modal-header")]//*[contains(text(), "משהו השתבש")]', po.shortWait)) {
            po.log('warning', web.getText('//div[contains(@class, "modal-container")]//div[contains(@class, "modal-body")]'))
            web.click('//div[contains(@class, "modal-container")]//button[contains(text(), "אישור")]') 
        } else if (web.isVisible('//*[@id="header" and contains(text(), "שנה את סיסמתך")]', po.shortWait)) {
            po.log('warning', `${env.username} :נדרש לשנות את הסיסמה ליוזר`)

            let oldPassword = env.password
            let letters = oldPassword.split(oldPassword.replace(/\D/g, ''))[0]
            let numbers = parseInt(oldPassword.replace(/\D/g, '')) 
            let newPassword = letters + (numbers + 1)

            web.type('id=newpassword', newPassword)
            web.type('id=confirmpassword', newPassword)
            web.click('//button[@id="password-button" and not(@disabled)]')
            po.log('success', `${newPassword} :סיסמה חדשה .${env.username} :הסיסמה השתנתה בהצלחה ליוזר`)
        } 
        
        if (!web.isVisible('id=oneHeader', po.longWait)) {
            for (let x = 0; x < 10; x++) {
                web.refresh()
                if (!web.isVisible('id=oneHeader', po.longWait)) 
                    continue
                    
                assert.equal(
                    web.isVisible('id=oneHeader'), true,
                    `Main page has failed to load at ${env.name} environment`
                )
                break
            }
        }

        let main = po.alphaMainPage
        let appName = web.getAttribute(main.appNameTab, 'title')
        po.log('info', `Current App: ${appName}`)

        if (appName != 'אלפא' || appName != 'yes') {
            web.click(main.appMenuBtn)
            web.type(main.appMenuSearchInput, 'yes')
            po.functions.pressENTER()
        }

        main.assertApplicationError()
        main.updatePersonalDetailsError(env.email)
    },

    /* functions */
    
    functions: {
        // Create Israeli ID Number
        createTzNumber: () => {
            var tzNumber
            while (true) {
                var tz = []
                for (var i = 0; i < 9; i++) {
                    tz.push(Math.floor(Math.random() * 10))
                }

                var weights = []
                var mul = 1
                for (var i = 0; i < 9; i++) {
                    weights.push(mul)
                    mul = mul == 1 ? 2 : 1
                }

                var tzWeighted = []
                for (var i = 0; i < 9; i++) {
                    tzWeighted.push(tz[i] * weights[i])
                }

                for (var i = 0; i < 9; i++) {
                    var num = tzWeighted[i].toString()
                    if (num.length === 2) {

                        var d1 = parseInt(num.substring(0, 1))
                        var d2 = parseInt(num.substring(1))
                        tzWeighted[i] = d1 + d2
                    }
                }

                var sum = 0
                for (var i = 0; i < 9; i++) {
                    sum += tzWeighted[i]
                }

                if (sum % 10 === 0) {
                    tzNumber = tz.join('')
                    break
                }
            }
            return tzNumber
        },

        currentDate: (date) => {
            let today = date ? new Date(date) : new Date()
            let dd = String(today.getDate()).padStart(2, "0")
            let mm = String(today.getMonth() + 1).padStart(2, "0")
            let yyyy = today.getFullYear()

            if (dd.charAt(0) == '0') dd = dd.replace('0', '')
            mm = mm.charAt(0) == '0' ? mm.replace('0', '') : mm

            return `${dd}.${mm}.${yyyy}`
        },

        futureDate: (days) => {
            var targetDate = new Date()
            targetDate.setDate(targetDate.getDate() + days)
            return po.functions.currentDate(targetDate)
        },

        getDay: (date) => {
            let day = date.slice(0, 2)
            return day < 10 ? day.substr(1) : day
        },

        getYear: () => {
            return new Date().getFullYear()
        },

        generateNumber: (min, max) => {
            return Math.floor(Math.random() * (max - min + 1) + min)
        },

        generatePhone: () => {
            let pre = ['050', '052', '054']
            return String(
                pre[Math.floor(Math.random() * pre.length)]
                + Math.random().toString().slice(2, 9)
            )
        },

        generateEmail: () => {
            let domains = ['gmail', 'hotmail', 'yahoo', 'live', 'gmx']
            return po.functions.generateName().toLowerCase()
                   + '@' + domains[Math.floor(Math.random() * domains.length) + 1] + '.com'
        },
        
        generateName: () => {
            let capitalize = (string) => {
                return string.charAt(0).toUpperCase() + string.slice(1)
            }
            let names = ['ben', 'iris', 'erez', 'shani', 'eli', 'nati']
            return capitalize(names[po.functions.generateNumber(0, names.length - 1)]) 
        },

        convertDateWithTimeFromDB: (date) => {
            date = date.slice(0, 10)
            let day = date.slice(8, 10)
            let month = date.slice(5, 7)
            let year = date.slice(0, 4)

            switch (month) {
                case 'JAN':
                    month = '01'
                    break
                case 'FEB':
                    month = '02'
                    break
                case 'MAR':
                    month = '03'
                    break
                case 'APR':
                    month = '04'
                    break
                case 'MAY':
                    month = '05'
                    break
                case 'JUN':
                    month = '06'
                    break
                case 'JUL':
                    month = '07'
                    break
                case 'AUG':
                    month = '08'
                    break
                case 'SEP':
                    month = '09'
                    break
                case 'OCT':
                    month = '10'
                    break
                case 'NOV':
                    month = '11'
                    break
                case 'DEC':
                    month = '12'
                    break
                default: 
                    month = month
                    break
            }
            return day + '/' + month + '/' + year
        },

        convertDateFromDB: (date) => {
            let day = date.slice(0, 2)
            let month = date.slice(3, 6)
            let year = date.slice(7)

            switch (month) {
                case 'JAN':
                    month = '01'
                    break
                case 'FEB':
                    month = '02'
                    break
                case 'MAR':
                    month = '03'
                    break
                case 'APR':
                    month = '04'
                    break
                case 'MAY':
                    month = '05'
                    break
                case 'JUN':
                    month = '06'
                    break
                case 'JUL':
                    month = '07'
                    break
                case 'AUG':
                    month = '08'
                    break
                case 'SEP':
                    month = '09'
                    break
                case 'OCT':
                    month = '10'
                    break
                case 'NOV':
                    month = '11'
                    break
                case 'DEC':
                    month = '12'
                    break
                default: 
                    month = month
                    break
            }
            return day + '/' + month + '/' + year
        },
		
		/* https://www.selenium.dev/selenium/docs/api/rb/Selenium/WebDriver/Keys.html */
		
        pressENTER: () => {
            web.pause(po.waitASecond)
            web.sendKeys('\uE007')
            web.pause(po.waitASecond)
        },

        pressTAB: () => {
            web.pause(po.waitASecond)
            web.sendKeys('\uE004')
            web.pause(po.waitASecond)
        },

		pressSPACE: () => {
            web.pause(po.waitASecond)
            web.sendKeys('\uE00D')
            web.pause(po.waitASecond)
        },
		
        pressARROW_DOWN: () => {
            web.pause(po.waitASecond)
            web.sendKeys('\uE015')
            web.pause(po.waitASecond)
        },

        pressESCAPE: () => {
            web.pause(po.waitASecond)
            web.sendKeys('\uE00C')
            web.pause(po.waitASecond)
        },

        pressBACKSPACE: () => {
            web.sendKeys('\uE003')
        },
    }, /* end of functions */
                                                                                                                                                                             
    clickUntilElementIsVisible: (elementToBeVisible, elementToClick) => {
        let tries = 5
        while (!web.isVisible(elementToBeVisible, po.shortWait)) {
            web.pause(po.waitASecond)
            if (web.isVisible(elementToClick, po.shortWait)) {
                 web.click(elementToClick)
            }
            if (tries == 0) break
            else tries--
        }
    },

    type: (element, text) => {
        po.specialClick(element)
        web.type(element, text)
    },

    specialClick: (element) => {
        web.pause(po.waitASecond)
        if (web.isVisible(element)) {
            // if element is using oxygen syntax convert to get by id else use xpath
            if (element.includes('id=') && !element.includes('@id=')) {
                element = element.replace('id=', '')
                web.execute((element) => {
                    document.getElementById(element).click()
                }, element)
            } else {
                web.execute((element) => {
                    document.evaluate(
                        element, document, null,
                        XPathResult.FIRST_ORDERED_NODE_TYPE, null
                    ).singleNodeValue.click()
                }, element)
            }
        }
    },

    specialType: (element, text) => {
        po.specialClick(element)
        web.pause(po.waitASecond)
        if (web.isVisible(element, po.longWait)) {
            if (element.includes('id=')) {
                element = element.replace('id=', '')
                web.execute((element) => {
                    document.getElementById(element).value = text
                }, element)
            } else {
                web.execute((element, text) => {
                    document.evaluate(
                        element, document, null,
                        XPathResult.FIRST_ORDERED_NODE_TYPE, null
                    ).singleNodeValue.value = text
                }, element, text)
            }
        }
    },

    selectWindow: (tab) => {
        let currentWindows = web.getWindowHandles()

        if (tab == 'current') {
            web.selectWindow(currentWindows[0])
        }

        if (tab == 'new') {
            if (currentWindows.length === 1) web.selectWindow(currentWindows[0])
            if (currentWindows.length === 2) web.selectWindow(currentWindows[1])
        }

        if (tab == 'third') web.selectWindow(currentWindows[2])
    },

    log: (type, message) => { 
        if (type == 'info') log.info(`🛈 ${message}`)
        if (type == 'error') log.info(`❌ ${message}`)
        if (type == 'warning') log.info(`⚠️ ${message}`)
        if (type == 'success') log.info(`✔️ ${message}`)
    },

    database: {
        getAddress: () => {
            db.setConnectionString(env.wiz_con_string)
            po.log('success', `Connected to: ${env.wiz_con_string}`)

            let getAddressQuery = 
            `   
                SELECT TO_NCHAR(Y.City), TO_NCHAR(Y.Street_Name), TO_NCHAR(Y.Street_Number), 
                TO_NCHAR(Y.ENTRANCE), TO_NCHAR(Y.Unit_Number), TO_NCHAR(Y.Dwelling_Type)
                FROM wiz_hp_description Y
                WHERE Y.Wired = 'Y'
                AND Y.Drop_Location = '1'
                AND Y.Delete_Record <> 'Y'
                and Y.Unit_Number <> '        '
                AND Y.Service_Address_Id NOT IN (SELECT L.SERVICE_ADDRESS_ID from wiz_customer_hp_life L)
                AND Y.Service_Address_Id NOT IN (SELECT W.SERVICE_ADDRESS_ID from wiz_work_order W)
                AND ROWNUM <= 99
            `
            let address = db.executeQuery(getAddressQuery)
            for (let x = 0; x < address.length; x++) {
                let randomQuery = po.functions.generateNumber(1, address.length)
                if (address[randomQuery] === null || address[randomQuery] === undefined|| address[randomQuery] === 'undefined') {
                    po.log('warning', `Address query at index ${randomQuery} is undefined`)
                    continue
                } else {
                    let apartmentNumber = Object.values(address[randomQuery])[4]
                    let houseNumber = Object.values(address[randomQuery])[2]

                    if (apartmentNumber.match(/[א-ת]/) || houseNumber.match(/[א-ת]/)) {
                        po.log('warning', `Address number includes letters: Apartment Number ${apartmentNumber}, House Number: ${houseNumber}`)
                        continue
                    } else {
                        po.log('success', 'Data: ' + JSON.stringify(address[randomQuery]))
                        return Object.values(address[randomQuery])
                    }
                }
            }
        }
    },

    /* login screen */
    loginScreen: {
        loginBtn: 'id=Login',
        usernameField: 'id=username',
        passwordField: 'id=password',
        addPhoneNumber: '//h2[contains(text(), "רשום את הטלפון הנייד שלך")]',
        changePassword: '//div[contains(@class, "change-password")]',
    },

    /* alpha 360 */
    alphaMainPage: {

        customerId: '301292892',
        customerName: 'כפיר ואלינה מדמוני',
        accountNumber: '6086284',
        phoneNumber: '0545644404',
        device: 'A76559450000BE3F',

        globalActionsButton: '//ul[@class="slds-global-actions"]//a[contains(@class, "globalCreateTrigger")]',
        globalActionsMenu: {
            createLead: '//a[@role="menuitem" and @title="יצירת ליד"]',
            createNewCustomer: '//a[@role="menuitem" and @title="הקמת לקוח חדש"]',
        },

        settingsButton: '//div[@data-aura-class="setupGear"]',
        settingsMenu: {
            currentApp: '//a[@role="menuitem" and @title="הגדרות"]',
        },

        appNameTab: '//*[contains(@class, "appName")]//span',
        leadsTab: '//div[@data-aura-class="navexConsoleNav"]//a[@title="לידים"]',
        openMainSearchButton: '//div[@data-aura-class="forceSearchAssistant"]',
        mainSearchInput: '//input[@title="חפש בהגדרות" or @placeholder="חיפוש..."]',
        closeTabButton: '//a[@role="tab" and not(contains(@href, "Dashboard"))]//..//*[name()="svg" and @data-key="close"]',
        tabArrowDownButton: '//div[contains(@class, "tabActionsList")]//*[name()="svg" and @data-key="chevrondown"]',
        tabCloseCardButton: '//div[contains(@class, "slds-dropdown")]//*[@title="סגור כרטיסייה"]',
        toastText: '//*[contains(@class, "forceActionsText")]',
        errorToastMessage: '//div[@data-key="error" and @role="alertdialog" or @data-aura-class="forceToastMessage"]',
        errorToastMessageCloseButton: '//div[@data-key="error" and @role="alertdialog" or @data-aura-class="forceToastMessage"]//lightning-icon[@icon-name="utility:close"]',
        newButton: '//a[@class="forceActionLink"]//div[@title="חדש/ה" or @title="יצירת ליד חדש"]',
        nextButton: '//*[text()="הבא" or text()="Next"]',
        nextButtonNotDisabled: '//*[@aria-disabled="false" and (text()="הבא" or text()="Next")]',

        appMenuBtn: '//div[@role="navigation"]//button',
        appMenuSearchInput: '//one-app-launcher-search-bar//input',
        appMenuOptions: {
            alpha: '//one-app-launcher-menu-item//a[@data-label="אלפא"]',
            salesConsole: '//div[contains(@class, "appLauncherMenu")]//*[contains(text(), "Sales Console")]',
        },

        navigationBtn: '//button[contains(@title, "תפריט ניווט") or contains(@title, "Navigation")]', 
        navigationOptions: {
            home: '//div[@id="navMenuList"]//a[@data-itemid="Home"]',
            customers: '//div[@id="navMenuList"]//a[@data-itemid="Alpha_Search"]',
            leads: '//div[@id="navMenuList"]//a[@data-itemid="Lead"]',
            contacts: '//div[@id="navMenuList"]//a[@data-itemid="Contact"]',
            accounts: '//div[@id="navMenuList"]//a[@data-itemid="Account"]',
            fieldServices: '//div[@id="navMenuList"]//a[contains(@data-itemid, "FieldService")]',
            services: '//div[@id="navMenuList"]//a[@data-itemid="ServiceAppointment"]',
            actions: '//div[@id="navMenuList"]//a[@data-itemid="WorkOrder"]'
        }, 

        closeTabs: (action) => {
            web.setTimeout(po.waitHalfAMinute)

            let closeTabButton = po.alphaMainPage.closeTabButton
            let tabsPresent = web.getElementCount(closeTabButton)
            let closedTabs = 0

            if (tabsPresent == 0) {
                return
            } 

            if (action == 'close last tab') {
                if (tabsPresent > 1) {
                    web.isVisible(`(${closeTabButton})[${tabsPresent}]`) && web.click(`(${closeTabButton})[${tabsPresent}]`)
                    po.log('info', `Closed last tab at index -> (${tabsPresent})`)
                }
                return
            }

            if (action == 'keep last tab') {
                if (tabsPresent == 1) return
                for (let x = tabsPresent; x <= tabsPresent; x--) {
                    web.isVisible(`(${closeTabButton})[${x}]`) && web.click(`(${closeTabButton})[${x}]`)
                    closedTabs++
                }
                po.log('info', `Closed ${closedTabs} tabs except last one`)
                return
            }

            for (let x = tabsPresent; x <= tabsPresent; x--) {
                if (x == 0) {
                    break
                } else {
                    web.pause(po.shortWait)
                    if (web.isVisible(`(${closeTabButton})[${x}]`, po.shortWait)) {
                        web.click(`(${closeTabButton})[${x}]`)
                    }
                    closedTabs++
                }
            }

            po.log('info', `Closed ${closedTabs} of ${tabsPresent} tab(s)`)
            web.setTimeout(po.waitTwoMinutes)
        },

        openSearchPage: () => {
            let main = po.alphaMainPage

            if (web.isVisible(main.navigationBtn, po.shortWait)) {
                web.click(main.navigationBtn)
                web.click(main.navigationOptions.customers)
            } else {
                web.click(main.appMenuBtn)
                web.click(main.appMenuOptions.alpha)
                web.click(main.navigationBtn)
                web.click(main.navigationOptions.customers)
            }

            if (web.isVisible(po.searchCustomerPage.header, po.shortWait)) {
                return
            } else {
                web.click(main.navigationBtn)
                web.click(main.navigationOptions.customers)
                assert.equal(web.isVisible(po.searchCustomerPage.header), true)
            }
        },

        openLeads: () => {
            let start = Date.now()
            let limit = 1 * 60 * 1000
            let main = po.alphaMainPage
            while (((Date.now() - start) < limit) && !web.isVisible(main.leadsTab, po.shortWait)) {
                web.click(main.navigationBtn)
                web.click(main.navigationOptions.leads)
            }
        },

        updatePersonalDetailsError: (emailToUpdate) => {
            if (web.isVisible('//div[@id="wrapper-body"]//h2[contains(text(), "עדכון פרטים אישיים")]', po.longWait)) {
                if (web.isVisible('//*[contains(text(), "כתובת המייל של הלקוח שגויה")]', po.shortWait)) {
                    web.type('//span[contains(text(), "דואר אלקטרוני")]//..//..//..//input', emailToUpdate)
                    po.log('success', `Updated email to: ${emailToUpdate}`)
                }
                web.click('//div[@id="wrapper-body"]//h2[contains(text(), "עדכון פרטים אישיים")]//..//..//..//..//..//button[contains(@title, "סגור")]')
            }
        },

        assertApplicationError: () => {
            if (web.isVisible('//h1[contains(text(), "מצטערים להפריע")]', po.longWait)) {
                web.click('//h1[contains(text(), "מצטערים להפריע")]//..//..//button[@title="אישור"]')
            } 
            
            if (web.isVisible('(//div[@data-aura-class="oneApplicationError"])[1]', po.shortWait)) {
                web.click('(//div[@data-aura-class="oneApplicationError"]//span[text()="עניינים טכניים"])[1]')
                po.log('warning', web.getValue('(//div[@data-aura-class="oneApplicationError"]//span[text()="עניינים טכניים"]//..//..//..//textarea)[1]'))
                web.refresh()
            }

            if (web.isVisible('//lightning-formatted-text[contains(text(), "ההפעלה שלך הסתיימה")]', po.shortWait)) {
                po.log('warning', web.getText('//lightning-formatted-text[contains(text(), "ההפעלה שלך הסתיימה")]//..//lightning-formatted-text'))
                web.click('//button[contains(text(), "כניסה")]')
            }

            if (web.isVisible('id=ErrorLoadingGantt', po.shortWait)) {
                po.log('error', web.getText('id=ErrorLoadingGantt'))
                web.refresh()
            }

            if (web.isVisible(`//span[@class="toastMessage forceActionsText" and contains(text(), 'קיימת פק"ע פתוחה עבור כתובת זו')]`, po.shortWait)
            || web.isVisible(`//span[@class="toastMessage forceActionsText" and contains(text(), 'שגיאה כללית')]`, po.shortWait)) {
                assert.fail(web.getText(`//span[@class="toastMessage forceActionsText"]`))
            }
        },

        assertErrorDialog() { 
            let main = po.alphaMainPage
            if (web.isVisible(main.errorToastMessage, po.longWait)) {
                let dialogs = web.getElementCount(main.errorToastMessage)
                for (let x = 1; x <= dialogs; x++) {
                    po.log('error', web.getText(`(${main.errorToastMessage})[${x}]`))
                }
            }

            if (web.isVisible(main.errorToastMessage, po.shortWait) && web.isVisible(main.nextButtonNotDisabled, po.shortWait)) {
                if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
            }
        },

        openSettings: () => {
            if (web.isVisible('//div[contains(@class, "modal-header")]//*[contains(text(), "משהו השתבש")]', po.shortWait)) {
                po.log('warning', web.getText('//div[contains(@class, "modal-container")]//div[contains(@class, "modal-body")]'))
                web.click('//div[contains(@class, "modal-container")]//button[contains(text(), "אישור")]')
                web.refresh()
            } else if (web.isVisible('//h1[contains(text(), "מצטערים להפריע")]', po.shortWait)) {
                web.click('//h1[contains(text(), "מצטערים להפריע")]//..//..//button[@title="אישור"]')
            } else if (web.isVisible(po.alphaMainPage.settingsButton, po.longWait)) {
                po.clickUntilElementIsVisible(po.alphaMainPage.settingsMenu.currentApp, po.alphaMainPage.settingsButton)
                web.click(po.alphaMainPage.settingsMenu.currentApp)
                web.selectWindow('title=דף הבית | Salesforce')
            }
        },

        loginAsContractor: (contractorCompany, contractorName, page) => {
            po.selectWindow('new')

            let tries = 5
            while (!web.isVisible('//button[@title="בחר תצוגת רשימה: חשבונות"]', po.longWait) || tries > 0) {
                po.specialClick(po.alphaMainPage.navigationBtn)
                web.clickHidden(po.alphaMainPage.navigationOptions.accounts)
                tries--
            }

            web.click('//button[@title="בחר תצוגת רשימה: חשבונות"]')
            web.click('//span[contains(text(), "קבלני SFS")]')
            po.specialClick(`//table//a[@title="${contractorCompany}"]`)
            po.specialClick('//a[contains(@href, "/Contacts/view")]//span[contains(text(), "הצג הכול")]')
            web.pause(po.shortWait)

            let scrollTries = 15
            while (!web.isVisible(`//slot[contains(text(), "${contractorName}")]`, po.waitASecond)) {
                web.execute(() => {
                    document.evaluate(
                        '//*[@title="אנשי קשר"]//..//..//..//..//..//..//div[@class="slds-scrollable_y"]', document, null,
                        XPathResult.FIRST_ORDERED_NODE_TYPE, null
                    ).singleNodeValue.scrollTop = 250
                })
                if (scrollTries == 0) break
                else scrollTries--
            }

            web.click(`//slot[contains(text(), "${contractorName}")]`)
            web.click(`//lightning-formatted-name[text()="${contractorName}"]//..//..//..//..//..//div[contains(@class, "actionsContainer")]//lightning-button-menu`)
            web.pause(po.waitASecond)
            web.click('//lightning-menu-item//span[contains(text(), "היכנס לחוויה כמשתמש")]')

            if (page) {
                po.specialClick(`//div[@data-aura-class="forceCommunityGlobalNavigation"]//span[text()='${page}']`)
                if (page == 'גאנט פק"עות') {
                    if (web.isVisible(po.servicePage.gantFrame, po.waitHalfAMinute)) {
                        web.selectFrame(po.servicePage.gantFrame)
                    }
                }
            }
        },
    },
 
    /* settings page */
    settingsPage: {
        loginWithRep: (repName) => {
            if (web.isVisible(`//header[@id="oneHeader"]//span[contains(text(), "כניסה בוצעה בתור")]`, po.shortWait)) {
                let previousRep = web.getText('//header[@id="oneHeader"]//a[@href="/secur/logout.jsp"]')
                web.click('//header[@id="oneHeader"]//a[@href="/secur/logout.jsp"]')
                if (!web.isVisible(`//header[@id="oneHeader"]//span[contains(text(), "${previousRep}")]`, po.longWait)) {
                    po.log('success', previousRep)
                } else {
                    po.log('error', previousRep)
                }
            } 

            if (web.isVisible('//input[@title="חפש בהגדרות"]', po.waitHalfAMinute)) {
                web.type('//input[@title="חפש בהגדרות"]', repName)
                if (web.isVisible(`//li[contains(@class, "lookup__item")]//span[@title="${repName}"]`)) {
                    po.functions.pressENTER()
                }
            }  

            if (web.isVisible(`(//a[contains(@class, "setupLink") and text()="${repName}"])[1]`, po.waitHalfAMinute)) {
                web.click(`(//a[contains(@class, "setupLink") and text()="${repName}"])[1]`)
            } else if (web.isVisible(`//span[@title="${repName}" and contains(@class, "mruName")]`, po.longWait)) {
                web.click(`//span[@title="${repName}" and contains(@class, "mruName")]`)
            }

            po.alphaMainPage.assertApplicationError()

            if (!web.isVisible(`//iframe[contains(@title, "User: ${repName}")]`, po.shortWait)) {
                web.refresh()
            }

            if (web.isVisible(`//iframe[contains(@title, "User: ${repName}")]`, po.longWait)) {
                web.selectFrame(`//iframe[contains(@title, "User: ${repName}")]`)
            } else if (web.isVisible(`//span[@title="${repName}" and contains(@class, "mruName")]`, po.shortWait)) {
                web.click(`//span[@title="${repName}" and contains(@class, "mruName")]`)
                web.selectFrame(`//iframe[contains(@title, "User: ${repName}")]`)
            }

            if (!web.isVisible('//td[@id="topButtonRow"]//input[@name="login"]', po.waitHalfAMinute)) {
                web.refresh()
            }

            if (web.isVisible('//td[@id="topButtonRow"]//input[@name="login"]', po.waitHalfAMinute)) {
                web.click('//td[@id="topButtonRow"]//input[@name="login"]')
            } else {
                assert.fail(`לא מופיע כפתור כניסה לנציג\ה ${repName}`)
            }

            po.selectWindow('new')
            if (web.isVisible(`//header[@id="oneHeader"]//span[contains(text(), "כניסה בוצעה בתור ${repName}")]`, po.waitHalfAMinute)) {
                po.log('success', `Logged in with rep -> ${repName}`)
            } else {
                po.log('warning', `Rep ${repName} is not visible`)
            }
        },
    },

    /* customer details 360 */
    customerDetails360: {
        customerDetails: '//li[@title="פרטי לקוח"]',
        generalDetails: '//li[@title="פרטים כלליים"]',
        openInquiries: '//li[@title="פרטי לקוח"]//..//a[@data-label="פניות פתוחות"]',
        customerLink: '(//span[@title="מסך משותף 360"]//..//..//..//a[contains(@class, "forceOutputLookup")])[1]',
        products: '//a[@data-label="מבצע ומוצרי לקוח"]',
        content: '//a[@data-label="תכנים בהזמנה"]', 
        pakaList: `//a[@data-label='פק"עות וכתובות']`,
        productsHistory: '//strong[contains(text(), "היסטורית מוצרים")]',
        futureActions: '//strong[contains(text(), "הוספות/ הסרות  עתידיות")]',
        activeProducts: '//strong[contains(text(), "מוצרים פעילים")]',
        noDetailsToShow: '//..//..//..//..//p[contains(text(), "אין נתונים להציג")]',
        removalStatus : '//*[contains(text(), "הסרת הערוץ")]//..//..//..//div[contains(@class, "slds-modal__content")]',

        pakaTableHeader: {
            filterArrowDisplayed: "//*[name()='svg' and @data-key='arrowdown']",
            pakaNumber: `//span[@title='מספר פק"ע']`,
            taskType: "//span[@title='סוג משימה']",
            pakaType: `//span[@title='סוג פק"ע']`,
            deliveryType: "//span[@title='שיטת משלוח']",
            status: "//span[@title='סטטוס']",
            dateCoordination: "//span[@title='תאריך תאום']",
            hourCoordination: "//span[@title='שעת תיאום']",
            timeWindow: "//span[@title='חלון הזמן לאיחור']",
            team: "//span[@title='צוות / קבלן']",
            technician: "//span[@title='טכנאי']",
            openDate: "//span[@title='תאריך פתיחה']",
        },

        extraPakaInfoTable: {
            headers: {
                jobs: `//a[@data-label="ג'ובים"]`,
                closingReason: `//a[@data-label="סיבת סגירה"]`,
                notes: `//a[@data-label="הערות"]`,
                history: `//a[@data-label="היסטוריה"]`,
            },
            tabs: {
                jobs: `//li[@title="ג'ובים" and contains(@class, "is-active")]//..//..//..//lightning-tab[contains(@aria-labelledby, "Jobs")]`,
                closingReason: `//li[@title="סיבת סגירה" and contains(@class, "is-active")]//..//..//..//lightning-tab[contains(@aria-labelledby, "FaultReasons")]`,
                notes: `//li[@title="הערות" and contains(@class, "is-active")]//..//..//..//lightning-tab[contains(@aria-labelledby, "Notes")]`,
                history: `//li[@title="היסטוריה" and contains(@class, "is-active")]//..//..//..//lightning-tab[contains(@aria-labelledby, "History")]`, 
            },
        },
        
        isChartOpen: (chart) => { 
            // if the arrow is facing down the chart is open, returns true
            return web.isVisible(`//*[name()="svg" and @data-key="chevrondown"]//..//..//..//..//..//*[contains(text(), "${chart}")]`, po.longWait)
        },

        isChartEmpty: (chart) => {
            return web.isVisible(`//strong[contains(text(), "${chart}")]//..//..//..//..//..//..//*[contains(text(), "לא קיימים נתונים להצגה")]`, po.longWait)
        },

        openProducts: (accountNumber) => {
            const openDetails = () => {
                web.pause(po.shortWait)
                web.click(po.customerDetails360.products)
                web.waitForVisible(po.customerDetails360.products)
            }

            if (web.isVisible(`//a[contains(@data-account-id, "")]//div[contains(text(), "${accountNumber}")]`, po.longWait)) {
                web.click(`//a[contains(@data-account-id, "")]//div[contains(text(), "${accountNumber}")]`)
                openDetails()

            } else if (web.isVisible(`//*[@c-alp360searchconsumer_alp360searchconsumer and contains(text(), "${accountNumber}")]`, po.longWait)) { 
                web.click(`//div[@class="slds-truncate"]//*[contains(text(), "${accountNumber}")]`)
                web.click(`//a[contains(@data-account-id, "")]//div[contains(text(), "${accountNumber}")]`)
                openDetails()

            } else if (web.isVisible(`//a[text()="${accountNumber}"]//..//..//div[@class="bezeq-notify-warning"]`, po.longWait)) {
                web.click(`//div[@class="bezeq-notify-warning"]//..//..//a[text()="${accountNumber}"]`)
                openDetails()

            } else if (web.isVisible(po.searchCustomerPage.customerNotFoundMsg, po.longWait)) {
                assert.fail(`לא נמצאו תוצאות עבור לקוח מספר: ${accountNumber}`)
            }  
        },

        loadCustomerDetails: () => {
            /* header details */
            var header = '//*[@data-component-id="alp360HeaderContainer"]//div[contains(@class, "slds-col")]'
            var headerDetails = web.getElementCount(header)
            if (headerDetails > 0) {
                for (let x = 1; x <= headerDetails; x++) {
                    assert.equal(
                        web.isExist(`(${header})[${x}]`), true,
                        `Header element did not load properly at: (${header})[${x}]`
                    )
                    po.log('success', web.getText(`(${header})[${x}]`))
                }
            }

            /* yes details */
            var yesTable = '//*[@data-component-id="alp360MainDetailsAdw"]//td'
            var yesTableDetails = web.getElementCount(yesTable)
            if (yesTableDetails > 0) {
                for (let x = 1; x <= yesTableDetails; x++) {
                    assert.equal(
                        web.isExist(`(${yesTable})[${x}]`), true,
                        `Yes table element did not load properly at: (${yesTable})[${x}]`
                    )
                    po.log('success', web.getText(`(${yesTable})[${x}]`))
                }
            }
        },

        assertDataRows: () => {
            if (!web.isVisible(po.customerDetails360.activeProducts, po.longWait)) po.log('warning', 'טבלת מוצרים פעילים אינה מופיעה')
            if (!web.isVisible(po.customerDetails360.productsHistory, po.longWait)) po.log('warning', 'טבלת היסטורית מוצרים אינה מופיעה')
            if (!web.isVisible(po.customerDetails360.futureActions, po.longWait)) po.log('warning', 'טבלת הוספות/ הסרות עתידיות אינה מופיעה')
        },

        changeOfferWithOutlet_M: (offerId) => {
                if (!web.isVisible(`//a[text()="${offerId}"]`, po.shortWait * 2)) {

                // if the offer id from the query does not appear, find a new one with the same outlet
                let otherOffersWithOutlet = '//lightning-base-formatted-text[contains(text(), "M0")]//..//..//..//..//..//a'
                let offerCount = web.getElementCount(otherOffersWithOutlet)

                if (offerCount > 1) {
                    log.warn(`Offer ${offerId} was not displayed, available offers:`)

                    for (let offer = 1; offer <= offerCount; offer++) {
                        if (web.isVisible(`(${otherOffersWithOutlet})[${offer}]`, po.shortWait)) {
                            log.info(web.getText(`(${otherOffersWithOutlet})[${offer}]`))
                        }
                    }
                }

                let randomOfferNumber = po.functions.generateNumber(1, offerCount)
                offerId = web.getText(`(${otherOffersWithOutlet})[${randomOfferNumber}]`)
                return offerId
            }
        }, 
    }, /* end of customer details 360 */

    searchCustomerPage: {
        header: '//app_flexipage-header//*[contains(text(), "איתור לקוח")]',
        searchBtn: '//button[@title="חפש" and not (@disabled)]',
        customerLink: '(//c-alp360-event-link-type)[1]',
        customerNotFoundMsg: '//strong[contains(text(), "לא נמצאו תוצאות")]',
        loadingDataError :'//*[contains(text(), "שגיאה בטעינת הנתונים")]',
        
        searchParametersBtn: '//*[@name="searchParam"]',
        parameters: {
            id: '//span[@title="מספר מזהה"]',
            phone: '//span[@title="מספר טלפון"]',
            name: '//span[@title="שם פרטי ומשפחה"]',
            caseNumber: '//span[@title="מספר פניה"]',
            deviceNumber: '//span[@title="מספר ממיר/ כרטיס"]',
            accountNumber: '//span[@title="מספר לקוח"]',
        },

        idInput: '//input[@name="id"]',
        phoneInput: '//input[@name="phone_number"]',
        firstNameInput: '//input[@name="first_name"]',
        lastNameInput: '//input[@name="last_name"]',
        caseNumberInput: '//input[@name="case_number"]',
        deviceNumberInput: '//input[@name="device_number"]',
        accountNumberInput: '//input[@name="billing_account_number"]',

        searchCustomerByAccount: (number) => {
            let searchPage = po.searchCustomerPage

            po.alphaMainPage.openSearchPage()
            web.click(searchPage.searchParametersBtn)
            web.click(searchPage.parameters.accountNumber)
            web.type(searchPage.accountNumberInput, number)
            web.click(searchPage.searchBtn)
            
            if (web.isVisible(`//a[contains(@data-account-id, "")]//div[contains(text(), "${number}")]`, po.shortWait)
            || web.isVisible(`//*[@c-alp360searchconsumer_alp360searchconsumer and contains(text(), "${number}")]`, po.shortWait)
            || web.isVisible(`//c-alp360-main-details-adw//div[@class="slds-truncate" and contains(text(), "${number}")]`, po.shortWait)
            || web.isVisible(`//c-alp360-main-details-adw//td[@class="bezeq-notify-td"]//a[contains(text(), "${number}")]`, po.shortWait)) {
                log.info('✔ Account ' + number + ' exists')
                return true
            } else if (web.isVisible(searchPage.customerNotFoundMsg, po.shortWait)) {
                log.info('לא נמצאו תוצאות למספר לקוח: ' + number)
                return false
            } else if (web.isVisible(searchPage.loadingDataError, po.shortWait)) {
                let error = web.getText(searchPage.loadingDataError)
                log.info('✘ ' + error) 
            }
            return false
        },
    }, /* end of search customer page */

    leads: {
        searchMenuArrow: '//a[@title="בחר תצוגת רשימה"]//*[name()="svg" and @data-key="down"]',
        phoneError: '//div[contains(text(), "מספר טלפון לא תקין")]',
        all: '(//span[@class=" virtualAutocompleteOptionText" and text()="All"])[1]',
        all_hebrew: '(//span[@class=" virtualAutocompleteOptionText" and text()="כל הלידים הפתוחים"])[1]',
        recentlyViewed: '//span[@data-aura-class="uiOutputText" and contains(text(), "הוצגו לאחרונה")]',
        leadsInProgress: '(//span[text()="לידים בטיפולי"])[1]',
        moreActionsArrow: '//li[contains(@class, "oneActionsDropDown")]//lightning-icon',
        createNewLead: '//li[@class="uiMenuItem"]//a[@title="יצירת ליד חדש"]',
        createLeadFormHeader: '//flowruntime-flow//div[contains(@class, "header")]//*[text()="יצירת ליד"]',
        firstName: '//input[@name="firstName"]',
        lastName: '//input[@name="lastName"]',
        phone: '(//*[text()="Phone Number" or text()="מספר טלפון"]//..//..//..//input)[1]',
        id: '(//*[text()="סוג זיהוי" or text()="מספר זיהוי" or text()="ID Number"]//..//..//..//input)[1]',
        finishLead: '(//span[text()="סיום"])[1]',
        finishUpdateLead: '//button[@name="סיים"]',
        findCustomers: '//button[@title="מצא לקוחות"]',
        createNewBillingAccount: '//input[contains(@id, "Create_New_Billing_Account")]',
        createLeadBtn: '//*[(@name="CreateLead" or @title="יצירת ליד") and @aria-disabled="false"]',
        deleteLeadBtn: '//a[contains(@data-target-selection-name, "Lead.Delete") or @title="מחיקה"]',
        confirmDelete: '//button[contains(@class, "forceActionButton")]/span[text()="מחיקה"]',
        customerConfirm: '//span[contains(text(), "אישור לקוח להעברת פרטים")]//..//span[contains(@class, "slds-checkbox_faux") or contains(@class, "slds-radio_faux")]',
        assignLeadToMeBtn: '//*[contains(text(), "הקצה ליד אליי")]',
        errorContainer: '//div[contains(@class, "record-layout-load-error-container")]',

        handlingCompanySelect: '(//span[text()="Handling Company" or text()="חברה מטפלת"]//..//..//..//select)[1]',
        handlingCompany: { 
            yes: 'value=handlingCompanyChoiceSet.YES',
            pelephone: 'value=handlingCompanyChoiceSet.PEL',
            bezeqInternational: 'value=handlingCompanyChoiceSet.BBL',
        },

        interestedInSelect: '(//span[text()="Product Category" or text()="מעוניין ב"]//..//..//..//select)[1]',
        interestedIn: {
            yes: 'label=yes',
            stingPlus: 'label=sting+',
            equipment: 'label=ציוד קצה',
            internet: 'label=אינטרנט yes',
            internetAndTV: 'label=טלוויזיה + אינטרנט',
        },

        updateLeadInterestedIn: {
            yes: '//span[text()="yes"]',
            stingPlus: '//span[text()="sting+"]',
            equipment: '//span[text()="ציוד קצה"]',
            internet: '//span[text()="אינטרנט yes"]', 
            internetAndTV: '//span[text()="טלוויזיה + אינטרנט"]',
        },

        offerGivenInput: '(//label[text()="הצעה שניתנה" or text()="Given Offer"]//..//..//input)[1]',
        offerGivenOptions: {
            yesUltimate: '(//label[text()="הצעה שניתנה"]//..//..//input)[1]//..//option[@value="yes ultimate"]',
            sting: '(//label[text()="הצעה שניתנה"]//..//..//input)[1]//..//option[@value="STING"]'
        },

        offerTextarea: '//label[text()="פירוט הצעה שניתנה" or text()="Given Offer Description"]//..//textarea',
        emailInput: '//label[text()="אימייל"]//..//input',
        idInput: '//label[text()="סוג זיהוי" or text()="מספר זיהוי" or text()="ID Number"]//..//input',
        findCustomersBtn: '//lightning-card//button[@title="מצא לקוחות" or @title="Find Customers"]',

        status: {
            interested: '//legend[contains(text(), "סטטוס") or contains(text(), "Status")]//..//span[text()="מעוניין"]',
            continueTreatment: '//legend[contains(text(), "סטטוס") or contains(text(), "Status")]//..//span[text()="המשך טיפול"]',
            denial: '//legend[contains(text(), "סטטוס") or contains(text(), "Status")]//..//span[text()="סירוב"]',
            noAnswer: '//legend[contains(text(), "סטטוס") or contains(text(), "Status")]//..//span[text()="אין מענה"]',
            wrongLead: '//legend[contains(text(), "סטטוס") or contains(text(), "Status")]//..//span[text()="ליד שגוי"]',
        },

        reason: {
            price: '//legend[contains(text(), "סיבה") or contains(text(), "Reason")]//..//span[text()="מחיר"]',
            product: '//legend[contains(text(), "סיבה") or contains(text(), "Reason")]//..//span[text()="מוצר"]',
            didNotDecide: '//legend[contains(text(), "סיבה") or contains(text(), "Reason")]//..//span[text()="לא החליט"]',
        },

        rivalCompanies: {
            hot: '//span[text()="HOT"]//..//..//label[contains(@class, "slds-radio_button")]', 
            partner: '//span[text()="פרטנר" or text()="Partner"]//..//..//label[contains(@class, "slds-radio_button")]', 
            netflix: '//span[text()="Netflix"]//..//..//label[contains(@class, "slds-radio_button")]', 
            next: '//span[text()="Next"]//..//..//label[contains(@class, "slds-radio_button")]', 
            other: '//span[text()="אחר"]//..//..//label[contains(@class, "slds-radio_button")]', 
            triple_C: '//span[text()="טריפל C" or text()="Triple C"]//..//..//label[contains(@class, "slds-radio_button")]', 
            idanPlus: '//span[text()="עידן +" or text()="Idan +"]//..//..//label[contains(@class, "slds-radio_button")]', 
            rimon: '//span[text()="רימון" or text()="Rimon"]//..//..//label[contains(@class, "slds-radio_button")]', 
        },

        openNewLeadWindow: () => {
            if (web.isVisible(po.alphaMainPage.newBtn, po.shortWait)) {
                web.click(po.alphaMainPage.newBtn)
            } else {
                web.click(po.leads.moreActionsArrow)
                web.click(po.leads.createNewLead)
            }
            web.waitForVisible(po.leads.createLeadFormHeader)
        },

        assertLeadWindowError: () => {
            let main = po.alphaMainPage
            if (web.isVisible(main.errorToastMessage, po.shortWait)) {
                assert.fail(web.getText(main.errorToastMessage))
            } else if (web.isVisible('//div[@data-aura-class="oneApplicationError"]', po.shortWait)) {
                log.info(web.getText('//div[@data-aura-class="oneApplicationError"]'))
                web.click('//span[contains(text(), "עניינים טכניים")]')
                if (web.isVisible('//div[@class="details-ctr expanded"]')) {
                    log.info(web.getText('//div[@class="details-ctr expanded"]//textarea'))
                    web.click('//div[@class="details-ctr expanded"]//..//..//..//button[@title="אישור"]')
                    web.refresh()
                }
            }
        },

        handlePhoneError: () => {
            if (web.isVisible(po.leads.phoneError, po.longWait / 2)) {
                web.clear(po.leads.phone)
                web.type(po.leads.phone, po.functions.generatePhone())
                po.functions.pressTAB()
                po.leads.handlePhoneError()
            }      
        },

        deleteLead: (firstName, lastName) => {
            let leads = po.leads
            let main = po.alphaMainPage
            let fullLeadName = `${firstName} ${lastName}`

            web.click(main.openMainSearchButton)
            web.pause(po.shortWait)
            web.type(main.mainSearchInput, fullLeadName)
            web.pause(po.shortWait)

            let tries = 5
            while (!web.isVisible(`//span[text()="ליד"]//..//..//..//span[@title="${fullLeadName}"]`, po.longWait)) {
                web.click(main.openMainSearchButton)
                web.pause(po.shortWait)
                web.type(main.mainSearchInput, fullLeadName)
                web.pause(po.shortWait)
                
                if (tries == 0) break
                else tries--
            }

            if (web.isVisible(`//span[text()="ליד"]//..//..//..//span[@title="${fullLeadName}"]`, po.waitHalfAMinute)) {
                po.functions.pressENTER()

                if (web.isVisible(`//a[text()="לידים"]//..//..//..//..//..//a[@title="${fullLeadName}"]//..//..//..//div[@data-aura-class="forceVirtualAction"]`, po.waitHalfAMinute)) {
                    web.click(`//a[text()="לידים"]//..//..//..//..//..//a[@title="${fullLeadName}"]//..//..//..//div[@data-aura-class="forceVirtualAction"]`)
                    web.click(leads.deleteLeadBtn)

                    if (web.isVisible(leads.confirmDelete)) {
                        web.click(leads.confirmDelete)
                    } else {
                        po.log('error', 'לא הופיע חלון של מחק ליד')
                    }
                } else {
                    po.log('error', `${fullLeadName} is not visible in the leads page!`)
                }
            }
        },

        openNewLeadForm: () => {
            let leads = po.leads
            let main = po.alphaMainPage
            let openLeadFormTries = 5

            web.pause(po.shortWait)
            web.click(main.navigationBtn)
            web.click(main.navigationOptions.leads)

            if (web.isVisible('//div[contains(@class, "firstHeaderRow")]//..//li[contains(@class, "oneActionsDropDown")]//a', po.waitHalfAMinute)) {
                web.click('//div[contains(@class, "firstHeaderRow")]//..//li[contains(@class, "oneActionsDropDown")]//a')
            }

            if (web.isVisible(leads.createLeadBtn, po.waitHalfAMinute)) {
                web.click(leads.createLeadBtn)
            } else {
                web.refresh()
                while (!web.isVisible(po.leads.createLeadFormHeader, po.longWait)) {
                    web.click(main.navigationBtn)
                    web.click(main.navigationOptions.leads)

                    if (web.isVisible('//div[contains(@class, "firstHeaderRow")]//..//li[contains(@class, "oneActionsDropDown")]//a', po.waitHalfAMinute)) {
                        web.click('//div[contains(@class, "firstHeaderRow")]//..//li[contains(@class, "oneActionsDropDown")]//a')
                    }

                    web.click(leads.createLeadBtn)
                    if (openLeadFormTries == 0) break
                    else openLeadFormTries--
                }
            }
        },

        createLead: (firstName, lastName, phone, id) => {
            let main = po.alphaMainPage
            let leads = po.leads

            web.pause(po.shortWait)
            web.type(leads.firstName, firstName)
            web.type(leads.lastName, lastName)
            web.type(leads.phone, phone) 
            po.functions.pressTAB()

            leads.handlePhoneError()

            if (!web.getValue(leads.phone).includes(phone)) {
                phone = web.getValue(leads.phone)
                po.log('info', `Updated phone to: ${phone}`)
            }

            web.select(leads.handlingCompanySelect, leads.handlingCompany.yes)            
            web.select(leads.interestedInSelect, leads.interestedIn.yes)

            if (web.isVisible(leads.customerConfirm, po.longWait)) {
                web.click(leads.customerConfirm)
            }

            web.transaction('Create Lead') 
            let newNextButtonElement
            let nextButtonCount = web.getElementCount(main.nextButtonNotDisabled)
            if (nextButtonCount == 1) {
                newNextButtonElement = `(${main.nextButtonNotDisabled})[1]`
            } else if (nextButtonCount == 2) {
                newNextButtonElement = `(${main.nextButtonNotDisabled})[2]`
            }

            web.scrollToElement(newNextButtonElement, true)
            web.click(newNextButtonElement)

            if (!web.isVisible(`(//lightning-formatted-name[contains(text(), "${firstName} ${lastName}")])[1]`)) {
                po.log('warning', `New lead did not include the right name (${firstName} ${lastName})`)

                if (!web.isVisible(`(//span[text()="טלפון" or text()="Phone"]//..//..//..//*[contains(text(), "${phone}")])[1]`)) {
                    po.log('warning', `New lead did not include the right phone number (${phone})`)
                }
            } else {
                po.log('success', `Created new lead for -> ${firstName} ${lastName}, ${phone}`)
            }
        },

        updateLead: (id, firstName, lastName) => {
            let leads = po.leads
            let func = po.functions

            if (web.isVisible('//a[@data-label="עדכון ליד"]', po.longWait)) {
                po.specialClick(leads.updateLeadInterestedIn.yes)
            }
            
            if (web.isVisible(`//div[@aria-label="כרטיסיות משנה עבור ${firstName + ' ' + lastName} | ליד"]//span[@class="title slds-truncate" and text()="יצירת ליד"]`, po.longWait)) {
                web.click(`//div[@aria-label="כרטיסיות משנה עבור ${firstName + ' ' + lastName} | ליד"]//span[@class="title slds-truncate" and text()="יצירת ליד"]`)
            }

            web.type(leads.offerGivenInput, 'Yes Ultimate')
            func.pressENTER()
            func.pressTAB()

            let givenOfferTries = 10
            while (web.isVisible('//div[text()="קלט שגוי"]', po.shortWait)) {
                web.type(leads.offerGivenInput, 'Yes Ultimate')
                func.pressENTER()
                func.pressTAB()

                if (web.isVisible('//div[text()="קלט שגוי"]', po.shortWait)) {
                    po.specialClick(leads.updateLeadInterestedIn.stingPlus)
                    web.type(leads.offerGivenInput, 'סדרות+')
                    func.pressENTER()
                    func.pressTAB()
                }

                if (givenOfferTries == 0) break
                else givenOfferTries--
            }

            po.log('info', 'Given Offer: ' + web.getValue(leads.offerGivenInput))
            
            web.type(leads.offerTextarea, 'פירוט הצעה שניתנה')
            po.clickUntilElementIsVisible(leads.rivalCompanies.triple_C, leads.status.interested)
            web.click(leads.rivalCompanies.triple_C)
            web.type(leads.id, id) 
            po.functions.pressTAB()

            // let displayedId = web.getValue(leads.idInput)
            // if (displayedId != id) {
            //     assert.fail(`Update lead window displayed the wrong id. Expected id: ${id} instead got: ${displayedId}`)
            // } else if (displayedId == '') {
            //     po.log('error', `Update lead window doesn't include newly created id (${id})`)
            //     web.type(leads.idInput, id)
            // } 

            web.transaction(`Find Customer With ID: ${id}`)
            web.click(leads.findCustomersBtn)

            if (!web.isVisible(`//button[text()="${firstName} ${lastName}"]`, po.longWait)) {
                if (web.isVisible('//*[contains(text(), "קיימת הזמנה פתוחה למספר זיהוי")]', po.longWait)) {
                    web.click('//*[contains(text(), "סגירת ליד")]//..//*[@class="slds-radio_faux"]')
                    po.specialClick(leads.finishUpdateLead)
                    assert.equal(
                        web.isVisible('//*[@data-refid="tab-name" and @title="הסתיים"]'), true,
                        'ליד עם תז ' + id + ' לא הסתיים בהצלחה'
                    )
                }
                po.log('info', 'לא נמצאו תוצאות ללקוח עם תז: ' + id)
            } else {
                web.click(`//button[text()="${firstName} ${lastName}"]//..//..//..//span[@class="slds-radio_faux"]`)
            }

            web.click('//*[contains(text(), "יצירת חשבון חיוב חדש")]//..//..//..//*[@class="slds-radio_faux"]')
            web.click(leads.finishUpdateLead)

            if (!web.isVisible('(//lightning-spinner)[1]', po.waitHalfAMinute) || !web.isVisible('(//lightning-spinner)[2]', po.waitHalfAMinute)) {
                return
            }
        },

    }, /* end of leads */

    cases: {
        saveBtn : '//span[text()="שמור"]',
        finishBtn: '//button[contains(text(), "סיים")]',
        modalSaveBtn: '//footer//span[text()="שמור"]',
        createCaseBtn: '//button[contains(text(), "צור פנייה")]',
        openTaskBtn: '//button[@name="Case.Open_Task"]',
        createTaskBtn: '//button[@name="Case.Create_Task"]',
        makeMeOwnerBtn: '//button[@name="Case.Make_Me_Owner"]',
        closeCaseBtn: '//button[@name="Case.Close_Case"]',
        transferToLegacyBtn: '//button[@name="Case.Transfer_to_Legacy"]',
        issueReportingComponent: '//*[@data-component-id="issueReporting"]',
        leadStatusUpdateComponent: '//*[@data-component-id="leadStatusUpdate"]',
        activityTimelineComponent: '//*[@data-component-id="timeline_activityTimeline"]',
        refreshActivityTimeline: '//*[@data-component-id="timeline_activityTimeline"]//button[@title="Refresh Data"]',
        assistCaseCheckbox: '//span[text()="פניית תפעול ותמיכה"]//..//..//input[@name="recordTypeId"]',
        infoCaseCheckbox: '//span[text()="פניית מתן מידע"]//..//..//input[@name="recordTypeId"]',

        expertConsultingBtn: '//button[contains(@name, "Case.Expert_Consulting")]',
        expertConsultingInput: '//span[contains(text(), "התייעצות בכיר")]//..//..//input',
        expertConsultingMainReasonInput: '//span[contains(text(), "נושא ראשי")]//..//..//input',
        expertConsultingSecondaryReasonBtn: '//span[contains(text(), "נושא משני")]//..//..//a',

        newIssueBtn: '//span[contains(text(), "תקלה חדש")]',
        issueInput: '//span[contains(text(), "תקלה")]//..//..//input',
        newIssueSaveBtn: '//h2[contains(text(), "צור תקלה")]//..//..//span[(text()="שמור")]',

        incidentInput: '//span[contains(text(), "מקרה")]//..//..//input',
        newIncidentBtn: '//span[contains(text(), "מקרה חדש")]',
        incidentFirstResult: '(//ul[contains(@class, "lookup__list") and contains(@class, "visible")]//li//a)[1]',
        newIncidentFirstRadioBtn: '(//h2[contains(text(), "מקרה חדש")]//..//..//div[contains(@class, "changeRecordTypeOption")]//span)[1]',
        newIncidentSaveBtn: '//h2[contains(text(), "מקרה חדש")]//..//..//span[(text()="שמור")]',

        expertConsultingReasons: {
            helpWithWizard: '//a[@title="סיוע במערכת Wizard"]',
            helpWithYes360: '//a[@title="סיוע במערכת Yes360"]',
        },

        createNewIncident: () => {
            let cases = po.cases
            web.click(cases.incidentInput)
            web.click(cases.newIncidentBtn)
            web.click(cases.newIncidentFirstRadioBtn)
            web.click(po.alphaMainPage.nextButton)
            web.click(cases.newIncidentSaveBtn)
        },

    }, /* end of cases */


    sales: {
        addAddress: (city, street, email, houseNumber, apartmentNumber, entrance, apartmentType) => {
            let main = po.alphaMainPage

            if (web.isVisible('//*[contains(text(), "היתכנות לאינטרנט סיבים")]', po.longWait)) {
                return
            }

            if (web.isVisible('//span[contains(text(), "פרטי לקוח")]')) {
                web.click('//a[@data-label="תהליך מכר"]')
                web.type('//label[contains(text(), "עיר")]//..//input', city)
                web.click(`(//span[@role="option"]//span[contains(text(), '${city}')])[1]`)
                web.type('//label[contains(text(), "רחוב")]//..//input', street)
                web.click(`(//span[@role="option"]//span[contains(text(), '${street}')])[1]`)
                web.type('//label[contains(text(), "Email")]//..//input', email)
                web.type('//label[contains(text(), "מספר בית")]//..//input', houseNumber)
                web.click(`//*[contains(text(), "האם הלקוח גר בבניין או בבית פרטי?")]//..//..//..//..//..//span[@class="slds-radio_faux"]//..//span[contains(text(), "${apartmentType}")]`)
                web.type('//label[contains(text(), "מספר דירה")]//..//input', apartmentNumber) 
                
                if (web.isVisible('//label[contains(text(), "כניסה")]//..//input', po.shortWait)) {
                    web.type('//label[contains(text(), "כניסה")]//..//input', entrance)

                    if (web.isVisible(main.nextButtonNotDisabled, po.shortWait)) {
                        if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                    } 
                }

                if (web.isVisible('(//legend[contains(text(), "כניסה")]//..//span[@class="slds-radio_faux"])[1]', po.shortWait)) {
                    web.click('(//legend[contains(text(), "כניסה")]//..//span[@class="slds-radio_faux"])[1]')
                }

                if (web.isVisible('//*[contains(text(), "היתכנות לאינטרנט סיבים")]', po.longWait)) {
                    return
                }

                if (web.isVisible('//div[contains(text(), "יש לבחור כניסה!")]', po.shortWait)) {
                    web.click('(//legend[contains(text(), "כניסה")]//..//span)[1]')

                    if (web.isVisible(main.nextButtonNotDisabled, po.shortWait)) {
                        if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                    } 
                }
            }

            if (web.isVisible('//span[text()="NO_ENTRANCE"]', po.shortWait)) {
                po.clickUntilElementIsVisible(main.nextButtonNotDisabled, '//span[text()="NO_ENTRANCE"]')
                if (web.isVisible(main.nextButtonNotDisabled, po.shortWait)) {
                    if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                } 
            } 

           if (web.isVisible('//*[@data-aura-class="forceActionsText" and contains(text(), "לא חזר מזהה כתובת")]', po.longWait)) {
                po.log('error', web.getText(main.errorToastMessage))
                po.specialType('//label[contains(text(), "כניסה")]//..//input', 'א')
                if (web.isVisible(main.nextButtonNotDisabled, po.shortWait)) {
                    if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                } 
            }
            
            if (web.isVisible(main.errorToastMessage, po.longWait) && web.isVisible(main.nextButtonNotDisabled, po.longWait)) {
                let errors = web.getElementCount(main.errorToastMessage)
                for (let x = 1; x <= errors; x++) {
                    po.log('error', web.getText(`(${main.errorToastMessage})[${x}]`))
                    web.click(`(${main.errorToastMessageCloseButton})[${x}]`)
                }
                if (web.isVisible(main.nextButtonNotDisabled, po.shortWait)) {
                    if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                } 
            }
        },

        feasibilityTest: (city, street, houseNumber) => {
            let main = po.alphaMainPage

            if (web.isVisible('//span[@data-label="בדיקת היתכנות"]')) {
                if (web.isVisible('//span[contains(text(), "ממשק לא הופעל באופן תקין")]', po.longWait)) {
                    po.log('warning', web.getText('//span[contains(text(), "ממשק לא הופעל באופן תקין")]'))
                    if (web.isVisible(main.nextButtonNotDisabled, po.longWait)) {
                        if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                        return
                    }
                } else if (web.isVisible('//flowruntime-base-section//p[contains(text(), "קיימת")]', po.longWait)) {
                    po.log('success', `היתכנות לאינטרנט סיבים קיימת בכתובת ${city} ${street} ${houseNumber}`)
                }

                let feasibilityData = `//*[contains(text(), "${street}") and contains(text(), "${city}") and contains(text(), "${houseNumber}")]`
                if (web.isVisible(feasibilityData, po.longWait)) {
                    po.log('info', 'הכתובת שמוצגת בבדיקת היתכנות ' + web.getText(feasibilityData))
                } 

                if (web.isVisible(main.nextButtonNotDisabled, po.longWait)) {
                    if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                }
            } else if (!web.isVisible(main.nextButtonNotDisabled, po.longWait)) {
                web.click('//button[contains(text(), "הקודם")]')
                po.specialClick(main.nextButtonNotDisabled)
            } else if (web.isVisible(`//span[@class="toastMessage forceActionsText" and contains(text(), 'קיימת פק"ע פתוחה עבור כתובת זו')]`, po.longWait)
            || web.isVisible(`//span[@class="toastMessage forceActionsText" and contains(text(), 'שגיאה כללית')]`, po.shortWait)) {
                assert.fail(`קיימת פק"ע פתוחה עבור כתובת ${city + ' ' + street + ' ' + houseNumber}`)
            }

            if (web.isVisible(main.errorToastMessage, po.longWait) && web.isVisible(main.nextButtonNotDisabled, po.longWait)) {
                let errors = web.getElementCount(main.errorToastMessage)
                for (let x = 1; x <= errors; x++) {
                    po.log('error', web.getText(`(${main.errorToastMessage})[${x}]`))
                    web.click(`(${main.errorToastMessageCloseButton})[${x}]`)
                }
                if (web.isVisible(main.nextButtonNotDisabled, po.longWait)) {
                    if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                }
            }
        },

        chooseProduct: (productName, productNumber) => {
            let main = po.alphaMainPage
            
            if (web.isVisible('//*[@class="slds-card__header-title"]//span[contains(text(), "שאלות להקמת לקוח")]', po.longWait)) {
                return
            }

            if (web.isVisible('//label[contains(text(), "הצעות טלויזיה")]')) {
                web.pause(po.shortWait)

                if (web.isVisible('//label[contains(text(), "הצעות טלויזיה")]//..//button')) {
                    po.specialClick('//label[contains(text(), "הצעות טלויזיה")]//..//button')
                }

                if (web.isVisible(`//lightning-base-combobox-item[contains(@data-value, "${productName}")]`)) {
                    po.specialClick(`//lightning-base-combobox-item[contains(@data-value, "${productName}")]`)
                }

                if (web.isVisible('//c-cart-search-result-item')) {
                    var offers = web.getElementCount('//c-cart-search-result-item')
                    for (let x = 1; x <= offers; x++) {
                        var offerNumber = web.getText(`(//c-cart-search-result-item//*[contains(@class, "slds-card__header-title")]//span)[${x}]`)
                        var offerDesc = web.getText(`(//c-cart-search-result-item//div[contains(@class, "slds-card__body")])[${x}]`)
                        po.log('info', `Offer Desc: ${offerDesc}`)

                        if (productName == 'VOD') {
                            po.specialClick(`(//c-cart-search-result-item//button[@title="joinNow"])[${x}]`)
                        } else if (web.isVisible(`(//c-cart-search-result-item//button[@title="joinNow"])[${x}]`, po.longWait)) {
                            po.specialClick(`(//c-cart-search-result-item//button[@title="joinNow"])[${x}]`)

                            if (web.isVisible('//c-cart-product-list//span[contains(text(), "מוצרים בחבילה")]', po.waitHalfAMinute)) {
                                po.specialClick(main.nextButtonNotDisabled)
                                break
                            }

                            if (web.isVisible('//span[contains(text(), "הצעה סגורה")]', po.waitHalfAMinute)) {
                                po.log('warning', `ההצעה סגורה: ${offerDesc} ${offerNumber}`)
                                if (offers == x) {
                                    assert.fail(assert.fail(`לא ניתן לבחור מוצר, (${offers}) כל ההצעות סגורות ${productName}`))
                                } else {
                                    continue
                                }
                            }

                            po.specialClick('//lightning-badge[contains(text(), "ממירים בשכירות")]')
                            po.specialClick(`//c-cart-expand-icon//..//span[contains(text(), "${productName}")]`)
                            po.specialClick(`(//c-cart-expand-icon//..//span[contains(text(), "${productName}")]//..//..//..//..//..//..//span[contains(text(), "${productName}")]//..//..//..//..//..//..//span[@class="slds-checkbox_faux"])[1]`)
                            po.specialClick('//button[contains(text(), "הגדרת מוצר")]')
                            if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                        } else {
                            if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                        }

                        if (web.isVisible('//h1[contains(text(), "תהליך מכר")]')) {
                            if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                            break
                        } else if (web.isVisible('//*[contains(text(), "לא נמצאו מוצרים המתאימים")]')) {
                            web.click('//button[contains(text(), "ביטול")]')
                            web.click('//button[contains(text(), "הקודם")]')
                            continue
                        } else if (web.isExist(`//slot[contains(text(), "${productName}")]`)) {
                            productNumber = offerNumber
                            po.log('info', 'Updated Product Number: ' + productNumber)
                            if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                            break
                        } else if (web.isVisible(main.errorToastMessage, po.shortWait)) {
                            po.log('error', web.getText(main.errorToastMessage))
                            continue
                        }
                    }
                } 
            } else if (web.isVisible(main.nextButtonNotDisabled, po.waitHalfAMinute)) {
                po.specialClick(main.nextButtonNotDisabled)
            } else {
                assert.fail(`הייתה בעיה בבחירת מוצר ${productName}`)
            }
            
            if (web.isVisible(main.errorToastMessage, po.longWait) && web.isVisible(main.nextButtonNotDisabled, po.longWait)) {
                let errors = web.getElementCount(main.errorToastMessage)
                for (let x = 1; x <= errors; x++) {
                    po.log('error', web.getText(`(${main.errorToastMessage})[${x}]`))
                    web.click(`(${main.errorToastMessageCloseButton})[${x}]`)
                }
                if (web.isVisible(main.nextButtonNotDisabled, po.longWait)) {
                    if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                }
            }
        },

        acceptConditions: () => {
            let main = po.alphaMainPage
            let func = po.functions
            
            if (web.isVisible('//*[@class="slds-card__header-title"]//span[contains(text(), "שאלות להקמת לקוח")]', po.waitHalfAMinute)) {
                let questionElements = '//*[@title="נדרש"]//..//..//button[contains(@id, "combobox") and not (@disabled)]'
                let questionElementsCount = web.getElementCount(questionElements)

                for (let x = 1; x <= questionElementsCount; x++) {
                    let error = `(//div[contains(text(), "מלא שדה זה")])[${x}]`
                    po.specialClick(`(${questionElements})[${x}]`)
                    func.pressARROW_DOWN()
                    func.pressARROW_DOWN()
                    func.pressENTER()
                    func.pressTAB()

                    if (web.isVisible(error, po.shortWait)) {
                        x =- 1
                        continue
                    }
                }

                if (web.isVisible(main.nextButtonNotDisabled)) {
                    web.click(main.nextButtonNotDisabled)
                } 
                
                if (web.isVisible(main.errorToastMessage, po.shortWait) && web.isVisible(main.nextButtonNotDisabled, po.shortWait)) {
                    let errors = web.getElementCount(main.errorToastMessage)
                    for (let x = 1; x <= errors; x++) {
                        po.log('error', web.getText(`(${main.errorToastMessage})[${x}]`))
                        web.click(`(${main.errorToastMessageCloseButton})[${x}]`)
                    }
                    if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                }
            }
        },

        retryInCaseOfError: (city, street, email, houseNumber, apartmentNumber, entrance, apartmentType, productName, productNumber) => {          
            let main = po.alphaMainPage

            if (web.isVisible(`//span[@class="toastMessage forceActionsText" and contains(text(), 'קיימת פק"ע פתוחה עבור כתובת זו')]`, po.longWait)
            || web.isVisible(`//span[@class="toastMessage forceActionsText" and contains(text(), 'שגיאה כללית')]`, po.shortWait)) {
                po.log('warning', `קיימת פק"ע פתוחה עבור כתובת ${city + ' ' + street + ' ' + houseNumber}`)
                
                web.execute(() => {
                    window.scrollTo(0, document.body.scrollHeight || document.documentElement.scrollHeight)
                })
                
                if (web.isVisible(main.nextButtonNotDisabled)) {
                    web.click(main.nextButtonNotDisabled)
                    if (!web.isVisible('//label[contains(text(), "עיר")]//..//input', po.waitHalfAMinute)) {
                        return
                    }
                }

                let tries = 5
                while (!web.isVisible('//label[contains(text(), "עיר")]//..//input', po.longWait)) {
                    web.isVisible('//button[contains(text(), "הקודם")]', po.longWait) && web.click('//button[contains(text(), "הקודם")]')
                    if (tries == 0) break
                    tries--
                }
                
                let queryValues = po.database.getAddress()
                city = queryValues[0].trim() != '' ? queryValues[0].trim() : 'מודיעין-מכבים-רעות'
                street = queryValues[1].trim() != '' ? queryValues[1].trim() : 'עמק חרוד'
                houseNumber = queryValues[2].trim() != '' ? queryValues[2].trim().match(/\d+/g).join('') : '44'
                entrance = queryValues[3].trim() != '' ? queryValues[3].trim() : ''
                apartmentNumber = queryValues[4].trim() != '' ? queryValues[4].trim().match(/\d+/g).join('') : func.generateNumber(1, 99)
                apartmentType = (queryValues[5].trim() != '' && (queryValues[5].trim() == 'BIL' || queryValues[5].trim() == 'TRN' || queryValues[5].trim() == 'TER')) ? 'בניין' : (queryValues[5].trim() != '' && queryValues[5].trim() == 'VIL') ? 'בית פרטי' : ''

                po.log('info', `Address: ${city} ${street} House: ${houseNumber} Apartment: ${apartmentNumber} Entrance: ${entrance} Apartment Type: ${apartmentType}`)

                web.pause(po.shortWait)
                po.specialType('//label[contains(text(), "מספר דירה")]//..//input', apartmentNumber)

                if (web.isVisible('//label[contains(text(), "כניסה")]//..//input', po.longWait)) {
                    po.specialType('//label[contains(text(), "כניסה")]//..//input', entrance)
                    if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                }

                if (web.isVisible('//div[contains(text(), "יש לבחור כניסה!")]', po.waitHalfAMinute)) {
                    po.clickUntilElementIsVisible(main.nextButtonNotDisabled, '(//legend[contains(text(), "כניסה")]//..//span)[1]')
                    if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                }
            
                if (web.isVisible('//span[text()="NO_ENTRANCE"]', po.longWait)) {
                    po.clickUntilElementIsVisible(main.nextButtonNotDisabled, '//span[text()="NO_ENTRANCE"]')
                    if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                }  

                po.sales.addAddress(city, street, email, houseNumber, apartmentNumber, entrance, apartmentType) 
                po.sales.feasibilityTest(city, street, houseNumber)
                po.sales.chooseProduct(productName, productNumber)
                po.sales.acceptConditions(city, street, houseNumber)
            }
            
            if (web.isVisible(main.errorToastMessage, po.longWait) && web.isVisible(main.nextButtonNotDisabled, po.longWait)) {
                let errors = web.getElementCount(main.errorToastMessage)
                for (let x = 1; x <= errors; x++) {
                    po.log('error', web.getText(`(${main.errorToastMessage})[${x}]`))
                    web.click(`(${main.errorToastMessageCloseButton})[${x}]`)
                }
                if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
            }
        },

        assertBuildingNetworks: () => {
            web.transaction('Assert Building Networks')
            if (web.isVisible('//div[@part="title"]//*[contains(text(), "רישות בניינים")]', po.waitHalfAMinute)) {
                if (web.isVisible('//*[contains(@class, "slds-theme_warning")]', po.shortWait)) {
                    po.log('warning', web.getText('//*[contains(@class, "slds-theme_warning")]'))
                    po.specialClick('//button[contains(text(), "העברת בקשה לרישות בניינים")]')
                    if (web.isVisible('//div[contains(text(), "ההזמנה נעולה לטיפול והועברה לרישות בניינים")]')) {
                        po.log('info', 'ההזמנה נעולה לטיפול והועברה לרישות בניינים')
                        assert.pass()
                    }
                }
            } else if (web.isVisible('//*[contains(text(), "בעיה בקריאה לממשק")]', po.longWait)) {
                assert.fail(web.getText('//*[contains(text(), "בעיה בקריאה לממשק")]'))
            }

            if (web.isVisible(main.errorToastMessage, po.longWait) && web.isVisible(main.nextButtonNotDisabled, po.longWait)) {
                let errors = web.getElementCount(main.errorToastMessage)
                for (let x = 1; x <= errors; x++) {
                    po.log('error', web.getText(`(${main.errorToastMessage})[${x}]`))
                    web.click(`(${main.errorToastMessageCloseButton})[${x}]`)
                }
                if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
            }
        },

        chooseDeliveryByTechnician: (phone) => {
            let main = po.alphaMainPage

            if (web.isVisible('//c-payment-method//*[contains(text(), "אמצעי תשלום")]', po.waitHalfAMinute)) {
                return
            } else if (web.isVisible('//span[contains(text(), "בחר אופן אספקה")]', po.waitHalfAMinute)) {
                let func = po.functions

                po.specialClick('//th[@data-label="שיטת אספקה"]//lightning-base-formatted-text[contains(text(), "טכנאי")]//..//..//..//..//..//span[@class="slds-radio_faux"]')

                if (web.isVisible('//label[contains(text(), "טלפון איש קשר")]//..//input')) {
                    web.type('//label[contains(text(), "טלפון איש קשר")]//..//input', phone)
                    po.specialClick('//button[contains(text(), "מצא חלון זמן")]')
                    if (!web.isVisible('(//div[contains(@class, "singleDay")])[1]')) {
                        po.clickUntilElementIsVisible('(//div[contains(@class, "singleDay")])[1]', '//button[contains(text(), "מצא חלון זמן")]')
                    }
                } else if (web.isVisible('//lightning-formatted-text[contains(text(), "Couldn’t schedule service appointment")]', po.shortWait)) {
                    po.log('error', web.getText('//lightning-formatted-text[contains(text(), "Couldn’t schedule service appointment")]'))
                    if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                }

                if (web.isVisible('//button[contains(text(), "מצא חלון זמן")]', po.waitHalfAMinute)) {
                    po.specialClick('//button[contains(text(), "מצא חלון זמן")]')
                }
                
                let findDayTries = 5
                while(!web.isVisible('(//div[contains(@class, "singleDay")])[1]', po.shortWait)) {
                    web.click('//button[text()="קדימה"]')
                    if (findDayTries == 0) {
                        po.log('warning', `לא נמצאו חלונות זמן אחרי ${findDayTries} נסיונות`)
                        break
                    } else {
                        findDayTries--
                    }  
                }
                
                if (web.isVisible('(//div[contains(@class, "singleDay")])[1]')) {
                    po.specialClick('(//div[contains(@class, "singleDay")])[1]')
                    po.specialClick('//span[contains(text(), "המצאות בגיר בבית")]//..//span[@class="slds-checkbox_faux"]')
                    
                    if (web.isVisible('//div[contains(text(), "סיבת בחירת החלון")]//button', po.longWait)) {
                        web.click('//div[contains(text(), "סיבת בחירת החלון")]//button')
                        func.pressARROW_DOWN()
                        func.pressENTER()
                    }

                    if (web.isVisible('//span[contains(text(), "הוסבר חיוג")]//..//span[@class="slds-checkbox_faux"]', po.longWait)) {
                        po.specialClick('//span[contains(text(), "הוסבר חיוג")]//..//span[@class="slds-checkbox_faux"]')
                    }
                }

                if (web.isVisible('//label[contains(text(), "בחרת חלון זמן מחוץ ל-SLA")]//..//button', po.longWait)) {
                    web.click('//label[contains(text(), "בחרת חלון זמן מחוץ ל-SLA")]//..//button')
                    func.pressARROW_DOWN()
                    func.pressENTER()
                    func.pressTAB()
                }

                if (web.isVisible('(//div[contains(@class, "singleDay selcted")])[1]') && web.isVisible(main.nextButtonNotDisabled)) {
                    let techDate = web.getText('(//div[contains(@class, "singleDay selcted")]//..//..//..//..//..//*[contains(text(), "יום")])[1]')
                    let techTime = web.getText('(//div[contains(@class, "singleDay selcted")])[1]')
                    po.log('success', `תאריך הגעת טכנאי: ${techDate} בשעה ${techTime}`)
                    if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
                } else if (web.isVisible('(//lightning-spinner)[1]', po.longWait) || web.isVisible('(//lightning-spinner)[2]', po.longWait)) {
                    let loadingTries = 10
                    while (web.isVisible('(//lightning-spinner)[1]', po.shortWait) || web.isVisible('(//lightning-spinner)[2]', po.shortWait)) {
                        if (web.isVisible(main.nextButtonNotDisabled)) {
                            break
                        } else if (loadingTries == 0) {
                            return
                        } else {
                            loadingTries--
                        } 
                    }
                }
            }
            
            if (web.isVisible(main.errorToastMessage, po.longWait) && web.isVisible(main.nextButtonNotDisabled, po.longWait)) {
                let errors = web.getElementCount(main.errorToastMessage)
                for (let x = 1; x <= errors; x++) {
                    po.log('error', web.getText(`(${main.errorToastMessage})[${x}]`))
                    web.click(`(${main.errorToastMessageCloseButton})[${x}]`)
                }
                if (web.isVisible(main.nextButtonNotDisabled)) web.click(main.nextButtonNotDisabled)
            }
        },

        getCustomerNumber: () => {
            let yesCustomerNumber = ''
            if (web.isVisible('//lightning-tab-bar//a[@data-label="תהליך מכר"]//..//..//a[@data-label="מידע קשור"]')) {
                web.click('//lightning-tab-bar//a[@data-label="תהליך מכר"]//..//..//a[@data-label="מידע קשור"]')
                web.pause(po.shortWait)
                
                let getYesCustomerNumberTries = 10
                while (yesCustomerNumber.length == 0) {
                    web.pause(po.waitASecond)
                    yesCustomerNumber = web.getText('//td[@data-label="מספר חשבון Yes"]')
                    if (getYesCustomerNumberTries == 0) break
                    else getYesCustomerNumberTries--
                }

                if (yesCustomerNumber == '') {
                    assert.fail('מספר לקוח יס ריק בתוך חלון מידע קשור')
                } else {
                    po.log('success', `מספר לקוח יס: ${yesCustomerNumber}`)
                }
                web.click('//lightning-tab-bar//a[@data-label="תהליך מכר"]')
            }
            return yesCustomerNumber
        },

        assertOrderSummary: () => {
            if (web.isVisible('//div[@class="order-summary"]')) {
                po.log('info', web.getText('//div[@class="order-summary"]'))
                if (web.isVisible(po.alphaMainPage.nextButtonNotDisabled, po.longWait)) {
                    web.click(po.alphaMainPage.nextButtonNotDisabled)
                }
            } else if (web.isVisible('//span[contains(text(), "בעיה בקריאה לממשק")]')) {
                let errorMessage = web.getText('//span[contains(text(), "בעיה בקריאה לממשק")]//..//..//..//..//lightning-formatted-rich-text')
                po.log('error', errorMessage)
                assert.fail(errorMessage)
            }
        },

        enterPaymentDetails: (email) => {
            if (web.isVisible('//c-payment-method//*[contains(text(), "אמצעי תשלום")]', po.waitHalfAMinute)) {
                web.click('//span[text()="הוראת קבע"]')

                po.specialClick('//label[contains(text(), "בנק")]//..//button')
                po.specialClick('//span[contains(text(), "ONE ZERO") or contains(@title, "ONE ZERO")]')

                web.type('//label[contains(text(), "סניף בנק")]//..//input', '001')
                po.specialClick('//*[contains(text(), "לקוחות - 001")]')

                web.type('//label[contains(text(), "מספר חשבון בנק")]//..//input', '123456')
                po.specialClick('//label[contains(text(), "אופן שליחה")]//..//button')
                po.specialClick(`//label[contains(text(), "אופן שליחה")]//..//span[@title='דוא"ל']`)

                web.waitForInteractable('//label[contains(text(), "שלח אל")]//..//input')
                web.clear('//label[contains(text(), "שלח אל")]//..//input')
                web.type('//label[contains(text(), "שלח אל")]//..//input', email)

                po.specialClick('//label[contains(text(), "מחזור חיוב")]//..//button')
                po.functions.pressENTER()
                web.click('//button[@title="המשך"]')
            } else {
                po.log('error', 'לא נפתח מסך אמצעי תשלום')
            }
        },

        assertOrder: () => {
            let main = po.alphaMainPage
            let newCustomerNumber = ''

            if (web.isVisible('//*[text()="ההזמנה נשלחה בהצלחה"]', po.waitThreeMinutes)) {
                if (web.isVisible('//div[contains(@class, "flowruntimeBody")]//div[contains(text(), "מספר לקוח")]')) {
                    newCustomerNumber = web.getText('//div[contains(@class, "flowruntimeBody")]//div[contains(text(), "מספר לקוח")]')
                    newCustomerNumber = newCustomerNumber.match(/\d+/g).join('')
                    if (newCustomerNumber.trim() === '') {
                        po.log('error', 'New Customer Number is empty')
                    } else {
                        po.log('success', 'New Customer Number: ' + newCustomerNumber)
                        return newCustomerNumber
                    }
                }
            } else if (web.isVisible('//*[text()=" בממשק הקמת אמצעי תשלום" or contains(text(), "ממשק שליחת טופס הוראת קבע נכשל")]', po.longWait)) {
                po.log('error', 'ממשק שליחת טופס הוראת קבע נכשל')
                web.refresh()
                let nextStepTries = 5
                while (web.isVisible(main.nextButtonNotDisabled, po.longWait)) {
                    web.click(main.nextButtonNotDisabled)
                    if (nextStepTries == 0) break
                    else nextStepTries--
                }
            } else {
                assert.fail(`לא נוצר מספר לקוח`)
            }
            
            return newCustomerNumber
        },

        updatePersonalDetails: () => {
            let func = po.functions
            
            web.click('//button[contains(text(), "עדכון פרטים אישיים")]')
            if (web.isVisible('//h2[contains(text(), "עדכון פרטים אישיים")]')) {
                var newName = func.generateName()
                var currentName = web.getValue('//span[contains(text(), "שם פרטי")]//..//..//..//input')
                var changeNameTries = 10
                while (newName == currentName) {
                    newName = func.generateName()
                    if (changeNameTries == 0) {
                        po.log('error', 'Failed to update new name')
                        break
                    } else if (newName != currentName) {
                        po.log('success', `Updated new name to: ${newName}`)
                        break
                    } else {
                        changeNameTries--
                    }
                }

                web.clear('//span[contains(text(), "שם פרטי")]//..//..//..//input')
                web.type('//span[contains(text(), "שם פרטי")]//..//..//..//input', newName)
                web.click('//*[(text()="הבא")]')

                if (web.isVisible('//*[contains(text(), "פרטים אישיים נקלטו בהצלחה")]')) {
                    po.log('success', 'פרטים אישיים נקלטו בהצלחה')
                    web.click('//button[contains(text(), "סיים")]')
                } else {
                    assert.fail('הייתה תקלה בשינוי פרטים אישיים')
                }
            } else {
                assert.fail('לא נפתח חלון עדכון פרטים אישיים')
            }

            if (web.isVisible('//span[@data-aura-class="forceActionsText"]//..//..//..//..//button[@title="סגור"]', po.longWait)) {
                web.click('//span[@data-aura-class="forceActionsText"]//..//..//..//..//button[@title="סגור"]')
            }
        },

        updatePaymentDetails: (repName) => {
            web.click('//button[contains(text(), "עדכון אמצעי תשלום")]')
            web.click('//span[contains(text(), "כרטיס אשראי")]')

            if (web.isVisible('//h2[contains(text(), "עדכון אמצעי תשלום")]')) {
                var newCreditCardNumber = '375510391000093'
                var newCreditCardId = '890108566'
                var newCreditCardYear = '2024'
                var newCreditCardMonth = '12'

                po.clickUntilElementIsVisible('//iframe[contains(@src, "https://cgmpiuat.creditguard.co.il")]', '//*[(text()="הבא")]')

                web.selectFrame('//iframe[contains(@src, "https://cgmpiuat.creditguard.co.il")]')
                web.scrollToElement('id=submitBtn')
                web.type('id=Track2CardNoDesigned', newCreditCardNumber)
                web.select('id=expMonth', `label=${newCreditCardMonth}`)
                web.select('id=expYear', `label=${newCreditCardYear}`)
                web.type('id=personalId', newCreditCardId)
                web.click('id=submitBtn')

                if (web.isVisible('//*[contains(text(), "עדכון אמצעי תשלום הסתיים בהצלחה")]')) {
                    po.log('success', `עדכון אמצעי תשלום הסתיים בהצלחה ללקוח: ${newCustomerNumber}`)
                    web.click('//button[contains(text(), "סיים")]')
                } else if (web.isVisible('//span[contains(text(), "הרשאות לא מספיקות")]')) {
                    assert.fail(`הרשאות לא מספיקות כדי לבצע שינוי אמצאי תשלום לנציג: ${repName}`)
                } else {
                    assert.fail(`הייתה שגיאה בעדכון אמצאי תשלום ללקוח: ${newCustomerNumber}`)
                }
            } else {
                assert.fail('לא נפתח חלון עדכון אמצעי תשלום')
            }

            if (web.isVisible('//span[@data-aura-class="forceActionsText"]//..//..//..//..//button[@title="סגור"]', po.longWait)) {
                web.click('//span[@data-aura-class="forceActionsText"]//..//..//..//..//button[@title="סגור"]')
            }
        },

        searchNewlyCreatedCustomer: (newCustomerNumber, paid) => {
            let func = po.functions
            let main = po.alphaMainPage
            let searchPage = po.searchCustomerPage

            if (!web.isVisible(searchPage.header, po.longWait)) {
                web.click(main.navigationBtn)
                web.click(main.navigationOptions.customers)
            }

            if (web.isVisible(searchPage.header, po.waitHalfAMinute)) {
                po.clickUntilElementIsVisible(searchPage.parameters.accountNumber, searchPage.searchParametersBtn)
                web.click(searchPage.parameters.accountNumber)
                web.type(searchPage.accountNumberInput, newCustomerNumber)

                func.pressTAB()
                web.click(searchPage.searchBtn)
            }

            if (web.isVisible(`//span[@class="bezeq-comp-link" and contains(text(), "${newCustomerNumber}")]`, po.longWait)) {
                po.log('success', web.getText('//c-alp360-billing-info'))
            } 

            let orderNumber
            let customerNumberHeader = `//c-alp360-billing-info//strong[contains(text(), "מספר לקוח")]//..//..//span[contains(text(), "${newCustomerNumber}")]`
            web.click('//li[@data-label="הזמנות"]')

            if (web.isVisible('//article[@aria-label="הזמנות"]//div[@class="slds-truncate"]//records-hoverable-link', po.longWait)) {
                orderNumber = web.getText('//article[@aria-label="הזמנות"]//div[@class="slds-truncate"]//records-hoverable-link')
                orderNumber = orderNumber.replace(/\D/g, '')
                po.log('success', `מספר הזמנה: ${orderNumber}`)
            }

            web.transaction(`Assert That Order ${orderNumber} Was Sent`)
            if (paid) {
                if (web.isVisible(customerNumberHeader, po.waitHalfAMinute)
                && web.isVisible('//article[@aria-label="הזמנות"]//span[contains(@title, "הזמנה נשלחה") or contains(text(), "בוצעה מכירה")]', po.longWait)) {
                    po.log('success', `הזמנה נשלחה בהצלחה ${orderNumber}`)
                } else {
                    po.log('error', `ההזמנה לא נשלחה ללקוח ${newCustomerNumber}`)
                }
            } else {
                if (web.isVisible(customerNumberHeader, po.longWait) && web.isVisible('//article[@aria-label="הזמנות"]//span[@title="בחירת אמצעי תשלום"]', po.longWait)) {
                    po.log('success', `ההזמנה נעצרה בבחירת אמצאי תשלום ${orderNumber}`)
                } else {
                    po.log('error', `ההזמנה לא נעצרה בבחירת אמצאי תשלום ${newCustomerNumber}`)
                }
            }

            if (web.isVisible('//span[@data-aura-class="forceActionsText"]//..//..//..//..//button[@title="סגור"]', po.longWait)) {
                web.click('//span[@data-aura-class="forceActionsText"]//..//..//..//..//button[@title="סגור"]')
            }

            let elementsString = ''
            let listElements = '//article[@aria-label="הזמנות"]//div[@class="slds-truncate"]'
            let listElementsCount = web.getElementCount(listElements)
            
            for (let x = 1; x <= listElementsCount; x++) {
                let listData = web.getText(`(${listElements})[${x}]`)
                if (listData.length > 1) {
                    elementsString += listData + ', '
                }     
            }

            po.log('info', `Order Data: ${elementsString}`)
            return orderNumber
        },

    }, /* end of sales */

    servicePage: {
        gantFrame: '//iframe[contains(@title, "Visualforce") or contains(@title, "Field Service")]',
        lightBoxFrame: '//iframe[@class="resourceLightboxIframe"]',
        candidatesFrame: '//iframe[@name="FSL__Candidates"]',
        
        openFieldServices: () => {
            po.specialClick(po.alphaMainPage.navigationBtn)
            po.specialClick(po.alphaMainPage.navigationOptions.fieldServices)

            let tries = 5
            while (!web.isVisible(po.servicePage.gantFrame, po.longWait) || tries > 0) {
                po.specialClick(po.alphaMainPage.navigationBtn)
                po.specialClick(po.alphaMainPage.navigationOptions.fieldServices)
                tries--
            }
            web.selectFrame(po.servicePage.gantFrame)
        },

        createNewPaka: (role) => {
            let main = po.alphaMainPage
            let activityNumber, jobNumber

            main.closeTabs()

            if (role != 'constractor') {
                po.specialClick(main.navigationBtn)
                web.click(main.navigationOptions.actions)

                let tries = 5
                while (!web.isVisible('//span[@title="מספר פעילות לביצוע"]', po.longWait)) {
                    web.refresh()
                    po.specialClick(main.navigationBtn)
                    web.click(main.navigationOptions.actions)
                    if (tries == 0) break
                    else tries--
                }
            }

            po.clickUntilElementIsVisible('//span[text()="Work Order YES"]', main.newButton)
            web.click(main.nextButton)

            if (role == 'constractor') {
                if (web.isVisible('//*[contains(text(), "Work Order YES")]')) {
                    po.clickUntilElementIsVisible('//div[contains(text(), "פעילות לביצוע")]//..//span[@class="uiOutputText"]', '//div[@class="actionsContainer"]//span[text()="שמור"]')
                }                
            } else {
                web.click(`//span[contains(text(), 'סוג פק"ע')]//..//..//a[@class="select"]`)
                web.click('(//*[@title="CH"])[1]')

                web.click('//span[contains(text(), "אישור לביצוע")]//..//..//input')
                web.click(`//span[contains(text(), 'אישור אמ"ת')]//..//..//input`)

                web.type('//span[contains(text(), "רחוב")]//..//..//textarea', 'יפה ירקוני 14')
                web.type('//span[contains(text(), "עיר")]//..//..//input', 'כפר סבא')

                web.type('//span[contains(text(), "סוג השליחות")]//..//..//input', 'T')
                web.click('(//*[@title="T"])[1]')

                web.type('//span[contains(text(), "סוג התקנה")]//..//..//input', 'B')
                web.click('(//*[@title="B"])[1]')

                web.click('//div[@class="actionsContainer"]//span[text()="שמור"]')
            }

            // activityNumber = web.execute(() => {
            //     let element = '//div[contains(text(), "פעילות לביצוע")]//..//span[@class="uiOutputText"]'
            //     let elementCount = document.evaluate(
            //         `count(${element})`,
            //         document, null, XPathResult.ANY_TYPE, null,
            //     ).numberValue

            //     if (elementCount == 1) {
            //         element = `(${element})[1]`
            //     } else if (elementCount == 2) {
            //         element = `(${element})[2]`
            //     }

            //     return document.evaluate(
            //         element, 
            //         document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
            //     ).singleNodeValue.innerText
            // })

            let activityNumberElement = '//div[contains(text(), "פעילות לביצוע")]//..//span[@class="uiOutputText"]'
            let activityNumberElementCount = web.getElementCount(activityNumberElement)

            if (activityNumberElementCount == 1) {
                activityNumberElement = `(${activityNumberElement})[1]`
            } else if (activityNumberElementCount == 2) {
                activityNumberElement = `(${activityNumberElement})[2]`
            }

            activityNumber = web.getText(activityNumberElement)

            if (activityNumber.trim() !== '') {
                po.log('success', 'New Activity Number: ' + activityNumber)

                web.execute(() => {
                    let element = '//a[@title="מידע קשור"]'
                    let elementCount = document.evaluate(
                        `count(${element})`,
                        document, null, XPathResult.ANY_TYPE, null,
                    ).numberValue

                    if (elementCount === 1) {
                        element = `(${element})[1]`
                    } else if (elementCount === 2) {
                        element = `(${element})[2]`
                    }

                    document.evaluate(
                        element, 
                        document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
                    ).singleNodeValue.click()
                })

                web.click(`//span[@title="ג'ובים"]//..//..//..//..//..//a[@title="חדש/ה"]`)
            } else {
                assert.fail('לא נוצרה פעילות לביצוע')
            }

            if (role == 'constractor') {
                if (web.isVisible(`//*[contains(text(), "צור ג'וב")]`)) {
                    web.click('//div[@class="actionsContainer"]//span[text()="שמור"]')
                } 
            } else {
                web.click('//span[contains(text(), "קטגוריית ציוד")]//..//..//a')
                web.click('(//*[@title="סטרימר"])[1]')
                web.click('//span[contains(text(), "התקנה/איסוף/תקלה")]//..//..//a')
                web.click('(//*[@title="התקנה"])[1]')
                web.click('//div[@class="actionsContainer"]//span[text()="שמור"]')
            }

            jobNumber = web.getText(`//div[contains(text(), "ג'וב")]//..//span[@class="uiOutputText"]`)
            po.log('success', 'New Job Number: ' + jobNumber)

            web.click(`//span[contains(text(), "פעילות לביצוע")]//..//..//a[@data-refid="recordId" and contains(text(), "${activityNumber}")]`)
            web.click(`//span[contains(text(), 'פק"עות')]//..//..//..//..//..//div[@title='חדש/ה']`)

            web.click('//*[contains(text(), "זמן שיבוץ מוקדם ביותר")]//..//input')
            web.pause(po.waitASecond)
            web.click('//*[@class="slds-is-today"]')
            web.pause(po.waitASecond)
            web.click('//*[contains(text(), "תאריך יעד")]//..//input')
            web.pause(po.waitASecond)
            web.click('//*[@class="slds-is-today"]')
            web.pause(po.waitASecond)
            web.click('//button[@name="SaveEdit"]')

            if (web.isVisible('//header[contains(@class, "pageErrorHeader")]', po.longWait)) {
                web.click('//*[contains(text(), "זמן שיבוץ מוקדם ביותר")]//..//input')
                web.pause(po.waitASecond)
                web.click('//*[@class="slds-is-today"]')
                web.pause(po.waitASecond)
                web.click('//*[contains(text(), "תאריך יעד")]//..//input')
                web.pause(po.waitASecond)
                web.click('//*[@class="slds-is-today"]')
                web.pause(po.waitASecond)
                web.click('//button[@name="SaveEdit"]')
            }

            if (web.isVisible(`//div[contains(text(), 'פק"ע')]//..//span[@class="uiOutputText"]`, po.longWait)) {
                po.log('success', web.getText(`//div[contains(text(), 'פק"ע')]//..//span[@class="uiOutputText"]`))
            } else if (web.isVisible(main.errorToastMessage, po.shortWait)) {
                po.log('warning', web.getText(main.errorToastMessage))
            }

            const newPakaNumber = web.getText(`//*[@slot="entityLabel" and contains(text(), 'פק"ע')]//..//..//..//*[contains(text(), 'SA')]`)
            if (newPakaNumber.trim() !== '') {
                po.log('success', 'New Paka Number: ' + newPakaNumber)
            } else {
                web.pause(po.shortWait)
                newPakaNumber = web.getText(`//*[@slot="entityLabel" and contains(text(), 'פק"ע')]//..//..//..//*[contains(text(), 'SA')]`)
                if (newPakaNumber.trim() !== '') {
                    po.log('success', 'New Paka Number: ' + newPakaNumber)
                } else {
                    assert.fail('לא נוצרה פק"ע')
                }
            }

            let element = '//div[contains(@class, "actionsContainer")]//lightning-button-menu//button'
            let elementCount = web.getElementCount(element)
            if (elementCount == 2) {
                element = `(${element})[2]`
            } else {
                element = `(${element})[1]`
            }

            if (web.isVisible(element)) {
                web.click(element)
                web.click('//span[text()="הרצת דריויישן"]')

                if (web.isVisible('//*[contains(text(), "הפעולה בוצעה בהצלחה")]')) {
                    po.log('success', 'הרצת דריויישן בוצעה בהצלחה')
                    web.click('//button[contains(text(), "סיים")]')
                } else {
                    po.log('error', 'הייתה שגיעה בהרצת דריויישן')
                }
            }
 
            // web.pause(po.waitHalfAMinute) // wait for paka to be synchronized
            return newPakaNumber
        },

        setAppointment: (tech, paka) => {
            po.selectWindow('new')
            web.selectFrame(po.servicePage.gantFrame)
            
            let tries = 5
            let techInGantTableElement = `(//div[@id="GanttContainer"]//a[contains(@title, "${tech}")]//..//..//..//..//..//..//..//..//div[contains(@data-col-date, "10:00")])[2]`
            let techPakaElement = `//*[contains(text(), "${paka}")]//..//..//..//..//div[@draggable="true"]`
            let createdPakaElement = `//div[@id="GanttContainer"]//div[@aria-label="${paka}"]`
            let isPakaDraggable = Boolean(web.getAttribute(techPakaElement, 'draggable'))

            function getScheduleTable() {
                web.click('//div[@id="GanttContainer"]//input[@placeholder="חיפוש טכנאי"]')
                web.type('//div[@id="GanttContainer"]//input[@placeholder="חיפוש טכנאי"]', tech)

                web.pause(po.shortWait)
                web.click('//div[@title="Jump to today"]')

                if (web.isVisible('//div[@class="dhx_scell_expand" and text()="+"]', po.longWait)) {
                    web.click('//div[@class="dhx_scell_expand" and text()="+"]')
                }
            }

            getScheduleTable()

            while (!web.isVisible(techInGantTableElement, po.longWait)) {
                web.refresh()
                web.pause(po.longWait)
                po.selectWindow('new')
                web.selectFrame(po.servicePage.gantFrame)
                getScheduleTable()
                if (tries == 0) break
                else tries--
            }

            if (web.isVisible(techPakaElement) && isPakaDraggable) {
                web.waitForInteractable(techPakaElement)
                web.dragAndDrop(
                    techPakaElement,
                    techInGantTableElement
                )
            } else {
                po.log('error', `לא ניתן לגרור פק"ע ${paka}`)
            }

            if (web.isVisible(createdPakaElement)) {
                po.log('success', `פק"ע ${paka} שובצה לטכנאי ${tech}`)
            } else {
                po.log('error', `פק"ע ${paka} לא שובצה לטכנאי ${tech}`)
            }
        },

        setSchedule: (name, phone) => {
            let service = po.servicePage

            if (web.isVisible(service.lightBoxFrame, po.longWait)) {
                web.selectFrame(service.gantFrame, service.lightBoxFrame)
            } else {
                let element = '//button[@name="ServiceAppointment.Booking_Screen"]'
                let elementCount = web.getElementCount(element)
                if (elementCount == 2) {
                    element = `(${element})[2]`
                } else {
                    element = `(${element})[1]`
                }

                if (web.isVisible(element)) {
                    web.click(element)
                }
            }

            if (web.isVisible('//c-work-order-details')) {
                if (web.isVisible('(//c-work-order-details//label[contains(text(), "שם איש קשר")]//..//input)[1]', po.longWait)) {
                    const contactName = web.getValue('(//c-work-order-details//label[contains(text(), "שם איש קשר")]//..//input)[1]')
                    if (contactName.trim() !== '') {
                        po.log('success', `שם איש קשר לפק"ע ${contactName}`)
                    } else {
                        po.log('warning', `לא מופיע שם איש קשר לפק"ע`)
                        web.type(`//label[contains(text(), 'שם איש קשר לפק"ע')]//..//input`, name)
                    }
                }
                
                if (web.isVisible('(//c-work-order-details//label[contains(text(), "טלפון איש קשר")]//..//input)[1]', po.longWait)) {
                    const contactPhone = web.getValue('(//c-work-order-details//label[contains(text(), "טלפון איש קשר")]//..//input)[1]')
                    if (contactPhone.trim() !== '') {
                        po.log('success', `טלפון איש קשר לפק"ע ${contactPhone}`)
                    } else {
                        po.log('warning', `לא מופיע טלפון איש קשר לפק"ע`)
                        web.type(`//label[contains(text(), 'טלפון איש קשר לפק"ע')]//..//input`, phone)
                    }
                }
            } 

            po.clickUntilElementIsVisible('(//div[contains(@class, "singleDay")])[1]', '//button[contains(text(), "מצא חלון זמן")]')
            if (web.isVisible('(//div[contains(@class, "singleDay")])[1]', po.waitHalfAMinute)) {
                web.click('(//div[contains(@class, "singleDay")])[1]')
            } else if (web.isVisible('//*[contains(text(), "לא נמצאו חלונות זמן")]', po.shortWait)) {
                let pickDayTries = 5
                while (!web.isVisible('(//div[contains(@class, "singleDay")])[1]', po.waitHalfAMinute)) {
                    if (pickDayTries == 0) break
                    web.click('//button[contains(text(), "קדימה")]')
                    pickDayTries--
                }

                if (web.isVisible('//*[contains(text(), "לא נמצאו חלונות זמן")]', po.shortWait)) {
                    assert.fail('לא נמצאו חלונות זמן לשיבוץ פק"ע')
                } else {
                    web.click('(//div[contains(@class, "singleDay")])[1]')
                }
            }

            if (web.isVisible('//c-work-order-regulation//lightning-input//label', po.longWait)) {
                let checkboxes = web.getElementCount('//c-work-order-regulation//lightning-input//label')
                for (let box = 1; box <= checkboxes; box++) {
                    web.pause(po.shortWait)
                    web.isVisible(`(//c-work-order-regulation//lightning-input//label)[${box}]`) 
                    && web.click(`(//c-work-order-regulation//lightning-input//label)[${box}]`)
                }
            }

            if (web.isVisible('(//div[contains(@class, "singleDay selcted")])[1]') && web.isVisible('//button[@title="תאם" and not(@disabled)]')) {
                let techDate = web.getText('(//div[contains(@class, "singleDay selcted")]//..//..//..//..//..//*[contains(text(), "יום")])[1]')
                let techTime = web.getText('(//div[contains(@class, "singleDay selcted")])[1]')
                po.log('success', `תאריך הגעת טכנאי: ${techDate} בשעה ${techTime}`)
                web.click('//button[@title="תאם" and not(@disabled)]')
            }

            if (web.isVisible('//button[@title="תאם" and not(@disabled)]', po.longWait)) {
                web.click('//button[@title="תאם" and not(@disabled)]')
            }
            
            let message
            if (web.isVisible('//*[contains(text(), "הפגישה נקבעה בהצלחה")]', po.waitTwoMinutes)) {
                message = web.getText('//*[contains(text(), "הפגישה נקבעה בהצלחה")]')
                po.log('success', message)
            } else {
                if (web.isVisible('//section[@class="bodyWrapper"]//h3')) {
                    message = web.getText('//section[@class="bodyWrapper"]//h3')
                    assert.fail(message)
                } else {
                    assert.fail('שיבוץ טכנאי נכשל')
                }
            }

            if (web.isVisible('//*[name()="svg" and contains(@ng-click, "closeLightbox") or @title="סגור חלון זה"]', po.shortWait)) {
                web.click('//*[name()="svg" and contains(@ng-click, "closeLightbox") or @title="סגור חלון זה"]')
            } else if (web.isVisible(service.gantFrame, po.shortWait)) {
                web.selectFrame(service.gantFrame)
                if (web.isVisible('//*[name()="svg" and contains(@ng-click, "closeLightbox") or @title="סגור חלון זה"]', po.shortWait)) {
                    web.click('//*[name()="svg" and contains(@ng-click, "closeLightbox") or @title="סגור חלון זה"]')
                }
            } else {
                po.selectWindow('new')
                if (web.isVisible(service.gantFrame, po.shortWait)) {
                    web.selectFrame(service.gantFrame)
                }
                if (web.isVisible('//*[name()="svg" and contains(@ng-click, "closeLightbox") or @title="סגור חלון זה"]', po.shortWait)) {
                    web.click('//*[name()="svg" and contains(@ng-click, "closeLightbox") or @title="סגור חלון זה"]')
                }
            }
        },

        assignToRecommendedTechnician: (paka) => {
            if (web.isVisible('//div[@class="assign-to-recommended"]', po.waitHalfAMinute)) {
                po.log('success', web.getText('id=slotsSentence'))
                web.click('//div[@class="assign-to-recommended"]')
                web.click(`(//span[text()="${paka}"]//..//..//..//..//div[contains(@class, "SingleTask")]//..//input)[1]`)
                web.click('id=actionQuickFirst')

                if (web.isVisible('(//div[contains(normalize-space(), "שיבוץ הסתיים")])[1]')) {
                    po.log('success', web.getText('(//div[contains(normalize-space(), "שיבוץ הסתיים")])[1]'))
                    web.click('//span[@ng-click="showResults()"]')

                    if (web.isVisible(`//div[@class="ScheduleResultRow"]//span[text()="${paka}"]`)) {
                        po.log('success', 'פק"ע שובצה בהצלחה: ' + web.getText(`//div[@class="ScheduleResultRow"]//span[text()="${paka}"]`))
                    } else {
                        po.log('error', 'פק"ע לא שובצה')
                    }
                }
            } else if (web.isVisible('//div[@class="get-slots-error"]', po.waitHalfAMinute)) {
                let message = web.getText('//div[@class="slots-panel-title"]')
                po.log('warning', 'לא נמצאו מועמדים ' + message)
            } else if (web.isVisible('id=ScheduledResultsTable', po.longWait)) {
                let status = web.getText('id=ScheduledResultsTable')
                if (status.includes('לא נמצאו מועמדים')) {
                    po.log('error', status)
                }
            } else {
                const selectedTechnician = web.getText('//div[contains(@class, "GS-grade-excellent")]//..//..//div[@class="candidates-container-row"]//h1')

                web.click('//div[contains(@class, "GS-grade-excellent")]//..//..//div[@class="candidates-container-row"]')
                web.click('(//div[contains(@class, "GS-grade-excellent")]//..//div[contains(text(), "שבץ")])[1]')

                if (web.isVisible(`//field-in-card//a[@title="${selectedTechnician}"]`)) {
                    po.log('success', `${selectedTechnician} שובץ בהצלחה`)
                } else {
                    po.log('error', `${selectedTechnician} לא שובץ בהצלחה`)
                }
            }

            web.selectFrame(po.servicePage.gantFrame)
            if (web.isVisible('//*[name()="svg" and contains(@ng-click, "closeLightbox") or @title="סגור חלון זה"]')) {
                web.click('//*[name()="svg" and contains(@ng-click, "closeLightbox") or @title="סגור חלון זה"]')
            }
        },

        selectPaka: (paka, action) => {
            let techPakaElement = `//*[contains(text(), "${paka}")]//..//..//..//..//div[contains(@ng-class, "DraggableSingleTask")]`

            po.selectWindow('new')
            web.selectFrame(po.servicePage.gantFrame)

            if (web.isVisible('id=TaskListSorting')) {
                web.type('id=TaskSearchFilterInput', paka)
                web.pause(po.shortWait)
                web.click('//button[@id="SearchOnServer"]')

                let searchPakaTries = 5
                while (!web.isVisible(techPakaElement, po.longWait) || searchPakaTries == 0) {
                    web.type('id=TaskSearchFilterInput', paka)
                    web.pause(po.shortWait)
                    web.click('//button[@id="SearchOnServer"]')
                    
                    let filterTries = 20
                    let value = web.getValue('id=TaskSearchFilterInput')
                    web.click('id=TaskSearchFilterInput')

                    while (value != '' || filterTries == 0) {
                        po.functions.pressBACKSPACE()
                        value = web.getValue('id=TaskSearchFilterInput')
                        filterTries--
                    }

                    web.type('id=TaskSearchFilterInput', paka)
                    web.click('//button[@id="SearchOnServer"]')
                    searchPakaTries--
                }
            } else if (web.isVisible('//div[@class="NoServicesFound"]', po.longWait)) {
                assert.fail(web.getText('//div[@class="NoServicesFound"]'))
            }

            if (action) {
                if (web.isVisible(`//div[@title="${action}"]`, po.longWait)) {
                    web.click(`//div[@title="${action}"]`)
                } else {
                    web.click(techPakaElement)
                    web.click(`//div[@title="${action}"]`)
                }
            }
        },

        removeSchedules: (tech, paka) => {            
            web.type('//div[@id="GanttContainer"]//input[@placeholder="חיפוש טכנאי"]', tech)
            
            web.pause(po.shortWait)
            if (web.isVisible('//div[contains(@class, "dailyViewUtilization")]', po.shortWait)) {
                po.log('info', web.getText('//div[contains(@class, "dailyViewUtilization")]'))
            }

            if (paka) {
                web.transaction(`Remove Paka ${paka} From ${tech}`)
                let removeFromScheduleButtonElements = '//*[contains(@id, "unschedule")]//div[contains(text(), "הסרה משיבוץ")]'
                let createdPakaElement = `//div[@id="GanttContainer"]//div[@aria-label="${paka}"]`

                web.rightClick(createdPakaElement)

                if (web.isVisible(`(${removeFromScheduleButtonElements})[2]`, po.longWait)) {
                    web.click(`(${removeFromScheduleButtonElements})[2]`)
                } else if (web.isVisible(`(${removeFromScheduleButtonElements})[1]`, po.longWait)) {
                    web.click(`(${removeFromScheduleButtonElements})[1]`)
                }

                if (web.isAlertPresent()) {
                    web.pause(po.waitASecond)
                    web.alertAccept()
                    web.pause(po.longWait * 2)
                    if (!web.isVisible(`//div[@id="GanttContainer"]//div[contains(@aria-label, "${paka}")]`, po.longWait)) {
                        po.log('success', `פק"ע ${paka} נמחקה משיבוץ של הטכנאי ${tech}`)
                    } else {
                        po.log('error', `פק"ע ${paka} לא נמחקה משיבוץ של הטכנאי ${tech}`)
                    }
                }
                return
            }

            web.transaction(`Remove All Pakas From ${tech}`)
            let scheduleElements = '//div[@id="GanttContainer"]//div[contains(@aria-label, "SA")]'

            if (web.isVisible(scheduleElements, po.waitHalfAMinute)) {
                let schedules = web.getElementCount(scheduleElements)

                if (web.isVisible(`//span[@class="resource-highlight-on-search" and contains(text(), "${tech}")]`)) {
                    for (let x = 1; x < schedules; x++) {
                        if (web.isVisible(`(${scheduleElements})[${x}]`, po.longWait)) {
                            let paka = web.getAttribute(`(${scheduleElements})[${x}]`, 'aria-label')
                            web.rightClick(`(${scheduleElements})[${x}]`)

                            let removeFromScheduleButtonElements = '//*[contains(@id, "unschedule")]//div[contains(text(), "הסרה משיבוץ")]'
                            let removeFromScheduleButtons = web.getElementCount(removeFromScheduleButtonElements)

                            for (let y = removeFromScheduleButtons; y >= removeFromScheduleButtons; y--) {
                                if (!web.isVisible(`(${removeFromScheduleButtonElements})[${y}]`, po.longWait)) {
                                    continue
                                } else {
                                    web.click(`(${removeFromScheduleButtonElements})[${y}]`)
                                    if (web.isAlertPresent()) {
                                        web.pause(po.waitASecond)
                                        web.alertAccept()
                                        web.pause(po.longWait * 2)
                                        if (!web.isVisible(`//div[@id="GanttContainer"]//div[contains(@aria-label, "${paka}")]`, po.waitHalfAMinute)) {
                                            po.log('success', `פק"ע ${paka} נמחקה משיבוץ של הטכנאי ${tech}`)
                                        } else {
                                            po.log('error', `פק"ע ${paka} לא נמחקה משיבוץ של הטכנאי ${tech}`)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                po.log('info', `Tech ${tech} has no active schedules`)
                return
            }
        },
    },

}
