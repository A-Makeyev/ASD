log.info(`2. תיאום מקוסטם לפקע בגאנט - קבלנים ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360

var firstName = func.generateName()
var lastName = `Automation - ${Math.random().toString().slice(2, 8)}`
const email = env.email ? env.email : func.generateEmail()
const phone = func.generatePhone()
const serviceRep = env.serviceRep
const techRep = env.techRep
const contractorCompany = 'יוביטל'
const contractorName = 'חנוך גיבילי'

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Create New Paka')
const newPakaNumber = service.createNewPaka(techRep, true, false)

web.transaction(`Login As Contractor ${contractorName} From ${contractorCompany}`)
main.loginAsContractor(contractorCompany, contractorName)
po.specialClick(`//div[@data-aura-class="forceCommunityGlobalNavigation"]//span[text()='גאנט פק"עות']`)

web.transaction('Select Field Service')
web.selectFrame(service.gantFrame)
web.select('id=PredefinedFilterSelector', 'label=א. כל הפק"עות על הגאנט')

web.transaction(`Select Paka ${newPakaNumber}`)
// service.removeSchedules(techRep)
service.selectPaka(newPakaNumber, 'schedule')

web.transaction(`Assert Paka ${newPakaNumber} Details`)
web.selectFrame(service.gantFrame, service.lightBoxFrame)
service.assertOrderContactDetails(firstName, phone) 

web.transaction('Find Time')
web.click('//button[contains(text(), "מצא חלון זמן")]')
web.click('(//div[contains(@class, "singleDay")])[1]')

if (web.isVisible('//c-work-order-regulation//lightning-input//label', po.longWait)) {
    let checkboxes = web.getElementCount('//c-work-order-regulation//lightning-input//label')
    for (let box = 1; box <= checkboxes; box++) {
        web.isVisible(`(//c-work-order-regulation//lightning-input//label)[${box}]`) && web.click(`(//c-work-order-regulation//lightning-input//label)[${box}]`)
    }
}

web.transaction('Send Details')
web.click('//button[@title="תאם" and not(@disabled)]')

if (!web.isVisible('//div[@id="cmpHolder"]//h3', po.waitHalfAMinute)) {
    web.click('//button[@title="תאם" and not(@disabled)]')
}

if (web.isVisible('//div[@id="cmpHolder"]')) {
    let message = web.getText('//div[@id="cmpHolder"]//h3')

    if (message.includes('הפגישה נקבעה בהצלחה')) {
        po.log('success', message)

        web.selectFrame(service.gantFrame)
        web.click('//*[name()="svg" and @ng-click="closeLightbox()"]')
        web.click('//div[@title="תיאום"]')

        web.selectFrame(service.gantFrame, service.lightBoxFrame)
        po.log('info', 'פרטי פק"ע: ' + web.getText(`//div[@title='פרטי פק"ע']//..//..//div[@class="slds-tile__detail"]`))
        po.log('info', 'פרטי תיאום: ' + web.getText(`//div[@title='פרטי תיאום']//..//..//div[@class="slds-tile__detail"]`))
    } else if (message.includes('שיבוץ נכשל')) {
        assert.fail('error', message)
    }
}
