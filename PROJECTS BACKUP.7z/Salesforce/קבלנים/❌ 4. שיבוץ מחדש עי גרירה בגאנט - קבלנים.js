log.info(`4. שיבוץ מחדש עי גרירה בגאנט ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const email = env.email ? env.email : func.generateEmail()
const serviceRep = env.serviceRep
const techRep = env.techRep
const contractorCompany = 'יוביטל'
const contractorName = 'חנוך גיבילי'

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction(`Login As Contractor ${contractorName} From ${contractorCompany}`)
main.loginAsContractor(contractorCompany, contractorName)

web.transaction('Find Service')
po.specialClick(`//div[@data-aura-class="forceCommunityGlobalNavigation"]//span[text()='פק"עות']`)

var serviceElement = '(//span[@class="slds-truncate" and contains(text(), "פתוח") or contains(text(), "ממתין לביצוע") or contains(text(), "בנסיעה") or contains(text(), "בהמתנה")]//..//..//..//..//..//a[contains(@title, "SA")])[1]'
var serviceNumber = ''

if (web.isVisible(serviceElement, po.waitHalfAMinute)) {
    serviceNumber = web.getText(serviceElement)
    po.log('success', `נמצאה פק"ע: ${serviceNumber}`)
}

po.specialClick(`//div[@data-aura-class="forceCommunityGlobalNavigation"]//span[text()='גאנט פק"עות']`)

web.transaction('Drag Task To Other Technician')
web.selectFrame(service.gantFrame)
web.select('id=PredefinedFilterSelector', 'label=א. כל הפק"עות על הגאנט')

web.click('id=serviceSearchsWrapper')
web.type('id=TaskSearchFilterInput', serviceNumber)

web.pause(po.shortWait)
web.click('//button[@id="SearchOnServer"]')

if (web.isVisible('id=TaskListSorting')) {
    web.click('id=matchGanttCheckbox')
} else if (web.isVisible('//div[@class="NoServicesFound"]', po.longWait)) {
    assert.fail(web.getText('//div[@class="NoServicesFound"]'))
} 

if (web.isVisible('(//div[@id="TaskListItems"]//div[@draggable="true"])[1]')) {
    web.dragAndDrop(
        '(//div[@id="TaskListItems"]//div[@draggable="true"])[1]',
        '//div[@class="dhx_cal_data"]'
    )
} else {
    po.log('error', 'לא נמצאה פק"ע שאפשר לגרור')
}

web.transaction('Assert Scheduled Task')
if (web.isVisible('//div[@class="ServiceEvent" or @class="jeopardyOnService"]', po.longWait)) {
    let scheduleId = web.getText('//div[@class="ServiceEvent" or @class="jeopardyOnService"]//..//..//div[contains(@class, "ServiceEventPadding")]')
    po.log('success', `שובץ בהצלחה: ${scheduleId}`)
} else {
    assert.fail('השיבוץ לא הצליח, לא ניתן לגרור את המשימה')
}
