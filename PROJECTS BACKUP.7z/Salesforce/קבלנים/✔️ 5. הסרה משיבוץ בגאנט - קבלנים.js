log.info(`5. הסרה משיבוץ בגאנט - קבלנים ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const email = env.email ? env.email : func.generateEmail()
const serviceRep = env.serviceRep
const techRep = env.techRep
const contractorCompany = 'יוביטל'
const contractorName = 'חנוך גיבילי'

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction(`Login As Contractor ${contractorName} From ${contractorCompany}`)
main.loginAsContractor(contractorCompany, contractorName, 'פעילויות לביצוע')

web.transaction('Create New Paka')
const newPakaNumber = service.createNewPaka(techRep, true, true)

web.transaction('Drag Task To Other Technician')
web.selectFrame(service.gantFrame)
web.select('id=PredefinedFilterSelector', 'label=א. כל הפק"עות על הגאנט')

web.transaction(`Select Paka ${newPakaNumber}`)
service.selectPaka(newPakaNumber)

web.transaction('Remove Scheduling')
service.removeSchedules(techRep, newPakaNumber)
