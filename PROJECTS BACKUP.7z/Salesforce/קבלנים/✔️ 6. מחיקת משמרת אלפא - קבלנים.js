log.info(`6. מחיקת משמרת אלפא ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const email = env.email ? env.email : func.generateEmail()
const serviceRep = env.serviceRep
const techRep = env.techRep
const contractorCompany = 'יוביטל'
const contractorName = 'חנוך גיבילי'

po.log('info', `Email: ${email}`)
po.log('info', `repName: ${serviceRep}`)

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)
main.assertApplicationError()

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Open Shift Screen')
web.click('//div[@class="slds-icon-waffle"]')
web.type('//one-app-launcher-menu//input[@type="search"]', 'משמרות')
web.click('//a[@id="Shift"]//b') 

web.click('//button[@title="בחר תצוגת רשימה: משמרות"]')
web.click('(//ul[@role="listbox"]//span[contains(text(), "כל המשמרות")])[1]')
web.click('(//td[@role="gridcell"]//input)[1]')

var firstShiftNumber = web.getText('(//a[@data-refid="recordId"])[1]')
var firstShiftDate = web.getText('(//span[@class="slds-truncate uiOutputDateTime"])[1]')
log.info('First Shift Number: ' + firstShiftNumber)
log.info('First Shift Date: ' + firstShiftDate)

web.transaction(`Delete Shift -> ${firstShiftNumber}`)
web.click('(//a[contains(@class, "rowActionsPlaceHolder")])[1]')
web.click('//a[@data-target-selection-name="sfdc:StandardButton.Shift.Delete"]')
web.click('//div[@role="dialog"]//button[@title="מחיקה"]')

if (!web.isVisible(firstShiftNumber, po.longWait)) {
    po.log('success', `Deleted Shift: ${firstShiftNumber} on date: ${firstShiftDate}`)
} else {
    assert.fail(`Shift: ${firstShiftNumber} on date: ${firstShiftDate} was not deleted`)
}
