log.info(`חיפוש מועמדים לפקע בגאנט - קבלנים ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const email = env.email ? env.email : func.generateEmail()
const firstName = func.generateName()
const phone = func.generatePhone()
const serviceRep = env.serviceRep
const techRep = env.techRep
const contractorCompany = 'יוביטל'
const contractorName = 'חנוך גיבילי'

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Create New Paka')
const newPakaNumber = service.createNewPaka()

web.transaction('Open Field Services')
service.openFieldServices()

web.transaction(`Set Paka ${newPakaNumber} Appointment To Tech ${techRep}`)
service.selectPaka(newPakaNumber)
service.setAppointment(techRep, newPakaNumber)

web.transaction(`Schedule Paka ${newPakaNumber}`)
service.selectPaka(newPakaNumber, 'תיאום') 
service.setSchedule(firstName, phone)

web.transaction('Assign To Recommended Technician')
service.selectPaka(newPakaNumber, 'מועמדים')
service.assignToRecommendedTechnician(newPakaNumber)

web.transaction('Update Status To Dispatched')
web.click('//div[@title="עדכון סטטוס"]')
web.selectFrame(service.gantFrame, service.lightBoxFrame)

web.select('//label[contains(text(), "סטטוס")]//..//select', 'value=Dispatched')
web.click('//button[text()="הבא"]')

if (web.isVisible('//*[text()="סטטוס עודכן בהצלחה"]')) {
    po.log('success', 'סטטוס עודכן בהצלחה לנשלח')
    web.selectFrame(service.gantFrame)

    if (web.isVisible('//*[name()="svg" and @ng-click="closeLightbox()"]', po.longWait)) {
        web.click('//*[name()="svg" and @ng-click="closeLightbox()"]')
    }

    if (web.isVisible(`//*[contains(text(), "${newPakaNumber}")]//..//..//..//service-list-column[text()="נשלח"]`)) {
        po.log('success', 'פק"ע עודכנה בהצלחה לנשלח')
    } else {
        assert.fail('פק"ע לא עודכנה לנשלח')
    }
} else {
    assert.fail('סטטוס לא עודכן לנשלח')
}

web.transaction(`Login As Contractor ${contractorName} From ${contractorCompany}`)
main.loginAsContractor(contractorCompany, contractorName, 'גאנט פק"עות')

web.transaction(`Assign To Recommended Technician As Contractor ${contractorName}`)
service.selectPaka(newPakaNumber, 'מועמדים')
service.assignToRecommendedTechnician(newPakaNumber)
