log.info(`3. שיבוץ בעזרת גרירת פקע בגאנט ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const phone = func.generatePhone()
const email = env.email ? env.email : func.generateEmail()
const serviceRep = env.serviceRep
const techRep = env.techRep
const contractorCompany = 'יוביטל'
const contractorName = 'חנוך גיבילי'

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Create Paka')
const newPaka = service.createNewPaka(techRep, true, false)

web.transaction(`Login As Contractor ${contractorName} From ${contractorCompany}`)
web.selectWindow(web.getWindowHandles()[1])
main.loginAsContractor(contractorCompany, contractorName)

po.specialClick(`//div[@data-aura-class="forceCommunityGlobalNavigation"]//span[text()='גאנט פק"עות']`)

web.transaction('Drag Task To Other Technician')
web.selectFrame(service.gantFrame)
web.select('id=PredefinedFilterSelector', 'label=א. כל הפק"עות על הגאנט')

let techInGantTableElement = `//div[@id="GanttContainer"]//a[contains(@title, "${techRep}")]`
let techPakaElement = `//*[contains(text(), "${newPaka}")]//..//..//..//..//div[@draggable="true"]`
let createdPakaElement = `//div[@id="GanttContainer"]//div[@class="ServiceEvent"]//div[contains(text(), "${newPaka}")]`

if (web.isVisible('id=TaskListSorting')) {
    web.click('id=serviceSearchsWrapper')
    web.type('id=TaskSearchFilterInput', newPaka)
    web.click('//button[@id="SearchOnServer"]')

    while (!web.isVisible(techPakaElement, po.longWait) || tries == 0) {
        web.click('id=TaskSearchFilterInput')
        
        let tries = 20
        let value = web.getValue('id=TaskSearchFilterInput')
        while (value != '' || tries != 0) {
            tries--
            po.functions.pressBACKSPACE()
            value = web.getValue('id=TaskSearchFilterInput')
        }
        
        web.type('id=TaskSearchFilterInput', newPaka)
        web.click('//button[@id="SearchOnServer"]')
    }
} else if (web.isVisible('//div[@class="NoServicesFound"]', po.longWait)) {
    assert.fail(web.getText('//div[@class="NoServicesFound"]'))
}

web.type('//div[@id="GanttContainer"]//input[@placeholder="חיפוש טכנאי"]', techRep)
web.pause(po.shortWait)

web.transaction(`Drag Task To Tech ${techRep}`)
if (web.isVisible(techPakaElement)) {
    web.waitForInteractable(techPakaElement)
    web.dragAndDrop(
        techPakaElement,
        techInGantTableElement
    )
} 

if (web.isVisible(createdPakaElement)) {
    po.log('success', `פק"ע ${newPaka} שובצה לטכנאי ${techRep}`)
} else {
    po.log('error', `פק"ע ${newPaka} לא שובצה לטכנאי ${techRep}`)
}

web.transaction(`Assert Scheduled Task Assigned To ${techRep}`)
if (web.isVisible(createdPakaElement)) {
    po.log('success', `פק"ע ${newPaka} שובצה לטכנאי ${techRep}`)
} else {
    po.log('error', `פק"ע ${newPaka} לא שובצה לטכנאי ${techRep}`)
}

web.transaction(`Removed Task From ${techRep}`)
web.rightClick(createdPakaElement)

const removeFromScheduleButtonElements = '//*[contains(@id, "unschedule")]//div[contains(text(), "הסרה משיבוץ")]'
const removeFromScheduleButtons = web.getElementCount(removeFromScheduleButtonElements)

for (let x = 1; x <= removeFromScheduleButtons; x++) {
    if (!web.isVisible(`(${removeFromScheduleButtonElements})[${x}]`, po.longWait)) {
        continue
    } else {
        web.click(`(${removeFromScheduleButtonElements})[${x}]`)
        if (web.isAlertPresent()) {
            web.alertAccept()
            web.pause(po.longWait)
            if (!web.isVisible(createdPakaElement, po.longWait)) {
                po.log('success', `פק"ע ${newPaka} נמחקה משיבוץ של הטכנאי ${techRep}`)
            } else {
                po.log('error', `פק"ע ${newPaka} לא נמחקה משיבוץ של הטכנאי ${techRep}`)
            }
        }
    }
}
