log.info(`11. SA תיאום מחדש של פקע - קבלנים ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const sales = po.sales
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const serviceRep = env.serviceRep
const email = env.email ? env.email : func.generateEmail()
const phone = func.generatePhone()
const firstName = func.generateName()
const techRep = env.techRep
const contractorCompany = 'יוביטל'
const contractorName = 'חנוך גיבילי'

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Create New Paka')
const newPakaNumber = service.createNewPaka()

web.transaction(`Login As Contractor ${contractorName} From ${contractorCompany}`)
main.loginAsContractor(contractorCompany, contractorName)
po.specialClick(`//div[@data-aura-class="forceCommunityGlobalNavigation"]//span[text()='גאנט פק"עות']`)

web.transaction('Select Field Service')
if (web.isExist('id=loadingSFLogo', po.waitHalfAMinute)) {
    po.log('info', 'Loading Field Service')
    web.waitForNotExist('id=loadingSFLogo')
}

web.selectFrame(service.gantFrame)
web.select('id=PredefinedFilterSelector', 'label=א. כל הפק"עות על הגאנט') 

web.transaction(`Select Paka ${newPakaNumber}`)
service.selectPaka(newPakaNumber, 'schedule')

web.transaction(`Assert Paka ${newPakaNumber} Details`)
web.selectFrame(service.gantFrame, service.lightBoxFrame)
service.assertOrderContactDetails(firstName, phone) 

web.transaction('Create Schedule')
if (web.isVisible('//button[contains(text(), "מצא חלון זמן")]', po.longWait)) {
    po.specialClick('//button[contains(text(), "מצא חלון זמן")]')
}

if (web.isVisible('(//div[contains(@class, "singleDay")])[1]')) {
    po.specialClick('(//div[contains(@class, "singleDay")])[1]')
    po.specialClick('//span[contains(text(), "המצאות בגיר בבית")]//..//span[@class="slds-checkbox_faux"]')
    po.specialClick('//span[contains(text(), "הוסבר חיוג")]//..//span[@class="slds-checkbox_faux"]')
}

if (web.isVisible('//label[contains(text(), "בחרת חלון זמן מחוץ ל-SLA")]//..//button', po.longWait)) {
    web.click('//label[contains(text(), "בחרת חלון זמן מחוץ ל-SLA")]//..//button')
    func.pressARROW_DOWN()
    func.pressENTER()
    func.pressTAB()
}

if (web.isVisible('(//div[contains(@class, "singleDay selcted")])[1]') && web.isVisible('//*[@aria-disabled="false" and (text()="תאם")]')) {
    let techDate = web.getText('(//div[contains(@class, "singleDay selcted")]//..//..//..//..//..//*[contains(text(), "יום")])[1]')
    let techTime = web.getText('(//div[contains(@class, "singleDay selcted")])[1]')
    po.log('success', `תאריך הגעת טכנאי: ${techDate} בשעה ${techTime}`)
    web.click('//*[@aria-disabled="false" and (text()="תאם")]')
}

if (web.isVisible('//*[contains(text(), "הפגישה נקבעה בהצלחה")]')) {
    po.log('success', web.getText('//*[contains(text(), "הפגישה נקבעה בהצלחה")]'))
} else {
    assert.fail('פגישה לא נקבעה')
}
