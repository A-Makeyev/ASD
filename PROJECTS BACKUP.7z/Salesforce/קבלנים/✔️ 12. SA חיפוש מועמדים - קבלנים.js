log.info(`12. SA חיפוש מועמדים - קבלנים ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const email = env.email ? env.email : func.generateEmail()
const firstName = func.generateName()
const phone = func.generatePhone()
const serviceRep = env.serviceRep
const techRep = env.techRep
const contractorCompany = 'יוביטל'
const contractorName = 'חנוך גיבילי'

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Create New Paka')
const newPakaNumber = service.createNewPaka()

web.transaction('Open Field Services')
service.openFieldServices()

web.transaction(`Set Paka ${newPakaNumber} Appointment To Tech ${techRep}`)
service.selectPaka(newPakaNumber)
service.setAppointment(techRep, newPakaNumber)

web.transaction(`Login As Contractor ${contractorName} From ${contractorCompany}`)
main.loginAsContractor(contractorCompany, contractorName, 'פק"עות')

web.transaction(`Schedule Paka ${newPakaNumber} As Contractor ${contractorName}`)
web.click(`//span[contains(text(), 'פק"עות')]//..//..//..//button[contains(@title, 'בחר תצוגת רשימה')]`)
web.click(`//div[contains(@class, 'uiAbstractList')]//span[text()='כל הפק"עות']`)
web.type('//div[contains(@class, "autocompleteWrapper")]//input', newPakaNumber)

func.pressENTER()
web.click('//div[contains(@class, "autocompleteWrapper")]//input')

if (web.isVisible(`//div[@class="listContent"]//span[@title="${newPakaNumber}"]`, po.longWait)) {
    web.click(`//div[@class="listContent"]//span[@title="${newPakaNumber}"]`)
} else {
    func.pressENTER()
    web.type('//div[contains(@class, "autocompleteWrapper")]//input', newPakaNumber)
    web.click('//div[contains(@class, "autocompleteWrapper")]//input')
    web.click(`//div[@class="listContent"]//span[@title="${newPakaNumber}"]`)
}

web.click('//button[@name="ServiceAppointment.Booking_Screen"]')
service.setSchedule(firstName, phone)

web.transaction(`Select Paka ${newPakaNumber}`)
po.specialClick(`//div[@data-aura-class="forceCommunityGlobalNavigation"]//span[text()='גאנט פק"עות']`)
web.selectFrame(po.servicePage.gantFrame)
service.selectPaka(newPakaNumber, 'מועמדים')

var grade, selectedTechnician
if (web.isVisible('(//div[contains(@class, "GS-grade-excellent")])[1]', po.waitHalfAMinute)) {
    grade = '(//div[contains(@class, "GS-grade-excellent")])[1]'
} else if (web.isVisible('(//div[contains(@class, "GS-grade-ok")])[1]', po.waitHalfAMinute)) {
    grade = '(//div[contains(@class, "GS-grade-ok")])[1]'
} else if (web.isVisible('//div[@class="get-slots-error"]', po.longWait)) {
    let message = web.getText('//div[@class="slots-panel-title"]')
    assert.fail('לא נמצאו מועמדים ' + message)
}

var selectedTechnician = web.getText(`${grade}//..//..//div[@class="candidates-container-row"]//h1`)

web.transaction(`Schedule Technician -> ${selectedTechnician}`)
web.click(`${grade}//..//..//div[@class="candidates-container-row"]`)
web.click(`${grade}//..//..//div[contains(text(), "שבץ")]`)

let scheduledTechnician = web.getText('//field-in-card//div[@title="טכנאי משובץ"]//..//a')
if (web.isVisible('//field-in-card//div[@title="טכנאי משובץ"]')) {
    po.log('success', `${scheduledTechnician} טכנאי משובץ בהצלחה`)
} else {
    assert.fail(`${selectedTechnician} לא שובץ`)
}
