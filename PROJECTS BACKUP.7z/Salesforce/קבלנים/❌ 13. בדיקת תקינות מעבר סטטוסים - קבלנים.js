log.info(`13. בדיקת תקינות מעבר סטטוסים - קבלנים ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const sales = po.sales
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const serviceRep = env.serviceRep
const email = env.email ? env.email : func.generateEmail()
const phone = func.generatePhone()
const firstName = func.generateName()
const techRep = env.techRep
const contractorCompany = 'יוביטל'
const contractorName = 'חנוך גיבילי'

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Create New Paka')
const newPakaNumber = service.createNewPaka()

web.transaction('Open Field Services')
service.openFieldServices()

web.transaction(`Login As Contractor ${contractorName} From ${contractorCompany}`)
main.loginAsContractor(contractorCompany, contractorName, 'גאנט פק"עות')

web.transaction(`Set Paka ${newPakaNumber} Appointment To Tech ${techRep}`)
service.selectPaka(newPakaNumber)
service.setAppointment(techRep, newPakaNumber)

web.transaction(`Schedule Paka ${newPakaNumber}`)
service.selectPaka(newPakaNumber, 'תיאום') 
service.setSchedule(firstName, phone)

web.transaction(`Assign To Recommended Technician As Contractor ${contractorName}`)
service.selectPaka(newPakaNumber, 'מועמדים') 
var grade, selectedTechnician
if (web.isVisible('(//div[contains(@class, "GS-grade-excellent")])[1]', po.waitHalfAMinute)) {
    grade = '(//div[contains(@class, "GS-grade-excellent")])[1]'
} else if (web.isVisible('(//div[contains(@class, "GS-grade-ok")])[1]', po.waitHalfAMinute)) {
    grade = '(//div[contains(@class, "GS-grade-ok")])[1]'
} else if (web.isVisible('//div[@class="get-slots-error"]', po.longWait)) {
    let message = web.getText('//div[@class="slots-panel-title"]')
    assert.fail('לא נמצאו מועמדים ' + message)
}

var selectedTechnician = web.getText(`${grade}//..//..//div[@class="candidates-container-row"]//h1`)

web.transaction(`Schedule Technician -> ${selectedTechnician}`)
web.click(`${grade}//..//..//div[@class="candidates-container-row"]`)
web.click(`${grade}//..//..//div[contains(text(), "שבץ")]`)

let scheduledTechnician = web.getText('//field-in-card//div[@title="טכנאי משובץ"]//..//a')
if (web.isVisible('//field-in-card//div[@title="טכנאי משובץ"]')) {
    po.log('success', `${scheduledTechnician} טכנאי משובץ בהצלחה`)
} else {
    assert.fail(`${selectedTechnician} לא שובץ`)
}

web.transaction('Update Status To Dispatched')
web.click('//div[@title="עדכון סטטוס"]')
web.selectFrame(service.gantFrame, service.lightBoxFrame)

web.select('//label[contains(text(), "סטטוס")]//..//select', 'value=Dispatched')
web.click('//button[text()="הבא"]')

if (web.isVisible('//*[text()="סטטוס עודכן בהצלחה"]')) {
    po.log('success', 'סטטוס עודכן בהצלחה לנשלח')
    web.selectFrame(service.gantFrame)

    if (web.isVisible('//*[name()="svg" and @ng-click="closeLightbox()"]', po.longWait)) {
        web.click('//*[name()="svg" and @ng-click="closeLightbox()"]')
    }

    if (web.isVisible(`//*[contains(text(), "${newPakaNumber}")]//..//..//..//service-list-column[text()="נשלח"]`)) {
        po.log('success', 'פק"ע עודכנה בהצלחה לנשלח')
    } else {
        assert.fail('פק"ע לא עודכנה לנשלח')
    }
} else {
    assert.fail('סטטוס לא עודכן לנשלח')
}

web.transaction('Update Status To Accepted')
web.click('//div[@title="עדכון סטטוס"]')
web.selectFrame(service.gantFrame, service.lightBoxFrame)

web.select('//label[contains(text(), "סטטוס")]//..//select', 'value=Accepted')
web.click('//button[text()="הבא"]')

if (web.isVisible('//*[text()="סטטוס עודכן בהצלחה"]')) {
    po.log('success', 'סטטוס עודכן בהצלחה להתקבל')
    web.selectFrame(service.gantFrame)

    if (web.isVisible('//*[name()="svg" and @ng-click="closeLightbox()"]', po.longWait)) {
        web.click('//*[name()="svg" and @ng-click="closeLightbox()"]')
    }

    if (web.isVisible(`//*[contains(text(), "${newPakaNumber}")]//..//..//..//service-list-column[text()="התקבל"]`)) {
        po.log('success', 'פק"ע עודכנה בהצלחה להתקבל')
    } else {
        assert.fail('פק"ע לא עודכנה להתקבל')
    }
} else {
    assert.fail('סטטוס לא עודכן להתקבל')
}

web.transaction('Update Status To Travel')
web.click('//div[@title="עדכון סטטוס"]')
web.selectFrame(service.gantFrame, service.lightBoxFrame)

web.select('//label[contains(text(), "סטטוס")]//..//select', 'value=Travel')
web.click('//button[text()="הבא"]')

if (web.isVisible('//*[text()="סטטוס עודכן בהצלחה"]')) {
    po.log('success', 'סטטוס עודכן בהצלחה לבנסיעה')
    web.selectFrame(service.gantFrame)

    if (web.isVisible('//*[name()="svg" and @ng-click="closeLightbox()"]', po.longWait)) {
        web.click('//*[name()="svg" and @ng-click="closeLightbox()"]')
    }

    if (web.isVisible(`//*[contains(text(), "${newPakaNumber}")]//..//..//..//service-list-column[text()="בנסיעה"]`)) {
        po.log('success', 'פק"ע עודכנה בהצלחה לבנסיעה')
    } else {
        assert.fail('פק"ע לא עודכנה לבנסיעה')
    }
} else {
    assert.fail('סטטוס לא עודכן לבנסיעה')
}

web.transaction('Update Status To In Progress')
web.click('//div[@title="עדכון סטטוס"]')
web.selectFrame(service.gantFrame, service.lightBoxFrame)

web.select('//label[contains(text(), "סטטוס")]//..//select', 'value=In Progress')
web.click('//button[text()="הבא"]')

if (web.isVisible('//*[text()="סטטוס עודכן בהצלחה"]')) {
    po.log('success', 'סטטוס עודכן בהצלחה לבביצוע')
    web.selectFrame(service.gantFrame)

    if (web.isVisible('//*[name()="svg" and @ng-click="closeLightbox()"]', po.longWait)) {
        web.click('//*[name()="svg" and @ng-click="closeLightbox()"]')
    }

    if (web.isVisible(`//*[contains(text(), "${newPakaNumber}")]//..//..//..//service-list-column[text()="בביצוע"]`)) {
        po.log('success', 'פק"ע עודכנה בהצלחה לבביצוע')
    } else {
        assert.fail('פק"ע לא עודכנה לבביצוע')
    }
} else {
    assert.fail('סטטוס לא עודכן לבביצוע')
}

web.transaction('Update Status To Cannot Complete')
web.click('//div[@title="עדכון סטטוס"]')
web.selectFrame(service.gantFrame, service.lightBoxFrame)

web.select('//label[contains(text(), "סטטוס")]//..//select', 'value=Cannot Complete')
web.select('//label[contains(text(), "תת סטטוס")]//..//select', 'value=Fault_worked_out')
web.click('//button[text()="הבא"]')

if (web.isVisible('//*[text()="סטטוס עודכן בהצלחה"]')) {
    po.log('success', 'סטטוס עודכן בהצלחה ללא הושלם')
    web.selectFrame(service.gantFrame)

    if (web.isVisible('//*[name()="svg" and @ng-click="closeLightbox()"]', po.longWait)) {
        web.click('//*[name()="svg" and @ng-click="closeLightbox()"]')
    }

    if (web.isVisible(`//*[contains(text(), "${newPakaNumber}")]//..//..//..//service-list-column[text()="לא הושלם"]`)) {
        po.log('success', 'פק"ע עודכנה בהצלחה ללא הושלם')
    } else {
        assert.fail('פק"ע לא עודכנה ללא הושלם')
    }
} else {
    assert.fail('סטטוס לא עודכן ללא הושלם')
}
