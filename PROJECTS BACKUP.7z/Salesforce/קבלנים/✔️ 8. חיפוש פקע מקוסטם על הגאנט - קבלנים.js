log.info(`8. חיפוש פקע מקוסטם על הגאנט ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const sales = po.sales
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const contractorCompany = 'יוביטל'
const contractorName = 'חנוך גיבילי'
const serviceRep = env.serviceRep
const email = env.email ? env.email : func.generateEmail()

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction(`Login As Contractor ${contractorName} From ${contractorCompany}`)
main.loginAsContractor(contractorCompany, contractorName)

web.transaction('Find Service')
po.specialClick(`//div[@data-aura-class="forceCommunityGlobalNavigation"]//span[text()='פק"עות']`)

var serviceElement = '(//span[@class="slds-truncate" and contains(text(), "פתוח") or contains(text(), "משובץ") or contains(text(), "ממתין לביצוע") or contains(text(), "בנסיעה") or contains(text(), "בהמתנה")]//..//..//..//..//..//a[contains(@title, "SA")])[1]'
var serviceNumber = ''

if (web.isVisible(serviceElement, po.waitHalfAMinute)) {
    serviceNumber = web.getText(serviceElement)
    po.log('success', `נמצאה פק"ע: ${serviceNumber}`)
}

po.specialClick(`//div[@data-aura-class="forceCommunityGlobalNavigation"]//span[text()='גאנט פק"עות']`)

web.transaction('Select Field Service')
web.selectFrame(service.gantFrame)
web.select('id=PredefinedFilterSelector', 'label=א. כל הפק"עות על הגאנט')

web.transaction('Search Paka By Legacy Number')
web.click('id=ActionButton')
if (!web.isVisible('//div[@id="MainActionContainer"]//div[normalize-space()="חיפוש מתקדם"]', po.longWait)) {
    assert.fail('אופציית חיפוש מתקדם לא קיימת')
} 

web.click('//div[@id="MainActionContainer"]//div[normalize-space()="חיפוש מתקדם"]')
web.selectFrame(service.gantFrame, service.lightBoxFrame)

if (!web.isVisible('//button[@title="Show Quick Filters"]', po.longWait)) {
    assert.fail('לחיצה על אופציית חיפוש מתקדם לא עובדת')
} else {
    web.click('//button[@title="Show Quick Filters"]')
}

const firstLegacyNumber = web.getText('(//lightning-primitive-cell-factory[contains(@data-label, "לגאסי")])[1]')

web.type('//label[contains(text(), "לגאסי")]//..//input', firstLegacyNumber)
func.pressTAB()
web.click('//button[text()="חפש"]')

if (web.isVisible(`//lightning-primitive-cell-factory[contains(@data-label, "לגאסי")]//lightning-base-formatted-text[text()="${firstLegacyNumber}"]`)
&& web.isVisible('//div[contains(text(), "כל הרשומות נטענו")]')) {
    po.log('success', `מספר פק"ע לגאסי לאחר סינון: ${firstLegacyNumber}`)
} else {
    assert.fail(`לא מופיע מספר פק"ע לגאסי לאחר סינון: ${firstLegacyNumber}`)
}

web.transaction('Search Paka By Legacy Status Open')
web.clear('//label[contains(text(), "לגאסי")]//..//input')
web.click('//lightning-checkbox-group//span[text()="פתוח"]')
web.click('//button[text()="חפש"]')

if (web.isVisible('(//lightning-primitive-cell-factory[contains(@data-label, "SA מספר")])[1]')
&& web.isVisible('(//lightning-primitive-cell-factory[contains(@data-label, "סטטוס")]//lightning-base-formatted-text[text()="פתוח"])[1]')) {
    po.log('success', 'סינון פק"עות בסטטוס פתוח בוצע בהצלחה')
} else {
    assert.fail('סינון פק"עות בסטטוס פתוח נכשל')
}

const saNumber = web.getText('(//lightning-primitive-cell-factory[contains(@data-label, "SA מספר")])[1]')
po.log('info', 'מספר פק"ע להעתקה: ' + saNumber)

web.transaction(`Copy Paka SA Number ${saNumber}`)
web.click('(//lightning-card//*[name()="svg" and @data-key="down"])[1]')
web.click('//a[@role="menuitem"]//span[text()="העתק"]')

web.selectWindow(web.getWindowHandles()[1])
if (web.isVisible(service.gantFrame)) {
    web.selectFrame(service.gantFrame)

    if (web.isVisible(`//span[@class="resource-highlight-on-search" and text()="${saNumber}"]`)) {
        po.log('success', `פק"ע ${saNumber} הועתקה בהצלחה`)
    } else {
        assert.fail(`פק"ע ${saNumber} הועתקה לא`)
    }
}
