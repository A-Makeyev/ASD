log.info(`9. SAתיאום מקוסטם לפקע על ה.js ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const sales = po.sales
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const serviceRep = env.serviceRep
const email = env.email ? env.email : func.generateEmail()
const phone = func.generatePhone()
const firstName = func.generateName()
const contractorCompany = 'יוביטל'
const contractorName = 'חנוך גיבילי'

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction(`Login As Contractor ${contractorName} From ${contractorCompany}`)
main.loginAsContractor(contractorCompany, contractorName)

web.transaction('Find Service')
po.specialClick(`//div[@data-aura-class="forceCommunityGlobalNavigation"]//span[text()='פק"עות']`)

var serviceElement = '(//span[@class="slds-truncate" and contains(text(), "פתוח") or contains(text(), "משובץ") or contains(text(), "ממתין לביצוע") or contains(text(), "בנסיעה") or contains(text(), "בהמתנה")]//..//..//..//..//..//a[contains(@title, "SA")])[1]'
var serviceNumber = ''

if (web.isVisible(serviceElement, po.waitHalfAMinute)) {
    serviceNumber = web.getText(serviceElement)
    po.log('success', `נמצאה פק"ע: ${serviceNumber}`)
}

po.specialClick(`//div[@data-aura-class="forceCommunityGlobalNavigation"]//span[text()='גאנט פק"עות']`)

web.transaction('Select Field Service')
web.selectFrame(service.gantFrame)
web.select('id=PredefinedFilterSelector', 'label=א. כל הפק"עות על הגאנט')

web.click('id=serviceSearchsWrapper')
web.type('id=TaskSearchFilterInput', serviceNumber)

web.pause(po.shortWait)
web.click('//button[@id="SearchOnServer"]')

if (web.isVisible('id=TaskListSorting')) {
    web.click('id=matchGanttCheckbox')
    web.click('(//service-list-column[contains(text(), "פתוח") or contains(text(), "נשלח") or contains(text(), "משובץ") or contains(text(), "בהמתנה") or contains(text(), "ממתין לביצוע")])[1]')
    web.click('//div[@title="תיאום"]')
} else if (web.isVisible('//div[@class="NoServicesFound"]', po.longWait)) {
    assert.fail(web.getText('//div[@class="NoServicesFound"]'))
} 

web.transaction('Assert Paka Details')
web.selectFrame(service.gantFrame, service.lightBoxFrame)

if (web.isVisible('//c-work-order-details')) {
    const contactName = web.getValue('(//c-work-order-details//label[contains(text(), "שם איש קשר")]//..//input)[1]')
    const contactPhone = web.getValue('(//c-work-order-details//label[contains(text(), "טלפון איש קשר")]//..//input)[1]')

    if (contactName.trim() !== '') {
        po.log('success', `שם איש קשר לפק"ע ${contactName}`)
    } else {
        po.log('error', `לא מופיע שם איש קשר לפק"ע`)
        web.type(`//label[contains(text(), 'שם איש קשר לפק"ע')]//..//input`, firstName)
    }

    if (contactPhone.trim() !== '') {
        po.log('success', `טלפון איש קשר לפק"ע ${contactPhone}`)
    } else {
        po.log('error', `לא מופיע טלפון איש קשר לפק"ע`)
        web.type(`//label[contains(text(), 'טלפון איש קשר לפק"ע')]//..//input`, phone)
    }
} 

web.transaction('Create Schedule')
if (web.isVisible('//button[contains(text(), "מצא חלון זמן")]', po.longWait)) {
    po.specialClick('//button[contains(text(), "מצא חלון זמן")]')
}

if (web.isVisible('(//div[contains(@class, "singleDay")])[1]')) {
    po.specialClick('(//div[contains(@class, "singleDay")])[1]')
    po.specialClick('//span[contains(text(), "המצאות בגיר בבית")]//..//span[@class="slds-checkbox_faux"]')
    po.specialClick('//span[contains(text(), "הוסבר חיוג")]//..//span[@class="slds-checkbox_faux"]')
}

if (web.isVisible('//label[contains(text(), "בחרת חלון זמן מחוץ ל-SLA")]//..//button', po.longWait)) {
    web.click('//label[contains(text(), "בחרת חלון זמן מחוץ ל-SLA")]//..//button')
    func.pressARROW_DOWN()
    func.pressENTER()
    func.pressTAB()
}

if (web.isVisible('(//div[contains(@class, "singleDay selcted")])[1]') && web.isVisible('//*[@aria-disabled="false" and (text()="תאם")]')) {
    let techDate = web.getText('(//div[contains(@class, "singleDay selcted")]//..//..//..//..//..//*[contains(text(), "יום")])[1]')
    let techTime = web.getText('(//div[contains(@class, "singleDay selcted")])[1]')
    po.log('success', `תאריך הגעת טכנאי: ${techDate} בשעה ${techTime}`)
    po.specialClick('//*[@aria-disabled="false" and (text()="תאם")]')
}

if (web.isVisible('//*[contains(text(), "הפגישה נקבעה בהצלחה")]', po.waitThreeMinutes)) {
    po.log('success', web.getText('//*[contains(text(), "הפגישה נקבעה בהצלחה")]'))
} else {
    assert.fail('הייתה תקלה ביצירת פגישת טכנאי')
}
