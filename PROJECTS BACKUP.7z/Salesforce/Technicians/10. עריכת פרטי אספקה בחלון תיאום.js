log.info(`10. עריכת פרטי אספקה בחלון תיאום ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const sales = po.sales
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const serviceRep = env.serviceRep
const email = env.email ? env.email : func.generateEmail()
const phone = func.generatePhone()
const firstName = func.generateName()
const techRep = env.techRep

web.transaction('Open Settings')
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Create New Paka')
const newPakaNumber = service.createNewPaka()

web.transaction('Open Field Services')
service.openFieldServices()

web.transaction(`Set Paka ${newPakaNumber} Appointment To Tech ${techRep}`)
service.selectPaka(newPakaNumber)
service.setAppointment(techRep, newPakaNumber)

web.transaction(`Schedule Paka ${newPakaNumber}`)
service.selectPaka(newPakaNumber, 'תיאום') 
service.setSchedule(firstName, phone)

web.transaction('Assert Schedule Details')
web.selectFrame(service.gantFrame)
service.selectPaka(newPakaNumber, 'תיאום') 

web.selectFrame(service.gantFrame, service.lightBoxFrame)

let error = ''
let pakaDetails = web.getText(`//div[@title='פרטי פק"ע']//..//..//div[@class="slds-tile__detail"]`)
let contactDetails = web.getText(`//div[@title='פרטי תיאום']//..//..//div[@class="slds-tile__detail"]`)

if (pakaDetails.includes(newPakaNumber)) {
    po.log('success', 'פרטי פק"ע: ' + web.getText(`//div[@title='פרטי פק"ע']//..//..//div[@class="slds-tile__detail"]`))
} else {
    error = `לא מופיע מספר פק"ע ${newPakaNumber}`
}

if (contactDetails.includes(firstName) && contactDetails.includes(phone)) {
    po.log('success', 'פרטי תיאום: ' + web.getText(`//div[@title='פרטי תיאום']//..//..//div[@class="slds-tile__detail"]`))
} else {
    error = `השם ${firstName} והמספר ${phone} לא מופיע בפרטי פק"ע`
}

if (error != '') {
    assert.fail(error)
}
