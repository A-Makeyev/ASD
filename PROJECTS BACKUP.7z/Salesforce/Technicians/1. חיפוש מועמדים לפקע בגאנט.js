log.info(`1. חיפוש מועמדים לפקע בגאנט ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const sales = po.sales
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const serviceRep = env.serviceRep
const email = env.email ? env.email : func.generateEmail()
const phone = func.generatePhone()
const firstName = func.generateName()
const techRep = env.techRep

web.transaction('Open Settings')
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Create New Paka')
const newPakaNumber = service.createNewPaka()

web.transaction('Open Field Services')
service.openFieldServices()

web.transaction(`Set Paka ${newPakaNumber} Appointment To Tech ${techRep}`)
service.selectPaka(newPakaNumber)
service.setAppointment(techRep, newPakaNumber)

web.transaction(`Schedule Paka ${newPakaNumber}`)
service.selectPaka(newPakaNumber, 'תיאום') 
service.setSchedule(firstName, phone)

web.transaction(`Select Paka ${newPakaNumber}`)
service.selectPaka(newPakaNumber, 'מועמדים')

web.transaction('Select Technician')
if (web.isVisible('//div[@class="assign-to-recommended"]', po.waitHalfAMinute)) {
    po.log('success', web.getText('id=slotsSentence'))
    web.click('//div[@class="assign-to-recommended"]')
    web.click(`(//span[text()="${newPakaNumber}"]//..//..//..//..//div[contains(@class, "SingleTask")]//..//input)[1]`)
    web.click('id=actionQuickFirst')

    if (web.isVisible('(//div[contains(normalize-space(), "שיבוץ הסתיים")])[1]')) {
        po.log('success', web.getText('(//div[contains(normalize-space(), "שיבוץ הסתיים")])[1]'))
        web.click('//span[@ng-click="showResults()"]')

        if (web.isVisible(`//div[@class="ScheduleResultRow"]//span[text()="${newPakaNumber}"]`)) {
            po.log('success', 'פק"ע שובצה בהצלחה: ' + web.getText(`//div[@class="ScheduleResultRow"]//span[text()="${newPakaNumber}"]`))
        } else {
            po.log('error', 'פק"ע לא שובצה')
        }
    }
} else if (web.isVisible('//div[@class="get-slots-error"]', po.waitHalfAMinute)) {
    let message = web.getText('//div[@class="slots-panel-title"]')
    po.log('warning', 'לא נמצאו מועמדים ' + message)
} else if (web.isVisible('id=ScheduledResultsTable', po.longWait)) {
    let status = web.getText('id=ScheduledResultsTable')
    if (status.includes('לא נמצאו מועמדים')) {
        po.log('error', status)
    }
} else {
    const selectedTechnician = web.getText('//div[contains(@class, "GS-grade-excellent")]//..//..//div[@class="candidates-container-row"]//h1')

    web.click('//div[contains(@class, "GS-grade-excellent")]//..//..//div[@class="candidates-container-row"]')
    web.click('(//div[contains(@class, "GS-grade-excellent")]//..//div[contains(text(), "שבץ")])[1]')

    if (web.isVisible(`//field-in-card//a[@title="${selectedTechnician}"]`)) {
        po.log('success', `${selectedTechnician} שובץ בהצלחה`)
    } else {
        po.log('error', `${selectedTechnician} לא שובץ בהצלחה`)
    }
}

web.selectFrame(service.gantFrame)
web.click('//*[name()="svg" and contains(@ng-click, "closeLightbox")]')

service.removeSchedules(techRep)
