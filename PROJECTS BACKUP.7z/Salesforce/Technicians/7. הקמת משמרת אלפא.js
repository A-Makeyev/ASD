log.info(`7. הקמת משמרת אלפא ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const sales = po.sales
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360

var shiftStartTime = '8:00'
var shiftEndTime = '17:00'
var techName = 'טכנאי2 בדיקות'
var repName = env.serviceRep
var tomorrow = func.futureDate(1)
var expectedShiftStart = `${tomorrow}, ${shiftStartTime}`
var expectedShiftEnd = `${tomorrow}, ${shiftEndTime}`
var email = env.email ? env.email : func.generateEmail()

po.log('info', `Email: ${email}`)
po.log('info', `repName: ${repName}`)
po.log('info', `techName: ${techName}`)
po.log('info', `Shift Start Time: ${expectedShiftStart}`)
po.log('info', `Shift End Time: ${expectedShiftEnd}`)

web.transaction('Open Settings')
main.openSettings()

web.transaction(`Login With Rep -> ${repName}`)
settings.loginWithRep(repName)
main.assertApplicationError()

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Open Shift Screen')
web.selectWindow(web.getWindowHandles()[1])
web.click('//div[@class="slds-icon-waffle"]')
web.type('//one-app-launcher-menu//input[@type="search"]', 'משמרות')
web.click('//a[@id="Shift"]//b') 

web.click('//button[@title="בחר תצוגת רשימה: משמרות"]')
web.click('(//ul[@role="listbox"]//span[contains(text(), "כל המשמרות")])[1]')
web.click('(//td[@role="gridcell"]//input)[1]')

web.transaction('Create New Shift')
web.click('//*[@data-target-selection-name="sfdc:StandardButton.Shift.New"]')

if (web.isVisible('//div[@class="base-record-form-header-container"]', po.longWait)) {
    web.type('(//legend[contains(text(), "שעת התחלה")]//..//input[@name="firstInputDateTime"])[1]', tomorrow)
    func.pressTAB()

    web.click('(//legend[contains(text(), "שעת התחלה")]//..//input[@name="firstInputDateTime"])[2]')
    web.click(`(//lightning-base-combobox-item//span[@title="${shiftStartTime}"])[1]`)

    web.type('(//legend[contains(text(), "שעת סיום")]//..//input[@name="firstInputDateTime"])[1]', tomorrow)
    func.pressTAB()

    web.type('(//legend[contains(text(), "שעת סיום")]//..//input[@name="firstInputDateTime"])[2]', shiftEndTime)
    web.click(`(//lightning-base-combobox-item//span[@title="${shiftEndTime}"])[1]`)

    web.type('//label[contains(text(), "טכנאי")]//..//input', techName)
    web.click('//span[contains(@class, "option-text_entity")]//*[@title="טכנאי2 בדיקות"]')
    web.click('//button[text()="שמור"]')
} else {
    po.log('error', 'לא נפתח מסך צור משמרת')
}

web.transaction('Assert Created New Shift')
var createdShiftDateAndTimeStart = web.getText('//p[@title="התחלת משמרת"]//..//lightning-formatted-date-time')
var createdShiftDateAndTimeEnd = web.getText('//p[@title="סיום משמרת"]//..//lightning-formatted-date-time')
var createdShiftStatus = web.getText('//p[@title="סטטוס משמרת"]//..//lightning-formatted-text')
var createdShiftTech = web.getText('//p[@title="טכנאי"]//..//a//span')
var createdShiftDevision = web.getText('//p[@title="מחלקה"]//..//lightning-formatted-text')
var createdShiftTeam = web.getText('//p[@title="צוות"]//..//lightning-formatted-text')
var createdShiftNumber = web.getText('//records-record-layout-section//span[contains(text(), "מספר משמרת")]//..//..//..//lightning-formatted-text')

if (createdShiftDateAndTimeStart == expectedShiftStart) {
    po.log('success', `Created shift START date & time: (${createdShiftDateAndTimeStart})`)
} else {
    po.log('info', `Expected created shift START date & time to be: (${expectedShiftStart}), instead got: (${createdShiftDateAndTimeStart})`)
}

if (createdShiftDateAndTimeEnd == expectedShiftEnd) {
    po.log('success', `Created shift END date & time: (${createdShiftDateAndTimeEnd})`)
} else {
    po.log('info', `Expected created shift END date & time to be: (${expectedShiftEnd}), instead got: (${createdShiftDateAndTimeEnd})`)
}

if (createdShiftTech == techName) {
    po.log('success', `Created shift technician: (${createdShiftTech})`)
} else {
    po.log('info', `Expected created shift technician to be: (${techName}), instead got: (${createdShiftTech})`)
}

po.log('info', `Created Shift Status: ${createdShiftStatus}`)
po.log('info', `Created Shift Devision: ${createdShiftDevision}`)
po.log('info', `Created Shift Team: ${createdShiftTeam}`)
po.log('info', `Created Shift Number: ${createdShiftNumber}`)
