log.info(`14. מעבר פקע מסטטוס משובץ לפתוח ולהמתנה ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const sales = po.sales
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const serviceRep = env.serviceRep
const email = env.email ? env.email : func.generateEmail()
const phone = func.generatePhone()
const firstName = func.generateName()
const techRep = env.techRep

web.transaction('Open Settings')
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Create New Paka')
const newPakaNumber = service.createNewPaka()

web.transaction('Open Field Services')
service.openFieldServices()

web.transaction(`Set Paka ${newPakaNumber} Appointment To Tech ${techRep}`)
service.selectPaka(newPakaNumber)
service.setAppointment(techRep, newPakaNumber)

web.transaction(`Schedule Paka ${newPakaNumber}`)
service.selectPaka(newPakaNumber, 'תיאום') 
service.setSchedule(firstName, phone)

service.selectPaka(newPakaNumber, 'מועמדים') 
var grade, selectedTechnician
if (web.isVisible('(//div[contains(@class, "GS-grade-excellent")])[1]', po.waitHalfAMinute)) {
    grade = '(//div[contains(@class, "GS-grade-excellent")])[1]'
} else if (web.isVisible('(//div[contains(@class, "GS-grade-ok")])[1]', po.waitHalfAMinute)) {
    grade = '(//div[contains(@class, "GS-grade-ok")])[1]'
} else if (web.isVisible('//div[@class="get-slots-error"]', po.longWait)) {
    let message = web.getText('//div[@class="slots-panel-title"]')
    assert.fail('לא נמצאו מועמדים ' + message)
}

var selectedTechnician = web.getText(`${grade}//..//..//div[@class="candidates-container-row"]//h1`)

web.transaction(`Schedule Technician -> ${selectedTechnician}`)
web.click(`${grade}//..//..//div[@class="candidates-container-row"]`)
web.click(`${grade}//..//..//div[contains(text(), "שבץ")]`)

let scheduledTechnician = web.getText('//field-in-card//div[@title="טכנאי משובץ"]//..//a')
if (web.isVisible('//field-in-card//div[@title="טכנאי משובץ"]')) {
    po.log('success', `${scheduledTechnician} טכנאי משובץ בהצלחה`)
} else {
    assert.fail(`${selectedTechnician} לא שובץ`)
}

web.transaction('Update Status To Dispatched')
web.click('//div[@title="עדכון סטטוס"]')
web.selectFrame(service.gantFrame, service.lightBoxFrame)

web.select('//label[contains(text(), "סטטוס")]//..//select', 'value=Scheduled')
web.click('//button[text()="הבא"]')

if (web.isVisible('//*[text()="סטטוס עודכן בהצלחה"]')) {
    po.log('success', 'סטטוס עודכן בהצלחה למשובץ')
    web.selectFrame(service.gantFrame)

    if (web.isVisible('//*[name()="svg" and @ng-click="closeLightbox()"]', po.longWait)) {
        web.click('//*[name()="svg" and @ng-click="closeLightbox()"]')
    }

    if (web.isVisible(`//*[contains(text(), "${newPakaNumber}")]//..//..//..//service-list-column[text()="משובץ"]`, po.longWait)) {
        po.log('success', 'פק"ע עודכנה בהצלחה למשובץ')
    } else {
        po.log('warning', `פק"ע לא עודכנה למשובץ במסך גאנט פקע"ות תחת ${newPakaNumber}`)
    }
} else {
    assert.fail('סטטוס לא עודכן למשובץ')
}

web.transaction('Update Status To None (Open)')
web.click('//div[@title="עדכון סטטוס"]')
web.selectFrame(service.gantFrame, service.lightBoxFrame)

web.select('//label[contains(text(), "סטטוס")]//..//select', 'value=None')
web.click('//button[text()="הבא"]')

if (web.isVisible('//*[text()="סטטוס עודכן בהצלחה"]')) {
    po.log('success', 'סטטוס עודכן בהצלחה לפתוח')
    web.selectFrame(service.gantFrame)

    if (web.isVisible('//*[name()="svg" and @ng-click="closeLightbox()"]', po.longWait)) {
        web.click('//*[name()="svg" and @ng-click="closeLightbox()"]')
    }

    if (web.isVisible(`//*[contains(text(), "${newPakaNumber}")]//..//..//..//service-list-column[text()="פתוח"]`)) {
        po.log('success', 'פק"ע עודכנה בהצלחה לפתוח')
    } else {
        assert.fail('פק"ע לא עודכנה לפתוח')
    }
} else {
    assert.fail('סטטוס לא עודכן לפתוח')
}

web.transaction('Update Status To On Hold')
web.click('//div[@title="עדכון סטטוס"]')
web.selectFrame(service.gantFrame, service.lightBoxFrame)

web.select('//label[contains(text(), "סטטוס")]//..//select', 'value=On Hold')
web.select('//label[contains(text(), "תת סטטוס")]//..//select', 'value=Fault_worked_out')
web.click('//button[text()="הבא"]')

if (web.isVisible('//div[@id="updateStatusHolder"]//p[contains(text(), "השגיאה") or contains(text(), "error")]', po.longWait)) {
    po.log('info', web.getText('//div[@id="updateStatusHolder"]//p[contains(text(), "השגיאה") or contains(text(), "error")]'))
    web.click('//button[contains(text(), "סיים")]')

    web.select('//label[contains(text(), "סטטוס")]//..//select', 'value=On Hold')
    web.select('//label[contains(text(), "תת סטטוס")]//..//select', 'value=Fault_worked_out')
    web.click('//button[text()="הבא"]')
} 

if (web.isVisible('//*[text()="סטטוס עודכן בהצלחה"]')) {
    po.log('success', 'סטטוס עודכן בהצלחה לבהמתנה')
    web.selectFrame(service.gantFrame)

    if (web.isVisible('//*[name()="svg" and @ng-click="closeLightbox()"]', po.longWait)) {
        web.click('//*[name()="svg" and @ng-click="closeLightbox()"]')
    }

    if (web.isVisible(`//*[contains(text(), "${newPakaNumber}")]//..//..//..//service-list-column[text()="בהמתנה"]`)) {
        po.log('success', 'פק"ע עודכנה בהצלחה לבהמתנה')
    } else {
        assert.fail('פק"ע לא עודכנה לבהמתנה')
    }
} else {
    assert.fail('סטטוס לא עודכן לבהמתנה')
}
