log.info(`4. שיבוץ מחדש עי גרירה בגאנט ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const sales = po.sales
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const serviceRep = env.serviceRep
const email = env.email ? env.email : func.generateEmail()
const phone = func.generatePhone()
const firstName = func.generateName()
const techRep = env.techRep

web.transaction('Open Settings')
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Create New Paka')
const newPakaNumber = service.createNewPaka()

web.transaction('Open Field Services')
service.openFieldServices()

web.transaction(`Set Paka ${newPakaNumber} Appointment To Tech ${techRep}`)
service.selectPaka(newPakaNumber)
service.setAppointment(techRep, newPakaNumber)

web.transaction(`Set Paka ${newPakaNumber} Appointment From Tech ${techRep} To New Tech`)
const scheduledPaka = `//div[@id="GanttContainer"]//div[@class="ServiceEvent"]//..//..//..//div[contains(text(), "${newPakaNumber}")]`
const newTech = `(//div[@id="GanttContainer"]//a[@title="${techRep}"]//..//..//..//..//..//..//a[contains(@class, "smallResourceName") and not (@title="${techRep}")])[1]`
const newTechTime = `${newTech}//..//..//..//..//..//..//..//..//div[contains(@data-col-date, "10:00")]`

web.clear('//div[@id="GanttContainer"]//input[@placeholder="חיפוש טכנאי"]')
web.pause(po.shortWait)

let scrollTries = 20
while (!web.isVisible(scheduledPaka, po.shortWait)) {
    web.execute(() => { document.querySelector('.dhx_cal_data').scrollTop += 400 })
    if (scrollTries == 0) break
    else scrollTries--
}

web.selectFrame(service.gantFrame)
web.waitForInteractable(scheduledPaka)
web.dragAndDrop(
    scheduledPaka,
    newTechTime
)

if (web.isVisible('//span[contains(@class, "toastMessage") and contains(text(), "שימו לב")]', po.waitHalfAMinute)) {
    po.log('warning', web.getText('//div[contains(@class, "toastMessage")]'))
}

// web.pause(po.waitHalfAMinute)

// scrollTries = 20
// while (!web.isVisible(scheduledPaka, po.shortWait)) {
//     web.execute(() => { document.querySelector('.dhx_cal_data').scrollTop -= 400 })
//     if (scrollTries == 0) break
//     else scrollTries--
// }

// if (web.isVisible(scheduledPaka, po.longWait)) {
//     web.pointJS(scheduledPaka)
// } else {
//      scrollTries = 20
//     while (!web.isVisible(scheduledPaka, po.shortWait)) {
//         web.execute(() => { document.querySelector('.dhx_cal_data').scrollTop += 400 })
//         if (scrollTries == 0) break
//         else scrollTries--
//     }
// }

// if (web.isVisible(scheduledPaka, po.longWait)) {
//     web.pointJS(scheduledPaka)
// }

// if (web.isVisible(`(//div[@class="tooltipLine" and not(contains(text(), "${techRep}"))])[1]`, po.longWait)) {
//     po.log('success', web.getText(`(//div[@class="tooltipLine" and not(contains(text(), "${techRep}"))])[1]`))
//     po.log('success', `פק"ע ${techRep} הועברה לטכנאי חדש בהצלחה ${newPakaNumber}`)
// } else {
//     assert.fail(`פק"ע ${techRep} לא הועברה לטכנאי חדש ${newPakaNumber}`)
// }
