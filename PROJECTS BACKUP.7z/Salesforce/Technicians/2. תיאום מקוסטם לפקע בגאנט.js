log.info(`2. תיאום מקוסטם לפקע בגאנט ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const sales = po.sales
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const serviceRep = env.serviceRep
const email = env.email ? env.email : func.generateEmail()
const phone = func.generatePhone()
const firstName = func.generateName()
const techRep = env.techRep

web.transaction('Open Settings')
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Create New Paka')
const newPakaNumber = service.createNewPaka()

web.transaction('Open Field Services')
service.openFieldServices()

web.transaction(`Set Paka ${newPakaNumber} Appointment To Tech ${techRep}`)
service.selectPaka(newPakaNumber)
service.setAppointment(techRep, newPakaNumber)

web.transaction(`Schedule Paka ${newPakaNumber}`)
service.selectPaka(newPakaNumber, 'תיאום') 
service.setSchedule(firstName, phone)
