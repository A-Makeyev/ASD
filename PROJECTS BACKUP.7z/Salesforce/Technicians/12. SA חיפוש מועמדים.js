log.info(`12. SA חיפוש מועמדים ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const sales = po.sales
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const service = po.servicePage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360
const serviceRep = env.serviceRep
const email = env.email ? env.email : func.generateEmail()
const phone = func.generatePhone()
const firstName = func.generateName()
const techRep = env.techRep

web.transaction('Open Settings')
main.openSettings()

web.transaction(`Login With Rep -> ${serviceRep}`)
settings.loginWithRep(serviceRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Create New Paka')
const newPakaNumber = service.createNewPaka()

web.transaction('Open Field Services')
service.openFieldServices()

web.transaction(`Set Paka ${newPakaNumber} Appointment To Tech ${techRep}`)
service.selectPaka(newPakaNumber)
service.setAppointment(techRep, newPakaNumber)

web.transaction('Open Services')
main.closeTabs()
po.selectWindow('new')
po.specialClick(main.navigationBtn)
web.scrollToElement(main.navigationOptions.services)
web.click(main.navigationOptions.services)

web.transaction(`Schedule Paka ${newPakaNumber}`)
web.click(`//span[contains(text(), 'פק"עות')]//..//..//..//button[contains(@title, 'בחר תצוגת רשימה')]`)
web.click(`//div[contains(@class, 'uiAbstractList')]//span[text()='כל הפק"עות']`)

po.clickUntilElementIsVisible('//header[@id="oneHeader"]//..//..//..//input[contains(@placeholder, "חפש")]', '//header[@id="oneHeader"]//button[@aria-label="חיפוש"]')
web.pause(po.shortWait)
web.type('//header[@id="oneHeader"]//..//..//..//input[contains(@placeholder, "חפש")]', newPakaNumber)
func.pressENTER()

if (!web.isVisible(`//div[@class="resultsMultiWrapper"]//a[@data-refid="recordId" and contains(text(), "${newPakaNumber}")]`, po.longWait)) {
    web.click(`//header[@id="oneHeader"]//button[@aria-label="חיפוש: ${newPakaNumber}"]`)
    func.pressARROW_DOWN()
    func.pressENTER()
} else {
    web.click(`//div[@class="resultsMultiWrapper"]//a[@data-refid="recordId" and contains(text(), "${newPakaNumber}")]`)
}

service.setSchedule(firstName, phone)

web.transaction(`Select Paka ${newPakaNumber}`)
po.selectWindow('new')
po.clickUntilElementIsVisible('//lightning-menu-item//span[text()="מועמדים"]', '//div[contains(@class, "actionsContainer")]//lightning-button-menu//lightning-primitive-icon')
web.click('//lightning-menu-item//span[text()="מועמדים"]')

if (web.isVisible(service.candidatesFrame)) {
    web.selectFrame(service.candidatesFrame)

    const techCandidateElement = '//div[@id="ActionBody"]//div[@class="AN-candidate"]//span[contains(@ng-bind, "Resource.Name")]'
    const timeElement = '//label[@class="AN-candidates-slot ng-scope"]//span[@class="AN-candidates-date ng-binding"]'
    const techCandidatesCount = web.getElementCount(techCandidateElement)

    if (web.isVisible(techCandidateElement)) {
        for (let x = 1; x <= techCandidatesCount; x++) {
            let techCandidate = web.getText(`(${techCandidateElement})[${x}]`)
            po.log('info', 'Tech Candidate: ' + techCandidate)
            web.click(`(${techCandidateElement})[${x}]`)

            if (web.isVisible(`(${timeElement})[${x}]`, po.longWait)) {
                let time = web.getText(`(${timeElement})[${x}]`)
                po.log('info', 'Time: ' + time)

                web.click(`(${timeElement})[${x}]`)
                web.click('id=ScheduleButton')

                if (web.isVisible('//div[@id="AN-Results"]//div[@class="AN-ResultText"]')) {
                    let result = web.getText('//div[@id="AN-Results"]//div[@class="AN-ResultText"]')
                    if (result.includes(time) && result.includes(techCandidate)) {
                        po.log('success', result)
                        break
                    } else {
                        po.log('error', result)
                        web.click('//div[@id="wrapper-body"]//span[text()="ביטול"]')
                        web.click('//div[contains(@class, "actionsContainer")]//lightning-button-menu//button')
                        web.click('//lightning-menu-item//span[text()="מועמדים"]')
                        continue
                    }
                } 
            } else {
                continue
            }
        }
    } else {
        assert.fail(`אין מועמדים להציג לפק"ע ${newPakaNumber}`)
    }
}



// service.openFieldServices()
// service.selectPaka(newPakaNumber, 'מועמדים')

// var grade, selectedTechnician
// if (web.isVisible('(//div[contains(@class, "GS-grade-excellent")])[1]', po.waitHalfAMinute)) {
//     grade = '(//div[contains(@class, "GS-grade-excellent")])[1]'
// } else if (web.isVisible('(//div[contains(@class, "GS-grade-ok")])[1]', po.waitHalfAMinute)) {
//     grade = '(//div[contains(@class, "GS-grade-ok")])[1]'
// } else if (web.isVisible('//div[@class="get-slots-error"]', po.longWait)) {
//     let message = web.getText('//div[@class="slots-panel-title"]')
//     assert.fail('לא נמצאו מועמדים ' + message)
// }

// var selectedTechnician = web.getText(`${grade}//..//..//div[@class="candidates-container-row"]//h1`)

// web.transaction(`Schedule Technician -> ${selectedTechnician}`)
// web.click(`${grade}//..//..//div[@class="candidates-container-row"]`)
// web.click(`${grade}//..//..//div[contains(text(), "שבץ")]`)

// let scheduledTechnician = web.getText('//field-in-card//div[@title="טכנאי משובץ"]//..//a')
// if (web.isVisible('//field-in-card//div[@title="טכנאי משובץ"]')) {
//     po.log('success', `${scheduledTechnician} טכנאי משובץ בהצלחה`)
// } else {
//     assert.fail(`${selectedTechnician} לא שובץ`)
// }
