log.info(`02. חיפוש לקוח - מספר לקוח (${env.name != 'default' ? `${env.name} סביבת` : ''})`)
po.init(env.url)

const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360

web.transaction('04. Open Settings')
web.click(main.settingsButton)
web.click(main.settingsMenu.currentApp)
po.selectWindow('new')

function searchRep() {
    web.type(settings.mainSearchInput, env.repName)
    func.pressENTER()
    if (web.isVisible(`(//a[contains(@class, "setupLink") and text()="${env.repName}"])[1]`, po.shortWait)) {
        web.click(`(//a[contains(@class, "setupLink") and text()="${env.repName}"])[1]`)
    } else if (web.isVisible(`//span[@title="${env.repName}" and contains(@class, "mruName")]`, po.shortWait)) {
        web.click(`//span[@title="${env.repName}" and contains(@class, "mruName")]`)
    }
}
searchRep()

let tries = 15
while (!web.isVisible(`//iframe[contains(@title, "User: ${env.repName}")]`, po.longWait)) {
    searchRep()
    if (tries == 0) break
    else tries--
}

web.transaction(`05. Login With Rep ${env.repName}`)
main.assertApplicationError()
web.selectFrame(`//iframe[contains(@title, "User: ${env.repName}")]`)
if (web.isVisible('//td[@id="topButtonRow"]//input[@name="login"]', po.shortWait)) {
    web.click('//td[@id="topButtonRow"]//input[@name="login"]')
} else {
    assert.fail(`לא מופיע כפתור כניסה לנציג\ה ${env.repName}`)
}

po.selectWindow('new')
main.assertApplicationError()

if (web.isVisible(`//header[@id="oneHeader"]//span[contains(text(), "כניסה בוצעה בתור ${env.repName}")]`, po.longWait)) {
    po.log('success', `Logged in with rep -> ${env.repName}`)
} else {
    po.log('error', `There was a problem logging in with rep -> ${env.repName}`)
}

if (web.isVisible('//lightning-formatted-text[contains(text(), "ההפעלה שלך הסתיימה")]', po.longWait)) {
    po.log('warning', web.getText('//lightning-formatted-text[contains(text(), "ההפעלה שלך הסתיימה")]//..//lightning-formatted-text'))
    web.click('//button[contains(text(), "כניסה")]')
}

web.transaction('04. Close All Active Tabs')
main.closeTabs()

web.transaction('05. Navigate To Search Account Page')
if (!web.isVisible(searchPage.header, po.shortWait)) {
    web.click(main.navigationBtn)
    web.click(main.navigationOptions.customers)
    assert.equal(web.isVisible(searchPage.header), true)
}

web.transaction('06. Select Customer By Account Number')
web.click(searchPage.searchParametersBtn)
web.pause(po.shortWait)

if (!web.isVisible(searchPage.parameters.accountNumber, po.shortWait)) {
    web.click(searchPage.searchParametersBtn)
}

web.click(searchPage.parameters.accountNumber)
web.type(searchPage.accountNumberInput, main.accountNumber)

web.transaction('07. Search Customer')
web.click(searchPage.searchBtn)

web.transaction('08. Assert Customer Details')
assert.equal(
    web.isExist(`//c-alp360-header-container//strong[text()="${main.customerName}"]`), true,
    `Customer ${main.customerName} has failed to load`
)

assert.equal(
    web.isExist(`//div[text()="${main.accountNumber}"]`), true,
    `Account ${main.accountNumber} has failed to load`
)

alpha360.loadCustomerDetails()
