log.info(`01. חיפוש לקוח - טלפון (${env.name != 'default' ? `${env.name} סביבת` : ''})`)
po.init(env.url)

const main = po.alphaMainPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360

web.transaction('04. Close All Active Tabs')
main.closeTabs()

web.transaction('05. Navigate To Search Account Page')
if (!web.isVisible(searchPage.header, po.shortWait)) {
    web.click(main.navigationBtn)
    web.click(main.navigationOptions.customers)
    assert.equal(web.isVisible(searchPage.header), true)
}

web.transaction('06. Select Customer By Phone')
web.click(searchPage.searchParametersBtn)
web.pause(po.shortWait)

if (!web.isVisible(searchPage.parameters.phone, po.shortWait)) {
    web.click(searchPage.searchParametersBtn)
}

web.click(searchPage.parameters.phone)
web.type(searchPage.phoneInput, main.phoneNumber)

web.transaction('07. Search Customer')
web.click(searchPage.searchBtn)

web.transaction('08. Assert Customer Details')
assert.equal(
    web.isExist(`//c-alp360-header-container//strong[text()="${main.customerName}"]`), true,
    `Customer ${main.customerName} has failed to load`
)

assert.equal(
    web.isExist(`//div[text()="${main.accountNumber}"]`), true,
    `Account ${main.accountNumber} has failed to load`
)

alpha360.loadCustomerDetails()
