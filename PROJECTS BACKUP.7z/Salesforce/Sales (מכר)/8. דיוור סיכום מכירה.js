log.info(`8. דיוור סיכום מכירה ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const sales = po.sales
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360

var repName = env.salesRep
var id = func.createTzNumber()
var phone = func.generatePhone()
var firstName = func.generateName()
var lastName = `Automation - ${Math.random().toString().slice(2, 8)}`
var email = env.email ? env.email : func.generateEmail()
var city, street, houseNumber, entrance, apartmentNumber
var productNumber = '200701'
var productName = 'yesUltimate'

web.transaction('Connect To Wiz DB')
var queryValues = po.database.getAddress()

city = queryValues[0].trim() != '' ? queryValues[0].trim() : 'מודיעין-מכבים-רעות'
street = queryValues[1].trim() != '' ? queryValues[1].trim() : 'עמק חרוד'
houseNumber = queryValues[2].trim() != '' ? queryValues[2].trim().match(/\d+/g).join('') : '44'
entrance = queryValues[3].trim() != '' ? queryValues[3].trim() : ''
apartmentNumber = queryValues[4].trim() != '' ? queryValues[4].trim().match(/\d+/g).join('') : func.generateNumber(1, 999)
apartmentType = (queryValues[5].trim() != '' && (queryValues[5].trim() == 'BIL' || queryValues[5].trim() == 'TRN' || queryValues[5].trim() == 'TER')) ? 'בניין' : (queryValues[5].trim() != '' && queryValues[5].trim() == 'VIL') ? 'בית פרטי' : ''

po.log('info', `ID: ${id}`)
po.log('info', `Phone: ${phone}`)
po.log('info', `Email: ${email}`)
po.log('info', `Full Name: ${firstName} ${lastName}`)
po.log('info', `Product Number: ${productNumber}`)
po.log('info', `Address: ${city} ${street} House: ${houseNumber} Apartment: ${apartmentNumber} Entrance: ${entrance} Apartment Type: ${apartmentType}`)

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${repName}`)
settings.loginWithRep(repName)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Open New Lead Form')
leads.openNewLeadForm()

web.transaction(`Create Lead For ${firstName} ${lastName}`)
leads.createLead(firstName, lastName, phone, id)

web.transaction('Update Lead')
leads.updateLead(id, firstName, lastName)

web.transaction('Add Address')
sales.addAddress(city, street, email, houseNumber, apartmentNumber, entrance, apartmentType)

web.transaction('Feasibility Test')
sales.feasibilityTest(city, street, houseNumber)
sales.chooseProduct(productName, productNumber)
main.assertApplicationError()

web.transaction('Accept Conditions')
sales.acceptConditions(city, street, houseNumber)
// sales.retryInCaseOfError(city, street, email, houseNumber, apartmentNumber, entrance, apartmentType, productName, productNumber)

web.transaction('Choose Delivery by Technician')
sales.chooseDeliveryByTechnician(phone)

web.transaction('Order Summary')
sales.assertOrderSummary()

web.transaction('Payment Info')
sales.enterPaymentDetails(email) 

web.transaction('Assert Order')
const newCustomerNumber = sales.assertOrder()

web.transaction(`Search Newly Created Customer ${newCustomerNumber}`)
sales.searchNewlyCreatedCustomer(newCustomerNumber, true)

web.transaction('Update Send Sale Form')
web.click('//button[contains(text(), "דיוור סיכום מכירה")]')

var sendSaleFormTries = 10
while (web.isVisible(`//*[contains(text(), "לא נמצאה הזמנה בסטטוס 'הושלם'")]`, po.longWait)) {
    po.log('warning', web.getText('//h2[contains(text(), "דיוור סיכום מכירה")]//..//..//flowruntime-lwc-body'))
    web.click('//button[contains(text(), "סיים")]')
    func.refresh()
    web.pause(po.longWait)
    web.click('//button[contains(text(), "דיוור סיכום מכירה")]')

    if (sendSaleFormTries == 0) break
    else sendSaleFormTries--
}

if (web.isVisible('//*[contains(text(), "כתובת המייל של הלקוח שגויה")]', po.longWait)) {
    web.type('//input[@name="Email"]', email)
    web.click('//*[@aria-disabled="false" and (text()="הבא")]')
    web.click('//button[contains(text(), "סיים")]')
    web.click('//button[contains(text(), "דיוור סיכום מכירה")]')
}

if (web.isVisible('//h2[contains(text(), "דיוור סיכום מכירה")]')) {
    web.select('//span[contains(text(), "בחר אופן שליחה")]//..//..//..//select', 'value=Email')

    if (!web.isVisible(`//div[@id="wrapper-body"]//*[contains(text(), "${email.toLocaleLowerCase()}")]`, po.shortWait)) {
        po.log('error', `לא מופיע שלח אל ${email} באת בחירת אופן שליחה במייל`)
    }

    web.click('//*[(text()="הבא")]')

    if (web.isVisible('//span[contains(text(), "ללקוח לא הוגדרה כתובת אימייל")]', po.shortWait)) {
        po.log('error', `לא הוגדרה כתובת אימייל ללקוח: ${newCustomerNumber}`)
        web.select('//span[contains(text(), "בחר אופן שליחה")]//..//..//..//select', 'value=SMS')
        web.select('//span[contains(text(), "בחר מספר לשליחה")]//..//..//..//select', `label=${phone}`)
        web.click('//*[(text()="הבא")]')
    }

    if (web.isVisible('//*[contains(text(), "בקשה לשליחת טופס דיוור נשלחה בהצלחה")]')) {
        po.log('success', `בקשה לשליחת טופס דיוור נשלחה בהצלחה ללקוח: ${newCustomerNumber}`)
        web.click('//button[contains(text(), "סיים")]')
        assert.pass()
    } else {
        assert.fail(`הייתה שגיאה בבקשה לשליחת טופס דיוור ללקוח: ${newCustomerNumber}`)
    }
} else {
    assert.fail('לא נפתח חלון דיוור סיכום מכירה')
}

if (web.isVisible('//span[@data-aura-class="forceActionsText"]//..//..//..//..//button[@title="סגור"]', po.shortWait)) {
    web.click('//span[@data-aura-class="forceActionsText"]//..//..//..//..//button[@title="סגור"]')
}

// web.transaction(`Delete Customer ${newCustomerNumber}`)
// leads.deleteLead(firstName, lastName, newCustomerNumber)
