log.info(`3. הליך מכר מעורב ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const sales = po.sales
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const settings = po.settingsPage

var fs = require('fs')
var salesRep = env.salesRep
var id = func.createTzNumber()
var phone = func.generatePhone()
var firstName = func.generateName()
var lastName = `Automation - ${Math.random().toString().slice(2, 8)}`
var email = env.email ? env.email : func.generateEmail()
var productName = 'STING'
var productNumber = '200701'
var city = 'כפר סבא'
var street = 'הרעות'
var houseNumber = '370'
var apartmentType = 'בניין'
var entrance = ''

var apartmentNumberTracker = po.dataFolder + '\\apartmentNumberTracker.js'
if (!fs.existsSync(apartmentNumberTracker)) fs.writeFileSync(apartmentNumberTracker, func.generateNumber(1, 999))
var apartmentNumber = fs.existsSync(apartmentNumberTracker) ? fs.readFileSync(apartmentNumberTracker).toString() : func.generateNumber(1, 999)

// yesClassic
// מבצעי יסוד
// אוכלוסיות מיוחדות
// עסקי

// web.transaction('Connect To Wiz DB')
// var queryValues = po.database.getAddress()

// var city = queryValues[0].trim() != '' ? queryValues[0].trim() : 'מודיעין-מכבים-רעות'
// var street = queryValues[1].trim() != '' ? queryValues[1].trim() : 'עמק חרוד'
// var houseNumber = queryValues[2].trim() != '' ? queryValues[2].trim().match(/\d+/g).join('') : '44'
// var entrance = queryValues[3].trim() != '' ? queryValues[3].trim() : ''
// var apartmentNumber = queryValues[4].trim() != '' ? queryValues[4].trim().match(/\d+/g).join('') : func.generateNumber(1, 999)
// var apartmentType = (queryValues[5].trim() != '' && (queryValues[5].trim() == 'BIL' || queryValues[5].trim() == 'TRN' || queryValues[5].trim() == 'TER')) ? 'בניין' : (queryValues[5].trim() != '' && queryValues[5].trim() == 'VIL') ? 'בית פרטי' : ''

po.log('info', `ID: ${id}`)
po.log('info', `Phone: ${phone}`)
po.log('info', `Email: ${email}`)
po.log('info', `Full Name: ${firstName} ${lastName}`)
po.log('info', `Product Number: ${productNumber}`)
po.log('info', `Address: ${city} ${street} House: ${houseNumber} Apartment: ${apartmentNumber} Entrance: ${entrance} Apartment Type: ${apartmentType}`)

web.transaction('Open Settings')
main.openSettings()

web.transaction(`Login With Rep -> ${salesRep}`)
settings.loginWithRep(salesRep)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Open New Lead Form')
leads.openNewLeadForm()

web.transaction(`Create Lead For ${firstName} ${lastName}`)
leads.createLead(firstName, lastName, phone, id)

web.transaction('Update Lead')
leads.updateLead(id, firstName, lastName)

web.transaction('Add Address')
sales.addAddress(city, street, email, houseNumber, apartmentNumber, entrance, apartmentType)
fs.writeFileSync(apartmentNumberTracker, Number(apartmentNumber) + 1)
po.log('info', 'Apartment Number + 1')

web.transaction('Feasibility Test')
sales.feasibilityTest(city, street, houseNumber)

web.transaction(`Choose < ${productName} > Product`)
sales.chooseProduct(productName, productNumber)

web.transaction('Accept Conditions')
sales.acceptConditions(city, street, houseNumber)

web.transaction('Choose Delivery by Technician')
sales.chooseDeliveryByTechnician(phone)

web.transaction('Order Summary')
sales.assertOrderSummary()

web.transaction('Payment Info')
sales.enterPaymentDetails(email) 

web.transaction('Assert Order')
const newCustomerNumber = sales.assertOrder()
main.closeTabs()

web.transaction(`Search Newly Created Customer ${newCustomerNumber}`)
sales.searchNewlyCreatedCustomer(newCustomerNumber, true)
web.click(`//a[@data-label='פק"עות וכתובות']`)

if (web.isVisible(`//td[@data-label='מספר פק"ע']`, po.longWait)) {
    var pakaNumber = web.getAttribute(`//td[@data-label='מספר פק"ע']`, 'data-cell-value')
    pakaNumber = pakaNumber.split('-')[0]
    po.log('info', 'New Paka: ' + pakaNumber)
} else {
    po.log('error', `מספר פק"ע לא מופיע אצל לקוח מספר ${newCustomerNumber}`)
}

web.transaction(`Delete Customer ${newCustomerNumber}`)
main.closeTabs()
leads.deleteLead(firstName, lastName, newCustomerNumber)
