log.info(`0. יצירת לקוח יס ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const sales = po.sales
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const settings = po.settingsPage
const searchPage = po.searchCustomerPage
const alpha360 = po.customerDetails360

var repName = env.salesRep
var id = func.createTzNumber()
var phone = func.generatePhone()
var firstName = func.generateName()
var lastName = `Automation - ${Math.random().toString().slice(2, 8)}`
var email = env.email ? env.email : func.generateEmail()
var city, street, houseNumber, entrance, apartmentNumber
var productNumber = '200701'
var productName = 'STING'

web.transaction('Connect To Wiz DB')
var queryValues = po.database.getAddress()

city = queryValues[0].trim() != '' ? queryValues[0].trim() : 'מודיעין-מכבים-רעות'
street = queryValues[1].trim() != '' ? queryValues[1].trim() : 'עמק חרוד'
houseNumber = queryValues[2].trim() != '' ? queryValues[2].trim().match(/\d+/g).join('') : '44'
entrance = queryValues[3].trim() != '' ? queryValues[3].trim() : ''
apartmentNumber = queryValues[4].trim() != '' ? queryValues[4].trim().match(/\d+/g).join('') : func.generateNumber(1, 999)
apartmentType = (queryValues[5].trim() != '' && (queryValues[5].trim() == 'BIL' || queryValues[5].trim() == 'TRN' || queryValues[5].trim() == 'TER')) ? 'בניין' : (queryValues[5].trim() != '' && queryValues[5].trim() == 'VIL') ? 'בית פרטי' : ''

po.log('info', `ID: ${id}`)
po.log('info', `Phone: ${phone}`)
po.log('info', `Email: ${email}`)
po.log('info', `Full Name: ${firstName} ${lastName}`)
po.log('info', `Product Number: ${productNumber}`)
po.log('info', `Address: ${city} ${street} House: ${houseNumber} Apartment: ${apartmentNumber} Entrance: ${entrance} Apartment Type: ${apartmentType}`)

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${repName}`)
settings.loginWithRep(repName)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction('Open New Lead Form')
leads.openNewLeadForm()

web.transaction(`Create Lead For ${firstName} ${lastName}`)
leads.createLead(firstName, lastName, phone, id)

web.transaction('Update Lead')
leads.updateLead(id, firstName, lastName)

web.transaction('Add Address')
sales.addAddress(city, street, email, houseNumber, apartmentNumber, entrance, apartmentType)

web.transaction('Feasibility Test')
sales.feasibilityTest(city, street, houseNumber)

web.transaction(`Choose < ${productName} > Product`)
sales.chooseProduct(productName, productNumber)
main.assertApplicationError()

web.transaction('Accept Conditions')
sales.acceptConditions(city, street, houseNumber)
// sales.retryInCaseOfError(city, street, email, houseNumber, apartmentNumber, entrance, apartmentType, productName, productNumber)

web.transaction('Choose Delivery by Technician')
sales.chooseDeliveryByTechnician(phone)

web.transaction('Order Summary')
sales.assertOrderSummary()

web.transaction('Payment Info')
sales.enterPaymentDetails(email) 

web.transaction('Assert Order')
const newCustomerNumber = sales.assertOrder()
main.closeTabs()

web.transaction(`Search Newly Created Customer ${newCustomerNumber}`)
sales.searchNewlyCreatedCustomer(newCustomerNumber, false)

// web.transaction(`Delete Customer  ${newCustomerNumber}`)
// leads.deleteLead(firstName, lastName, newCustomerNumber)
