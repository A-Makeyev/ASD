module.exports = {

    suites: [
        {
            name: 'Technicians',
            cases: [
                { path: './Technicians/1. חיפוש מועמדים לפקע בגאנט.js' },
                { path: './Technicians/2. תיאום מקוסטם לפקע בגאנט.js' },
                { path: './Technicians/3. שיבוץ בעזרת גרירת פקע בגאנט.js' },
                { path: './Technicians/4. שיבוץ מחדש עי גרירה בגאנט.js' },
                { path: './Technicians/5. הסרה משיבוץ בגאנט.js' },
                { path: './Technicians/6. מחיקת משמרת אלפא.js' },
                { path: './Technicians/7. הקמת משמרת אלפא.js' },
                { path: './Technicians/8. חיפוש פקע מקוסטם על הגאנט.js' },
                { path: './Technicians/9. SAתיאום מקוסטם לפקע על ה.js' },
                { path: './Technicians/10. עריכת פרטי אספקה בחלון תיאום.js' },
                { path: './Technicians/11. SA תיאום מחדש של פקע.js' },
                // { path: './Technicians/12. SA חיפוש מועמדים.js' },
                // { path: './Technicians/13. בדיקת תקינות מעבר סטטוסים.js' },
                // { path: './Technicians/14. מעבר פקע מסטטוס משובץ לפתוח ולהמתנה.js' },
            ]
        },

        // {
        //     name: 'Sales (מכר)',
        //     cases: [
        //         { path: './Sales (מכר)/1. תהליך מכר ULTIMATE.js' },
        //         { path: './Sales (מכר)/2. תהליך מכר עם הצעת סטינג.js' },
        //         { path: './Sales (מכר)/3. הליך מכר מעורב.js' },
        //         { path: './Sales (מכר)/4. תהליך מכר לוויאני.js' },
        //         { path: './Sales (מכר)/5. תהליך מכר BYOD.js' },
        //         { path: './Sales (מכר)/6. עדכון פרטים אישיים.js' },
        //         { path: './Sales (מכר)/7. עדכון אמצעי תשלום.js' },
        //         { path: './Sales (מכר)/8. דיוור סיכום מכירה.js' },
        //         { path: './Sales (מכר)/9. SMS זיהוי לקוח.js' }, 
        //         { path: './Sales (מכר)/10. שליחת הודעה ללקוח.js' },
        //     ]
        // },

        // {
        //     name: 'Search Customers',
        //     cases: [
        //         { path: './Search Customers/01. חיפוש לקוח - טלפון.js' },
        //         { path: './Search Customers/02. חיפוש לקוח - מספר לקוח.js' },
        //         { path: './Search Customers/03. חיפוש לקוח - מספר ממיר.js' },
        //         { path: './Search Customers/04. חיפוש לקוח - מספר פנייה.js' },
        //         { path: './Search Customers/05. חיפוש לקוח - שם.js', 
        //            iterations: 1,
        //            load: {
        //               threads: 50,        
        //               rampup: 100,     
        //               duration: 300    
        //            }
        //         },
        //     ]
        // },
    ],

    seleniumUrl: 'http://autoload01:4444/wd/hub',
    modules: ['web', 'assert', 'log', 'db', 'http', 'utils'],
    framework: 'oxygen',

    reporting: {
        outputDir: './Reports',
        reporters: ['csv', 'es'],
    },

    elasticOpts: {
        node: 'http://autoload03:9200',
    },
          
    // =====
    // Hooks
    // =====
    // Oxygen provides several hooks that can be used to interfere with the test
    // execution process. 
    //
    // hooks: {
    //     //
    //     // Hook that gets executed before the test starts.
    //     // At this point, Oxygen has been already initialized, so you
    //     // can access Oxygen via 'ox' global variable. 
    //     //
    //     beforeTest: function(runId, options, caps) {

    //     },
    //     beforeCase: function(suiteDef) {

    //     },
    //     beforeSuite: function(caseDef) {
       
    //     },
    //     beforeCommand: function(cmdDef) {

    //     },
    //     afterCommand: function(cmdResult) {

    //     },
    //     afterCase: function(caseDef, caseResult) {

    //     },
    //     afterSuite: function(suiteDef, suiteResult) {
            
    //     },
    //     afterTest: function(runId, testResult) {

    //     }
    // }
}
