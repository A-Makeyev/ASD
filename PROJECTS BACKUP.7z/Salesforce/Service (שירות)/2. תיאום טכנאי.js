log.info(`2. תיאום טכנאי ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const cases = po.cases
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const settings = po.settingsPage
const alpha360 = po.customerDetails360
const searchPage = po.searchCustomerPage
const email = env.email ? env.email : func.generateEmail()
const repName = env.serviceRep
const customerNumber = '245158'

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${repName}`)
settings.loginWithRep(repName)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction(`07. Search Customer ${customerNumber}`)
if (!web.isVisible(searchPage.header, po.shortWait)) {
    web.click(main.navigationBtn)
    web.click(main.navigationOptions.customers)
    assert.equal(web.isVisible(searchPage.header), true)
}

web.click(searchPage.searchParametersBtn)
web.pause(po.shortWait)

if (!web.isVisible(searchPage.parameters.accountNumber, po.shortWait)) {
    web.click(searchPage.searchParametersBtn)
}

web.click(searchPage.parameters.accountNumber)
web.type(searchPage.accountNumberInput, customerNumber)
web.click(searchPage.searchBtn)

web.transaction('08. Create Request')
po.clickUntilElementIsVisible('//c-create-case-modal', cases.createCaseBtn)

if (web.isVisible('//c-create-case-modal', po.longWait)) {
    web.click('(//span[contains(text(), "פניית תפעול ותמיכה")])[1]')
    web.click(cases.nextBtn)
} else if (web.isVisible('//h2[contains(text(), "עדכון פרטים אישיים")]', po.longWait)) {
    web.click('//h2[contains(text(), "עדכון פרטים אישיים")]//..//..//*[(text()="הבא")]')

    if (web.isVisible('//img[contains(@src, "Error")]', po.longWait)) {
        po.log('error', web.getText('(//div[@id="wrapper-body"]//flowruntime-list-container)[1]'))
        web.click(cases.finishBtn)
        web.click(cases.createCaseBtn)
    }
}

if (web.isVisible('//*[contains(text(), "כתובת המייל של הלקוח שגויה")]', po.shortWait)) {
    web.type('//span[contains(text(), "דואר אלקטרוני")]//..//..//..//input', email)
    web.click('//button[text()="הבא"]')
    if (web.isVisible('//p[contains(text(), "פרטים אישיים נקלטו בהצלחה")]', po.longWait)) {
        po.log('success', 'פרטים אישיים נקלטו בהצלחה')
        assert.pass()
    }
}

if (web.isVisible(cases.finishBtn, po.shortWait)) web.click(cases.finishBtn)
if (web.isVisible(cases.createCaseBtn, po.shortWait)) web.click(cases.createCaseBtn)
if (web.isVisible(cases.nextBtn, po.shortWait)) web.click(cases.nextBtn)

if (web.isVisible('//*[contains(text(), "יש לתעד את התקלה")]', po.longWait)) {
    po.log('warning', web.getText('//*[contains(text(), "יש לתעד את התקלה")]'))
}

if (web.isVisible('//h2[contains(text(), "קיים תיק פתוח")]', po.longWait)) {
    po.log('warning', web.getText('//h2[contains(text(), "קיים תיק פתוח")]//..//..//..//..//div[@class="modal-content"]'))
    assert.pass()
}

if (web.isVisible(`//a[@title="פתוח"]//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//a[@data-label='פק"עות']`, po.longWait)) {
    web.transaction('09. Get Technician')
    web.click(`//a[@title="פתוח"]//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//a[@data-label='פק"עות']`)
    web.click(`(//*[contains(text(), 'פק"עות פתוחות')]//..//..//..//lightning-primitive-cell-actions//button)[2]`)

    if (web.isVisible('//a[@role="menuitem"]//span[contains(text(), "עדכון תיאום")]')) {
        web.clickHidden('//a[@role="menuitem"]//span[contains(text(), "עדכון תיאום")]')
        web.click('//button[contains(text(), "מצא חלון זמן")]')
        if (!web.isVisible('(//div[contains(@class, "singleDay")])[1]', po.longWait)) {
            main.assertErrorDialog()
            po.clickUntilElementIsVisible('(//div[contains(@class, "singleDay")])[1]', '//button[contains(text(), "מצא חלון זמן")]')
        }
        web.pause(po.shortWait)
        web.click('(//div[contains(@class, "singleDay")])[1]')
        if (!web.isVisible('//lightning-spinner', po.longWait)) {
            web.click('//span[contains(text(), "המצאות בגיר בבית")]')
            web.click('//span[contains(text(), "הוסבר חיוג מטלפון")]')
            web.click('//button[@title="תאם" and not(@disabled)]')
        } else {
            po.log('error', 'Window stuck on loading after clicking on a date')

            web.click(`(//*[contains(text(), 'פק"עות  פתוחות')]//..//..//..//lightning-primitive-cell-actions//button)[2]`)
            web.click('//a[@role="menuitem"]//span[contains(text(), "עדכון תיאום")]')
            web.click('//button[contains(text(), "מצא חלון זמן")]')
            if (!web.isVisible('(//div[contains(@class, "singleDay")])[1]', po.longWait)) {
                main.assertErrorDialog()
                po.clickUntilElementIsVisible('(//div[contains(@class, "singleDay")])[1]', '//button[contains(text(), "מצא חלון זמן")]')
            }
            web.pause(po.shortWait)
            web.click('(//div[contains(@class, "singleDay")])[1]')
        }
    } else if (web.isVisible('//a[@role="menuitem"]//span[contains(text(), "תיאום טכנאי")]')) {
        web.clickHidden('//a[@role="menuitem"]//span[contains(text(), "תיאום טכנאי")]')
        web.click('//*[contains(text(), "בחר אופן אספקה")]//..//..//..//..//..//lightning-base-formatted-text[contains(text(), "טכנאי")]//..//..//..//..//..//label[contains(@id, "radio")]')

        if (web.isVisible('//span[contains(text(), "בחר אופן אספקה")]')) {
            web.click('//th[@data-label="שיטת אספקה"]//lightning-base-formatted-text[contains(text(), "טכנאי")]//..//..//..//..//..//span[@class="slds-radio_faux"]')
            web.click('//button[contains(text(), "מצא חלון זמן")]')
            if (!web.isVisible('(//div[contains(@class, "singleDay")])[1]', po.longWait)) {
                main.assertErrorDialog()
                po.clickUntilElementIsVisible('(//div[contains(@class, "singleDay")])[1]', '//button[contains(text(), "מצא חלון זמן")]')
            }
            web.pause(po.shortWait)
            web.click('(//div[contains(@class, "singleDay")])[1]')
            if (!web.isVisible('//lightning-spinner', po.longWait)) {
                web.click('//span[contains(text(), "המצאות בגיר בבית")]')
                web.click('//span[contains(text(), "הוסבר חיוג מטלפון")]')
                web.click('//button[@title="תאם" and not(@disabled)]')
            } else {
                po.log('error', 'Window stuck on loading after clicking on a date')

                web.click('//a[@role="menuitem"]//span[contains(text(), "תיאום טכנאי")]')
                web.click('//*[contains(text(), "בחר אופן אספקה")]//..//..//..//..//..//lightning-base-formatted-text[contains(text(), "טכנאי")]//..//..//..//..//..//label[contains(@id, "radio")]')
                web.click('//th[@data-label="שיטת אספקה"]//lightning-base-formatted-text[contains(text(), "טכנאי")]//..//..//..//..//..//span[@class="slds-radio_faux"]')
                web.click('//button[contains(text(), "מצא חלון זמן")]')
                if (!web.isVisible('(//div[contains(@class, "singleDay")])[1]', po.longWait)) {
                    main.assertErrorDialog()
                    po.clickUntilElementIsVisible('(//div[contains(@class, "singleDay")])[1]', '//button[contains(text(), "מצא חלון זמן")]')
                }
                web.pause(po.shortWait)
                web.click('(//div[contains(@class, "singleDay")])[1]')
                web.click('//span[contains(text(), "המצאות בגיר בבית")]')
                web.click('//span[contains(text(), "הוסבר חיוג מטלפון")]')
                web.click('//button[@title="תאם" and not(@disabled)]')
            }
        }

        web.type('//input[@name="contactName"]', 'שם לתיאום אספקה')
        web.click('//span[contains(text(), "המצאות בגיר בבית")]')
        web.click('//span[contains(text(), "הוסבר חיוג מטלפון")]')
        web.click('//label[contains(text(), "סיבת בחירת החלון")]//..//button')
        web.click('//span[@title="בקשת לקוח"]')
        web.click('//button[@title="תאם" and not(@disabled)]')
    } 
    
    if (web.isVisible('//span[contains(text(), "הושלם בהצלחה")]')) {
        po.log('success', 'תיאום טכנאי הושלם בהצלחה')
        web.click('//button[contains(text(), "סיים")]')
        assert.pass()
    } else {
        assert.fail('הייתה תקלה בתיאום טכנאי')
    }
} else {
    if (web.isVisible('//h2[contains(text(), "קיים תיק פתוח")]', po.longWait)) {
        po.log('warning', web.getText('//h2[contains(text(), "קיים תיק פתוח")]//..//..//..//..//div[@class="modal-content"]'))
    }

    if (web.isVisible('//*[contains(text(), "כתובת המייל של הלקוח שגויה")]', po.shortWait)) {
        web.type('//span[contains(text(), "דואר אלקטרוני")]//..//..//..//input', email)
        web.click('//button[text()="הבא"]')
        if (web.isVisible('//p[contains(text(), "פרטים אישיים נקלטו בהצלחה")]', po.longWait)) {
            po.log('success', 'פרטים אישיים נקלטו בהצלחה')
            assert.pass()
        }
    }

    web.click('//label[contains(text(), "סוג תקלה")]//..//input')
    web.click('//label[contains(text(), "סוג תקלה")]//..//li[@class="slds-listbox__item"]//span[contains(text(), "תקלה מלאה")]')

    web.click('//label[contains(text(), "אבחון משני")]//..//input')
    web.click('(//label[contains(text(), "אבחון משני")]//..//li[@class="slds-listbox__item"])[1]')

    web.click('//span[contains(text(), "לא בוצע תפעול")]')

    web.click('//label[contains(text(), "סיבה")]//..//input')
    web.click('//label[contains(text(), "סיבה")]//..//li[@class="slds-listbox__item"]//span[contains(text(), "לקוח מסרב לתפעל")]')

    web.click('//label[contains(text(), "תוצאה")]//..//input')
    web.click('//label[contains(text(), "תוצאה")]//..//li[@class="slds-listbox__item"]//span[contains(text(), "נדרש טיפול טכנאי")]')

    web.pause(po.shortWait)
    web.click('//button[contains(text(), "שמור תקלה")]')
    main.assertErrorDialog()

    if (web.isVisible('//div[@class="slds-modal__container change-alias-modal"]', po.shortWait)) {
        web.click('//div[@class="slds-modal__container change-alias-modal"]//button[@title="Yes"]')
    }

    web.transaction(`09. Search Customer ${customerNumber}`)
    if (!web.isVisible(searchPage.header, po.shortWait)) {
        web.click(main.navigationBtn)
        web.click(main.navigationOptions.customers)
        assert.equal(web.isVisible(searchPage.header), true)
    }

    web.click(searchPage.searchParametersBtn)
    web.pause(po.shortWait)

    if (!web.isVisible(searchPage.parameters.accountNumber, po.shortWait)) {
        web.click(searchPage.searchParametersBtn)
    }

    web.click(searchPage.parameters.accountNumber)
    web.type(searchPage.accountNumberInput, customerNumber)
    web.click(searchPage.searchBtn)

    if (web.isVisible(`//th[@data-label="מספר לקוח משלם"]//a[contains(text(), "${customerNumber}")]`, po.longWait)) web.click(`//th[@data-label="מספר לקוח משלם"]//a[contains(text(), "${customerNumber}")]`)
    if (web.isVisible(`//div[contains(text(), "${customerNumber}")]`, po.longWait)) web.click(`//div[contains(text(), "${customerNumber}")]`)

    web.transaction('10. Assert Created Request')
    web.click(alpha360.pakaList)
    main.assertErrorDialog()

    assert.equal(
        web.isExist('(//lightning-base-formatted-text[contains(text(), "תקלה")])[1]'), true,
        `לא נוצרה תקלה אצל לקוח מספר: ${customerNumber}`
    )
}
