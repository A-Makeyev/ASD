log.info(`3. איפוס תיאום ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const cases = po.cases
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const settings = po.settingsPage
const alpha360 = po.customerDetails360
const searchPage = po.searchCustomerPage
const email = env.email ? env.email : func.generateEmail()
const repName = env.serviceRep
const customerNumber = '245158'

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${repName}`)
settings.loginWithRep(repName)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction(`07. Search Customer ${customerNumber}`)
if (!web.isVisible(searchPage.header, po.shortWait)) {
    web.click(main.navigationBtn)
    web.click(main.navigationOptions.customers)
    assert.equal(web.isVisible(searchPage.header), true)
}

web.click(searchPage.searchParametersBtn)
web.pause(po.shortWait)

if (!web.isVisible(searchPage.parameters.accountNumber, po.shortWait)) {
    web.click(searchPage.searchParametersBtn)
}

web.click(searchPage.parameters.accountNumber)
web.type(searchPage.accountNumberInput, customerNumber)
web.click(searchPage.searchBtn)

web.transaction('08. Create Request')
web.click(cases.createCaseBtn)

if (web.isVisible('//div[@id="wrapper-body"]//h2[contains(text(), "עדכון פרטים אישיים")]', po.longWait)) {
    web.click(cases.nextBtn)
    if (web.isVisible('//img[contains(@src, "Error")]', po.longWait)) {
        po.log('error', web.getText('(//div[@id="wrapper-body"]//flowruntime-list-container)[1]'))
        web.click(cases.finishBtn)
        web.click(cases.createCaseBtn)
    }
} else {
    web.click('(//span[contains(text(), "פניית תפעול ותמיכה")])[1]')
    web.click(cases.nextBtn)
}

if (web.isVisible(cases.finishBtn, po.shortWait)) web.click(cases.finishBtn)
if (web.isVisible(cases.createCaseBtn, po.shortWait)) web.click(cases.createCaseBtn)
if (web.isVisible(cases.nextBtn, po.shortWait)) web.click(cases.nextBtn)
if (web.isVisible(cases.finishBtn, po.shortWait)) web.click(cases.finishBtn)

if (web.isVisible('//*[contains(text(), "יש לתעד את התקלה")]', po.longWait)) {
    po.log('warning', web.getText('//*[contains(text(), "יש לתעד את התקלה")]'))
}

if (web.isVisible(`//a[@title="פתוח"]//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//a[@data-label='פק"עות']`, po.longWait)) {
    web.transaction('09. Reset Request')
    web.click(`//a[@title="פתוח"]//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//..//a[@data-label='פק"עות']`)
    web.click(`(//*[contains(text(), 'פק"עות פתוחות')]//..//..//..//lightning-primitive-cell-actions//button)[2]`)
    web.clickHidden('//a[@role="menuitem"]//span[contains(text(), "איפוס")]')

    if (web.isVisible(`//h2[contains(text(), 'איפוס פק"ע')]`)) {
        po.specialClick('//label[contains(text(), "סיבות לאיפוס")]//..//button')
        func.pressARROW_DOWN()
        func.pressENTER()
        web.click(cases.nextBtn)

        if (web.isVisible('//span[contains(text(), "הושלם בהצלחה")]')) {
            po.log('success', 'איפוס פק"ע הושלם בהצלחה')
            web.click('//button[contains(text(), "סיים")]')
            assert.pass()
        } else {
            assert.fail('הייתה תקלה באיפוס פק"ע')
        }
    } else {
        po.log('error', 'לא הוקפץ חלון איפוס פק"ע')
    }
} 
