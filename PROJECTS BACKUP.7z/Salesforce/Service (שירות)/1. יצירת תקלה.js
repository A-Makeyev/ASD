log.info(`1. יצירת תקלה ${env.name != 'default' ? `(${env.name} סביבת)` : ''}`)
po.init(env.url)

const cases = po.cases
const leads = po.leads
const func = po.functions
const main = po.alphaMainPage
const settings = po.settingsPage
const alpha360 = po.customerDetails360
const searchPage = po.searchCustomerPage
const email = env.email ? env.email : func.generateEmail()
const repName = env.serviceRep
const customerNumber = '245158'

web.transaction('Open Settings')
main.updatePersonalDetailsError(email)
main.openSettings()

web.transaction(`Login With Rep -> ${repName}`)
settings.loginWithRep(repName)

web.transaction('Close All Active Tabs')
main.closeTabs()

web.transaction(`07. Search Customer ${customerNumber}`)
if (!web.isVisible(searchPage.header, po.shortWait)) {
    web.click(main.navigationBtn)
    web.click(main.navigationOptions.customers)
    assert.equal(web.isVisible(searchPage.header), true)
}

web.click(searchPage.searchParametersBtn)
web.pause(po.shortWait)

if (!web.isVisible(searchPage.parameters.accountNumber, po.shortWait)) {
    web.click(searchPage.searchParametersBtn)
}

web.click(searchPage.parameters.accountNumber)
web.type(searchPage.accountNumberInput, customerNumber)
web.click(searchPage.searchBtn)

web.transaction('08. Create Request')
po.clickUntilElementIsVisible('//c-create-case-modal', cases.createCaseBtn)

if (web.isVisible('//c-create-case-modal', po.longWait)) {
    web.click('(//span[contains(text(), "פניית תפעול ותמיכה")])[1]')
    web.click(cases.nextBtn)
} else if (web.isVisible('//h2[contains(text(), "עדכון פרטים אישיים")]', po.longWait)) {
    web.click('//h2[contains(text(), "עדכון פרטים אישיים")]//..//..//*[(text()="הבא")]')

    if (web.isVisible('//img[contains(@src, "Error")]', po.longWait)) {
        po.log('error', web.getText('(//div[@id="wrapper-body"]//flowruntime-list-container)[1]'))
        web.click(cases.finishBtn)
        web.click(cases.createCaseBtn)
    }
}

if (web.isVisible('//*[contains(text(), "פרטים אישיים נקלטו בהצלחה")]', po.longWait)) {
    po.log('success', 'פרטים אישיים נקלטו בהצלחה')
} 

if (web.isVisible('//div[@id="wrapper-body"]//h2[contains(text(), "עדכון פרטים אישיים")]', po.longWait)) {
    web.click('//div[@id="wrapper-body"]//h2[contains(text(), "עדכון פרטים אישיים")]//..//..//..//..//..//button[contains(@title, "סגור")]')
    web.click('//button[contains(text(), "צור פנייה")]')
    web.click(cases.nextBtn)

    web.click('(//div[@class="slds-form-element__control"]//span[@class="slds-radio_faux"])[1]')
    web.click('//label[contains(text(), "בחירת תת נושא")]//..//input')
    web.click('(//li[@class="slds-listbox__item"])[1]')
    func.pressTAB()
    web.click('//button[text()="שמירה"]')
    web.click('//button[text()="שמור"]')

    if (web.isVisible('//div[@data-key="success"]//span[@ data-aura-class="forceActionsText"]', po.shortWait)) {
        po.log('success', web.getText('//div[@data-key="success"]//span[@ data-aura-class="forceActionsText"]'))
    }
}

if (web.isVisible(cases.finishBtn, po.shortWait)) web.click(cases.finishBtn)
if (web.isVisible(cases.createCaseBtn, po.shortWait)) web.click(cases.createCaseBtn)
if (web.isVisible(cases.nextBtn, po.shortWait)) web.click(cases.nextBtn)

web.transaction('09. Delete Existing Requests')
let requestElements = '//article[@aria-label="תקלות"]//lst-template-list-item-factory//article[contains(@aria-label, "")]'
if (web.isVisible(requestElements)) {
    web.scrollToElement(`(${requestElements})[1]`, false)
    
    let requests = web.getElementCount(requestElements)
    po.log('warning', `קיימות ${requests} תקלות פתוחות`)

    for (let r = 1; r <= requests; r++) {
        let requestInfo = web.getAttribute(`(${requestElements})[1]`, 'aria-label')
        po.log('info', `${r}. ${requestInfo}`)

        po.specialClick(`(${requestElements}//lightning-button-menu)[1]`)      
        po.specialClick('(//div[@title="מחיקה" and @class="forceActionLink"])[1]')

        if (leads.confirmDelete, po.longWait) {
            po.specialClick(leads.confirmDelete)
            if (web.isVisible(main.toastText, po.longWait)) {
                po.log('success', web.getText(main.toastText)) 
            }
            po.specialClick('//lightning-icon[@icon-name="utility:close"]')
        } else {
            continue
        }
    }
}

web.transaction('10. Create New Request')
if (web.isVisible('//*[contains(text(), "יש לתעד את התקלה")]', po.longWait)) {
    po.log('warning', web.getText('//*[contains(text(), "יש לתעד את התקלה")]'))
}

if (web.isVisible('//h2[contains(text(), "קיים תיק פתוח")]', po.longWait)) {
    web.click(cases.nextBtn)
    po.log('warning', web.getText('//h2[contains(text(), "קיים תיק פתוח")]//..//..//..//..//div[@class="modal-content"]'))
    web.click(cases.nextBtn)
    assert.fail(web.getText('//h2[contains(text(), "קיים תיק פתוח")]//..//..//..//..//div[@class="modal-content"]'))
}  

if (!web.isVisible('//label[contains(text(), "סוג תקלה")]//..//input', po.longWait)) {
    web.refresh()
}

web.click('//label[contains(text(), "סוג תקלה")]//..//input')
web.click('//label[contains(text(), "סוג תקלה")]//..//li[@class="slds-listbox__item"]//span[contains(text(), "תקלה מלאה")]')

web.click('//label[contains(text(), "אבחון משני")]//..//input')
web.click('(//label[contains(text(), "אבחון משני")]//..//li[@class="slds-listbox__item"])[1]')

web.click('//span[contains(text(), "לא בוצע תפעול")]')

web.click('//label[contains(text(), "סיבה")]//..//input')
web.click('//label[contains(text(), "סיבה")]//..//li[@class="slds-listbox__item"]//span[contains(text(), "לקוח מסרב לתפעל")]')

web.click('//label[contains(text(), "תוצאה")]//..//input')
web.click('//label[contains(text(), "תוצאה")]//..//li[@class="slds-listbox__item"]//span[contains(text(), "נדרש טיפול טכנאי")]')

if (web.isVisible('//button[contains(text(), "שמור תקלה")]')) {
    po.specialClick('//button[contains(text(), "שמור תקלה")]')
}

main.assertErrorDialog()

if (web.isVisible('//div[@class="slds-modal__container change-alias-modal"]', po.shortWait)) {
    web.click('//div[@class="slds-modal__container change-alias-modal"]//button[@title="Yes"]')
}

web.transaction(`11. Search Customer ${customerNumber}`)
if (!web.isVisible(searchPage.header, po.shortWait)) {
    web.click(main.navigationBtn)
    web.click(main.navigationOptions.customers)
    assert.equal(web.isVisible(searchPage.header), true)
}

web.click(searchPage.searchParametersBtn)
web.pause(po.shortWait)

if (!web.isVisible(searchPage.parameters.accountNumber, po.shortWait)) {
    web.click(searchPage.searchParametersBtn)
}

web.click(searchPage.parameters.accountNumber)
web.type(searchPage.accountNumberInput, customerNumber)
web.click(searchPage.searchBtn)

if (web.isVisible(`//th[@data-label="מספר לקוח משלם"]//a[contains(text(), "${customerNumber}")]`, po.longWait)) web.click(`//th[@data-label="מספר לקוח משלם"]//a[contains(text(), "${customerNumber}")]`)
if (web.isVisible(`//div[contains(text(), "${customerNumber}")]`, po.longWait)) web.click(`//div[contains(text(), "${customerNumber}")]`)

web.transaction('12. Assert Created Request')
web.click(alpha360.pakaList)
main.assertErrorDialog()

if (web.isVisible(`//*[contains(text(), 'היסטוריית פק"עות')]//..//..//..//*[@icon-name="utility:chevronleft"]`, po.longWait)) {
    web.click(`//*[contains(text(), 'היסטוריית פק"עות')]//..//..//..//*[@icon-name="utility:chevronleft"]`)
}

if (web.isExist('(//lightning-base-formatted-text[contains(text(), "תקלה")])[1]')) {
    po.log('success', `נוצרה תקלה אצל לקוח מספר: ${customerNumber}`)
} else {
    po.log('error', `לא נוצרה תקלה אצל לקוח מספר: ${customerNumber}`)
}
