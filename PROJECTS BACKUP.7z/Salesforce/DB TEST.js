db.setConnectionString(env.wiz_con_string)
po.log('success', `Connected to: ${env.wiz_con_string}`)

let getAddressQuery = 
`   
    SELECT TO_NCHAR(Y.City), TO_NCHAR(Y.Street_Name), TO_NCHAR(Y.Street_Number), 
    TO_NCHAR(Y.ENTRANCE), TO_NCHAR(Y.Unit_Number), TO_NCHAR(Y.Dwelling_Type)
    FROM wiz_hp_description Y
    WHERE Y.Wired = 'Y'
    AND Y.Drop_Location = '1'
    AND Y.Delete_Record <> 'Y'
    and Y.Unit_Number <> '        '
    AND Y.Service_Address_Id NOT IN (SELECT L.SERVICE_ADDRESS_ID from wiz_customer_hp_life L)
    AND Y.Service_Address_Id NOT IN (SELECT W.SERVICE_ADDRESS_ID from wiz_work_order W)
    AND ROWNUM <= 99
`
let address = db.executeQuery(getAddressQuery)
for (let x = 0; x < address.length; x++) {
    let randomQuery = po.functions.generateNumber(1, address.length)
    if (address[randomQuery] === null || address[randomQuery] === undefined|| address[randomQuery] === 'undefined') {
        po.log('warning', `Address query at index ${randomQuery} is undefined`)
        continue
    } else {
        houseType = Object.values(address[randomQuery])[5]
        log.info(houseType)

        let apartmentNumber = Object.values(address[randomQuery])[4]
        let houseNumber = Object.values(address[randomQuery])[2]

        if (apartmentNumber.match(/[א-ת]/) || houseNumber.match(/[א-ת]/)) {
            po.log('warning', `Address number includes letters: Apartment Number ${apartmentNumber}, House Number: ${houseNumber}`)
            continue
        } else {
            po.log('success', 'Data: ' + JSON.stringify(address[randomQuery]))
            //return Object.values(address[randomQuery])
        }
    }
}

// var queryValues = Object.values(address[randomQuery])
// city = queryValues[0].trim() != '' ? queryValues[0].trim() : 'מודיעין-מכבים-רעות'
// street = queryValues[1].trim() != '' ? queryValues[1].trim() : 'עמק חרוד'
// houseNumber = queryValues[2].trim() != '' ? queryValues[2].trim().match(/\d+/g).join('') : '44'
// entrance = queryValues[3].trim() != '' ? queryValues[3].trim() : ''
// apartmentNumber = queryValues[4].trim() != '' ? queryValues[4].trim().match(/\d+/g).join('') : func.generateNumber(1, 999)
